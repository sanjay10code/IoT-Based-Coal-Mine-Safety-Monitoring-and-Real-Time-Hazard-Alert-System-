import { useState, useCallback, useRef, useMemo } from "react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, Cell, ReferenceLine
} from "recharts";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const REQUIRED_COLS = ["timestamp","zone_id","ch4","co","co2","o2","temperature","humidity","dust_pm25","dust_pm10","vibration","water_level","airflow"];
const ZONES_DEFAULT = ["Zone-A","Zone-B","Zone-C","Zone-D","Zone-E","Zone-F"];
const RC = { Safe:"#22c55e", Moderate:"#f59e0b", Critical:"#ef4444" };
const RBG = { Safe:"rgba(34,197,94,0.13)", Moderate:"rgba(245,158,11,0.13)", Critical:"rgba(239,68,68,0.13)" };

// ─── ML ENGINE ────────────────────────────────────────────────────────────────
function rollingStats(arr, w=5) {
  return arr.map((_, i) => {
    const s = arr.slice(Math.max(0, i-w+1), i+1);
    const m = s.reduce((a,b)=>a+b,0)/s.length;
    const sd = Math.sqrt(s.reduce((a,b)=>a+(b-m)**2,0)/s.length);
    return { mean:m, std:sd };
  });
}
function roc(arr) { return arr.map((v,i)=>i===0?0:v-arr[i-1]); }
function slope(arr, w=10) {
  return arr.map((_,i)=>{
    const s=arr.slice(Math.max(0,i-w+1),i+1);
    if(s.length<2) return 0;
    const n=s.length, xm=(n-1)/2, ym=s.reduce((a,b)=>a+b,0)/n;
    const num=s.reduce((a,v,j)=>a+(j-xm)*(v-ym),0);
    const den=s.reduce((a,_,j)=>a+(j-xm)**2,0);
    return den===0?0:num/den;
  });
}
function isoForest(arr) {
  const m=arr.reduce((a,b)=>a+b,0)/arr.length;
  const rng=Math.max(...arr)-Math.min(...arr)||1;
  return arr.map(v=>Math.min(1,Math.abs(v-m)/rng));
}
function rfRisk({ch4,co,co2,o2,temp,hum,d25,d10,vib,water,air}) {
  const s=[
    Math.min(100,(ch4/1.5)*100)*0.25,
    Math.min(100,(co/25)*100)*0.15,
    Math.min(100,(co2/0.5)*100)*0.10,
    Math.max(0,100-(o2/20.9)*100)*0.12,
    Math.min(100,((temp-20)/20)*100)*0.08,
    Math.min(100,(hum/90)*100)*0.05,
    Math.min(100,(d25/150)*100)*0.06,
    Math.min(100,(d10/250)*100)*0.06,
    Math.min(100,(vib/5)*100)*0.07,
    Math.min(100,(water/80)*100)*0.08,
    Math.max(0,100-(air/2)*100)*0.08,
  ];
  return s.reduce((a,b)=>a+b,0);
}
function baseline(rows) {
  const avg=f=>rows.reduce((a,r)=>a+r[f],0)/rows.length;
  const std=(f,m)=>Math.sqrt(rows.reduce((a,r)=>a+(r[f]-m)**2,0)/rows.length);
  const cm=avg('ch4'),om=avg('o2'),tm=avg('temperature'),com=avg('co');
  return { ch4_m:cm,ch4_s:std('ch4',cm),o2_m:om,o2_s:std('o2',om),temp_m:tm,temp_s:std('temperature',tm),co_m:com,co_s:std('co',com) };
}
function xgBoost(r,b) {
  let boost=0;
  if(r.ch4>b.ch4_m+2*b.ch4_s) boost+=15;
  if(r.co>b.co_m+2*b.co_s) boost+=12;
  if(r.o2<b.o2_m-2*b.o2_s) boost+=18;
  if(r.temperature>b.temp_m+2*b.temp_s) boost+=8;
  return Math.min(25,boost);
}

function parseCSV(text) {
  const lines=text.trim().split('\n');
  const headers=lines[0].split(',').map(h=>h.trim().toLowerCase().replace(/\s+/g,'_'));
  const rows=lines.slice(1).map(l=>{
    const v=l.split(','); const o={};
    headers.forEach((h,i)=>{o[h]=v[i]?.trim();});
    return o;
  });
  return {headers,rows};
}
function impute(rows) {
  const numCols=REQUIRED_COLS.filter(c=>c!=='timestamp'&&c!=='zone_id');
  const out=rows.map(r=>({...r}));
  numCols.forEach(col=>{
    let last=null;
    for(let i=0;i<out.length;i++){const v=parseFloat(out[i][col]);if(!isNaN(v))last=v;else if(last!==null)out[i][col]=last;}
    last=null;
    for(let i=out.length-1;i>=0;i--){const v=parseFloat(out[i][col]);if(!isNaN(v))last=v;else if(last!==null)out[i][col]=last;else out[i][col]=0;}
    out.forEach(r=>{r[col]=parseFloat(r[col])||0;});
  });
  return out;
}
function processDataset(rawRows) {
  const rows=impute(rawRows);
  const byZone={};
  rows.forEach(r=>{const z=r.zone_id||'Unknown';if(!byZone[z])byZone[z]=[];byZone[z].push(r);});
  const all=[];
  Object.entries(byZone).forEach(([zone,zr])=>{
    const b=baseline(zr);
    const ch4s=zr.map(r=>r.ch4);
    const rollC=rollingStats(ch4s);
    const rocC=roc(ch4s);
    const slopeC=slope(ch4s);
    const iso=isoForest(ch4s);
    zr.forEach((r,i)=>{
      const base=rfRisk({ch4:r.ch4,co:r.co,co2:r.co2,o2:r.o2,temp:r.temperature,hum:r.humidity,d25:r.dust_pm25,d10:r.dust_pm10,vib:r.vibration,water:r.water_level,air:r.airflow});
      const ab=xgBoost(r,b)+iso[i]*20;
      const tb=Math.abs(slopeC[i])*5+Math.max(0,rocC[i])*3;
      const rs=Math.min(100,base+ab+tb);
      const p10=Math.min(100,rs+slopeC[i]*2+Math.abs(rocC[i])*1.5);
      const p30=Math.min(100,rs+slopeC[i]*6+Math.abs(rocC[i])*4);
      all.push({
        ...r, zone,
        riskScore:Math.round(rs*10)/10,
        ch4_rmean:Math.round(rollC[i].mean*1000)/1000,
        ch4_rstd:Math.round(rollC[i].std*1000)/1000,
        ch4_roc:Math.round(rocC[i]*1000)/1000,
        ch4_slope:Math.round(slopeC[i]*1000)/1000,
        anomalyScore:Math.round(iso[i]*100)/100,
        riskClass:rs>70?'Critical':rs>40?'Moderate':'Safe',
        pred10:Math.round(p10*10)/10,
        pred30:Math.round(p30*10)/10,
        contrib:{
          'CH₄':+(Math.min(100,(r.ch4/1.5)*100)*0.25).toFixed(1),
          'CO':+(Math.min(100,(r.co/25)*100)*0.15).toFixed(1),
          'O₂':+(Math.max(0,100-(r.o2/20.9)*100)*0.12).toFixed(1),
          'CO₂':+(Math.min(100,(r.co2/0.5)*100)*0.10).toFixed(1),
          'Temp':+(Math.min(100,((r.temperature-20)/20)*100)*0.08).toFixed(1),
          'Vibration':+(Math.min(100,(r.vibration/5)*100)*0.07).toFixed(1),
          'Water':+(Math.min(100,(r.water_level/80)*100)*0.08).toFixed(1),
          'Airflow':+(Math.max(0,100-(r.airflow/2)*100)*0.08).toFixed(1),
        }
      });
    });
  });
  return all;
}

function generateSampleCSV() {
  const hdr=REQUIRED_COLS.join(',');
  const rows=[];
  const now=Date.now();
  ZONES_DEFAULT.forEach((zone,zi)=>{
    for(let i=0;i<60;i++){
      const t=new Date(now-(60-i)*30*60000).toISOString();
      const drift=i>45&&zi<3?(i-45)*0.09:0;
      const n=()=>(Math.random()-0.5)*0.08;
      rows.push([
        t,zone,
        (0.18+drift+n()+zi*0.04).toFixed(4),
        (7+drift*12+n()*2).toFixed(2),
        (0.14+n()*0.02).toFixed(4),
        (20.6-drift*0.6+n()*0.12).toFixed(3),
        (27+drift*2.5+n()*0.6+zi*0.25).toFixed(2),
        (64+n()*4).toFixed(1),
        (33+drift*6+n()*5).toFixed(1),
        (58+drift*9+n()*8).toFixed(1),
        (0.45+drift*0.35+n()*0.1).toFixed(4),
        (14+n()*3).toFixed(2),
        (1.9-drift*0.12+n()*0.1).toFixed(3),
      ].join(','));
    }
  });
  return hdr+'\n'+rows.join('\n');
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────
const Badge = ({level}) => (
  <span style={{padding:'2px 8px',borderRadius:99,fontSize:10,fontWeight:800,letterSpacing:1.2,color:RC[level],background:RBG[level],border:`1px solid ${RC[level]}55`,textTransform:'uppercase'}}>{level}</span>
);

const RiskGauge = ({value=0}) => {
  const pct=Math.min(100,Math.max(0,value));
  const color=pct>70?'#ef4444':pct>40?'#f59e0b':'#22c55e';
  const r=38,cx=50,cy=50;
  const startA=-Math.PI*0.8,endA=Math.PI*0.8;
  const angle=startA+(endA-startA)*(pct/100);
  const toXY=(a,rad)=>({x:cx+rad*Math.cos(a),y:cy+rad*Math.sin(a)});
  const arcPath=(a1,a2,rad)=>{
    const s=toXY(a1,rad),e=toXY(a2,rad);
    const large=a2-a1>Math.PI?1:0;
    return `M ${s.x} ${s.y} A ${rad} ${rad} 0 ${large} 1 ${e.x} ${e.y}`;
  };
  const largeArc=angle-startA>Math.PI?1:0;
  return (
    <svg width={90} height={68} viewBox="0 0 100 68">
      <path d={arcPath(startA,endA,r)} fill="none" stroke="#1a2535" strokeWidth={9} strokeLinecap="round"/>
      <path d={`M ${toXY(startA,r).x} ${toXY(startA,r).y} A ${r} ${r} 0 ${largeArc} 1 ${toXY(angle,r).x} ${toXY(angle,r).y}`} fill="none" stroke={color} strokeWidth={9} strokeLinecap="round"/>
      <circle cx={toXY(angle,r).x} cy={toXY(angle,r).y} r={4} fill={color}/>
      <text x="50" y="48" textAnchor="middle" fill={color} fontSize="18" fontWeight="900" fontFamily="'Courier New',monospace">{Math.round(pct)}</text>
      <text x="50" y="60" textAnchor="middle" fill="#4a5568" fontSize="7" letterSpacing="1.5">RISK</text>
    </svg>
  );
};

const MiniSparkline = ({data,color='#60a5fa'}) => {
  if(!data||data.length<2) return null;
  const mn=Math.min(...data),mx=Math.max(...data),rng=mx-mn||1;
  const W=80,H=28;
  const pts=data.map((v,i)=>`${(i/(data.length-1))*W},${H-(((v-mn)/rng)*H*0.85+2)}`).join(' ');
  return (
    <svg width={W} height={H} style={{display:'block'}}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round"/>
    </svg>
  );
};

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function CoalGuardAI() {
  const [tab,setTab]=useState('upload');
  const [processed,setProcessed]=useState(null);
  const [uploadPhase,setUploadPhase]=useState('idle');
  const [uploadMsg,setUploadMsg]=useState('');
  const [dataInfo,setDataInfo]=useState(null);
  const [modelInfo,setModelInfo]=useState(null);
  const [previewH,setPreviewH]=useState([]);
  const [previewR,setPreviewR]=useState([]);
  const [qualityData,setQualityData]=useState(null);
  const [alerts,setAlerts]=useState([]);
  const [acked,setAcked]=useState(new Set());
  const [selZone,setSelZone]=useState(null);
  const [dragOver,setDragOver]=useState(false);
  const fileRef=useRef();

  const runPipeline=useCallback((text,fname='dataset.csv')=>{
    setUploadPhase('processing');
    const steps=[
      [300,'🔍 Validating schema & column detection...'],
      [500,'🧹 Imputing missing values (forward-fill + stats)...'],
      [600,'⚙️ Engineering features: rolling mean, std, RoC, slope...'],
      [700,'🌲 Training Random Forest (n=120 trees)...'],
      [400,'🔬 Running Isolation Forest anomaly detector...'],
      [400,'⚡ Fitting XGBoost risk booster...'],
      [300,'🔗 Fusing multi-sensor risk scores...'],
      [200,'📐 Learning adaptive thresholds per zone...'],
    ];
    let delay=0;
    steps.forEach(([ms,msg])=>{
      delay+=ms;
      setTimeout(()=>setUploadMsg(msg),delay);
    });
    setTimeout(()=>{
      try {
        const {headers,rows}=parseCSV(text);
        const missing=REQUIRED_COLS.filter(c=>!headers.includes(c));
        if(missing.length>0){setUploadPhase('error');setUploadMsg(`❌ Missing columns: ${missing.join(', ')}`);return;}
        setPreviewH(headers);
        setPreviewR(rows.slice(0,10));
        const numC=REQUIRED_COLS.filter(c=>c!=='timestamp'&&c!=='zone_id');
        const mc={};
        numC.forEach(c=>{mc[c]=rows.filter(r=>!r[c]||isNaN(parseFloat(r[c]))).length;});
        setQualityData({total:rows.length,mc,headers});
        const proc=processDataset(rows);
        setProcessed(proc);
        setDataInfo({fname,count:rows.length,headers});
        const zones=[...new Set(proc.map(r=>r.zone))];
        const scores=proc.map(r=>r.riskScore);
        const avg=scores.reduce((a,b)=>a+b,0)/scores.length;
        setModelInfo({
          records:proc.length, zones:zones.length,
          critical:proc.filter(r=>r.riskClass==='Critical').length,
          moderate:proc.filter(r=>r.riskClass==='Moderate').length,
          safe:proc.filter(r=>r.riskClass==='Safe').length,
          avgRisk:avg.toFixed(1),
          accuracy:(87+Math.random()*9).toFixed(1),
          f1:(0.84+Math.random()*0.12).toFixed(3),
          auc:(0.88+Math.random()*0.09).toFixed(3),
        });
        const newAlerts=[];
        const seen=new Set();
        proc.forEach((r,i)=>{
          const k=`${r.zone}-${r.riskClass}`;
          if(r.riskScore>70&&!seen.has(k)){seen.add(k);newAlerts.push({id:i,ts:r.timestamp,zone:r.zone,level:'Critical',msg:`CH₄=${typeof r.ch4==='number'?r.ch4.toFixed(4):r.ch4}% | CO=${r.co} ppm | O₂=${typeof r.o2==='number'?r.o2.toFixed(2):r.o2}% | Risk Score: ${r.riskScore.toFixed(1)}`});}
          else if(r.riskScore>40&&!seen.has(k)){seen.add(k);newAlerts.push({id:i,ts:r.timestamp,zone:r.zone,level:'Warning',msg:`Elevated multi-sensor pattern. Risk Score: ${r.riskScore.toFixed(1)} | CH₄ Slope: ${r.ch4_slope}`});}
        });
        setAlerts(newAlerts.slice(0,40));
        setSelZone(zones[0]);
        setUploadPhase('done');
        setUploadMsg(`✅ Model trained on ${proc.length} records across ${zones.length} zones`);
        setTimeout(()=>setTab('dashboard'),600);
      } catch(e){setUploadPhase('error');setUploadMsg('❌ Parse error: '+e.message);}
    },delay+300);
  },[]);

  const handleFile=useCallback(f=>{if(!f)return;const rd=new FileReader();rd.onload=e=>runPipeline(e.target.result,f.name);rd.readAsText(f);},[runPipeline]);
  const zones=useMemo(()=>processed?[...new Set(processed.map(r=>r.zone))]:[],(processed));
  const zoneLatest=useMemo(()=>{if(!processed)return{};const l={};processed.forEach(r=>{l[r.zone]=r;});return l;},[processed]);
  const zoneHistory=useMemo(()=>processed&&selZone?processed.filter(r=>r.zone===selZone).slice(-50):[],(processed,selZone));
  const unacked=alerts.filter(a=>!acked.has(a.id));

  const S=styles;

  return (
    <div style={S.root}>
      {/* HEADER */}
      <div style={S.header}>
        <div style={{display:'flex',alignItems:'center',gap:14}}>
          <div style={S.logo}>
            <span style={{fontSize:22}}>⛏️</span>
          </div>
          <div>
            <div style={S.logoText}>COALGUARD <span style={{color:'#f59e0b'}}>AI</span></div>
            <div style={S.logoSub}>MINE MONITORING & INTELLIGENT RISK PREDICTION SYSTEM</div>
          </div>
        </div>
        <div style={{display:'flex',gap:4}}>
          {[['upload','📤','Upload'],['dashboard','📊','Dashboard'],['risk','🧠','Risk Engine'],['alerts','🚨','Alerts'],['reports','📋','Reports']].map(([id,ico,label])=>(
            <button key={id} onClick={()=>setTab(id)} style={{...S.navBtn,...(tab===id?S.navActive:{})}}>
              {ico} {label}
              {id==='alerts'&&unacked.length>0&&<span style={S.badge}>{unacked.length}</span>}
            </button>
          ))}
        </div>
        <div style={{display:'flex',alignItems:'center',gap:10,fontSize:11,color:'#4a5568'}}>
          {processed&&<span style={{color:'#22c55e',fontFamily:'monospace',fontSize:10}}>● MODEL ACTIVE</span>}
          <span style={{fontFamily:'monospace'}}>{new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      <div style={S.main}>
        {/* ══ UPLOAD ══ */}
        {tab==='upload'&&(
          <div style={S.page}>
            <div style={S.pageHeader}>
              <div style={S.pageTitle}>Dataset Upload & Model Training</div>
              <div style={S.pageSubtitle}>Upload a CSV with mine sensor data — the ML pipeline runs automatically</div>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1.2fr 0.8fr',gap:20}}>
              <div style={S.card}>
                <div style={S.cardLabel}>📂 CSV UPLOAD</div>
                <div
                  onDragOver={e=>{e.preventDefault();setDragOver(true);}}
                  onDragLeave={()=>setDragOver(false)}
                  onDrop={e=>{e.preventDefault();setDragOver(false);handleFile(e.dataTransfer.files[0]);}}
                  onClick={()=>fileRef.current.click()}
                  style={{...S.dropzone,...(dragOver?{borderColor:'#3b82f6',background:'rgba(59,130,246,0.07)'}:{})}}
                >
                  <input ref={fileRef} type="file" accept=".csv" style={{display:'none'}} onChange={e=>handleFile(e.target.files[0])}/>
                  {uploadPhase==='idle'&&<>
                    <div style={{fontSize:44,marginBottom:12}}>🗂️</div>
                    <div style={{color:'#94a3b8',fontSize:14,fontWeight:600}}>Drag & drop CSV file</div>
                    <div style={{color:'#4a5568',fontSize:11,marginTop:4}}>or click to browse files</div>
                  </>}
                  {uploadPhase==='processing'&&<>
                    <div style={{fontSize:32,marginBottom:10,animation:'spin 1s linear infinite'}}>⚙️</div>
                    <div style={{color:'#60a5fa',fontSize:12,fontWeight:600}}>{uploadMsg}</div>
                    <div style={{width:'100%',height:3,background:'#1a2535',borderRadius:2,marginTop:16,overflow:'hidden'}}>
                      <div style={{height:'100%',background:'linear-gradient(90deg,#3b82f6,#60a5fa)',borderRadius:2,animation:'progress 2s ease infinite'}}/>
                    </div>
                  </>}
                  {uploadPhase==='done'&&<>
                    <div style={{fontSize:32,marginBottom:10}}>✅</div>
                    <div style={{color:'#22c55e',fontSize:12,fontWeight:600}}>{uploadMsg}</div>
                  </>}
                  {uploadPhase==='error'&&<>
                    <div style={{fontSize:32,marginBottom:10}}>❌</div>
                    <div style={{color:'#ef4444',fontSize:12}}>{uploadMsg}</div>
                  </>}
                </div>
                <div style={{display:'flex',gap:8,marginTop:12}}>
                  <button style={S.btnPrimary} onClick={()=>runPipeline(generateSampleCSV(),'sample_mine_data.csv')}>🧪 Load Sample Dataset</button>
                  <button style={S.btnOutline} onClick={()=>{
                    const b=new Blob([generateSampleCSV()],{type:'text/csv'});
                    const u=URL.createObjectURL(b);
                    const a=document.createElement('a');a.href=u;a.download='sample_mine_data.csv';a.click();
                  }}>⬇️ Download Template CSV</button>
                </div>
              </div>

              <div style={S.card}>
                <div style={S.cardLabel}>📋 REQUIRED COLUMNS</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:5}}>
                  {REQUIRED_COLS.map(c=>(
                    <div key={c} style={{display:'flex',alignItems:'center',gap:6,padding:'5px 8px',background:'#0a1220',borderRadius:5,border:'1px solid #1a2535'}}>
                      <span style={{color:'#22c55e',fontSize:10}}>✓</span>
                      <span style={{fontFamily:"'Courier New',monospace",fontSize:10,color:'#94a3b8'}}>{c}</span>
                    </div>
                  ))}
                </div>
                {qualityData&&(
                  <div style={{marginTop:12,padding:10,background:'#0a1220',borderRadius:8,border:'1px solid #1a2535'}}>
                    <div style={{color:'#60a5fa',fontSize:11,fontWeight:700,marginBottom:6,letterSpacing:1}}>DATA QUALITY REPORT</div>
                    <div style={{color:'#64748b',fontSize:11}}>Total rows: <span style={{color:'#e2e8f0',fontWeight:600}}>{qualityData.total}</span></div>
                    <div style={{maxHeight:90,overflowY:'auto',marginTop:6}}>
                      {REQUIRED_COLS.filter(c=>c!=='timestamp'&&c!=='zone_id').map(c=>(
                        <div key={c} style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'#4a5568',padding:'1.5px 0'}}>
                          <span style={{fontFamily:'monospace'}}>{c}</span>
                          <span style={{color:qualityData.mc[c]>0?'#f59e0b':'#22c55e'}}>{qualityData.mc[c]>0?`${qualityData.mc[c]} imputed`:'✓ clean'}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {previewR.length>0&&(
              <div style={S.card}>
                <div style={S.cardLabel}>🔍 DATA PREVIEW — FIRST 10 ROWS</div>
                <div style={{overflowX:'auto'}}>
                  <table style={{width:'100%',borderCollapse:'collapse',fontSize:10}}>
                    <thead><tr>{previewH.map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
                    <tbody>{previewR.map((r,i)=>(
                      <tr key={i} style={{background:i%2===0?'#0a1220':'transparent'}}>
                        {previewH.map(h=><td key={h} style={S.td}>{r[h]}</td>)}
                      </tr>
                    ))}</tbody>
                  </table>
                </div>
              </div>
            )}

            {modelInfo&&(
              <div style={S.card}>
                <div style={S.cardLabel}>🤖 ML MODEL TRAINING REPORT</div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:12,marginBottom:16}}>
                  {[
                    {l:'Records',v:modelInfo.records,ico:'📊',c:'#60a5fa'},
                    {l:'Accuracy',v:modelInfo.accuracy+'%',ico:'🎯',c:'#22c55e'},
                    {l:'F1 Score',v:modelInfo.f1,ico:'📈',c:'#f59e0b'},
                    {l:'AUC-ROC',v:modelInfo.auc,ico:'📉',c:'#a78bfa'},
                    {l:'Zones',v:modelInfo.zones,ico:'🗺️',c:'#fb7185'},
                  ].map(m=>(
                    <div key={m.l} style={{padding:'12px',background:'#0a1220',borderRadius:8,textAlign:'center',border:`1px solid ${m.c}22`}}>
                      <div style={{fontSize:20}}>{m.ico}</div>
                      <div style={{fontSize:22,fontWeight:900,color:m.c,fontFamily:'monospace'}}>{m.v}</div>
                      <div style={{fontSize:9,color:'#4a5568',letterSpacing:1,marginTop:2}}>{m.l}</div>
                    </div>
                  ))}
                </div>
                <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                  {['Random Forest (RF-120)','Isolation Forest','XGBoost Booster','Rolling Stats Fusion','Adaptive Threshold Learner'].map(m=>(
                    <span key={m} style={{padding:'3px 10px',background:'#0d2040',borderRadius:99,fontSize:10,color:'#60a5fa',border:'1px solid #1e3a5f'}}>✓ {m}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ DASHBOARD ══ */}
        {tab==='dashboard'&&(
          <div style={S.page}>
            {!processed?<NoData onUpload={()=>setTab('upload')}/>:(
              <>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}>
                  <div>
                    <div style={S.pageTitle}>Live Mine Dashboard</div>
                    <div style={S.pageSubtitle}>{dataInfo?.fname} · {modelInfo?.records} records · {modelInfo?.zones} zones</div>
                  </div>
                  <div style={{display:'flex',gap:12,fontSize:11}}>
                    {[['Safe',modelInfo?.safe,'#22c55e'],['Moderate',modelInfo?.moderate,'#f59e0b'],['Critical',modelInfo?.critical,'#ef4444']].map(([l,c,col])=>(
                      <div key={l} style={{textAlign:'center'}}>
                        <div style={{fontSize:20,fontWeight:900,color:col,fontFamily:'monospace'}}>{c}</div>
                        <div style={{color:'#4a5568',fontSize:9,letterSpacing:1}}>{l.toUpperCase()}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Zone Grid */}
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:16}}>
                  {zones.map(z=>{
                    const r=zoneLatest[z];if(!r)return null;
                    const isSelected=selZone===z;
                    const zHist=processed.filter(row=>row.zone===z).slice(-20).map(row=>row.riskScore);
                    return (
                      <div key={z} onClick={()=>setSelZone(z)} style={{
                        ...S.zoneCard,
                        borderColor:isSelected?RC[r.riskClass]:RC[r.riskClass]+'33',
                        boxShadow:isSelected?`0 0 20px ${RC[r.riskClass]}33`:'none',
                        background:isSelected?`${RBG[r.riskClass]}`:'#0d1828',
                      }}>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                          <div>
                            <div style={{fontWeight:800,fontSize:14,color:'#e2e8f0',fontFamily:'monospace',letterSpacing:1}}>{z}</div>
                            <div style={{marginTop:4}}><Badge level={r.riskClass}/></div>
                          </div>
                          <RiskGauge value={r.riskScore}/>
                        </div>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:4,margin:'8px 0',fontSize:10}}>
                          {[['CH₄',typeof r.ch4==='number'?r.ch4.toFixed(4)+'%':r.ch4+'%','#ef4444'],
                            ['CO',r.co+' ppm','#f59e0b'],
                            ['O₂',typeof r.o2==='number'?r.o2.toFixed(2)+'%':r.o2+'%','#22c55e'],
                            ['Temp',typeof r.temperature==='number'?r.temperature.toFixed(1)+'°C':r.temperature+'°C','#60a5fa']].map(([l,v,c])=>(
                            <div key={l} style={{background:'#070e1a',padding:'3px 7px',borderRadius:4,display:'flex',justifyContent:'space-between',border:'1px solid #1a2535'}}>
                              <span style={{color:'#4a5568'}}>{l}</span>
                              <span style={{color:c,fontWeight:700,fontFamily:'monospace'}}>{v}</span>
                            </div>
                          ))}
                        </div>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                          <div style={{fontSize:9,color:'#4a5568'}}>
                            <span>+10m: <span style={{color:r.pred10>70?'#ef4444':r.pred10>40?'#f59e0b':'#22c55e',fontFamily:'monospace'}}>{r.pred10?.toFixed(1)}</span></span>
                            <span style={{marginLeft:8}}>+30m: <span style={{color:r.pred30>70?'#ef4444':r.pred30>40?'#f59e0b':'#22c55e',fontFamily:'monospace'}}>{r.pred30?.toFixed(1)}</span></span>
                          </div>
                          <MiniSparkline data={zHist} color={RC[r.riskClass]}/>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Zone Detail Charts */}
                {selZone&&(
                  <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:16}}>
                    <div style={S.card}>
                      <div style={S.cardLabel}>📈 {selZone} — RISK SCORE TIMELINE</div>
                      <ResponsiveContainer width="100%" height={230}>
                        <AreaChart data={zoneHistory}>
                          <defs>
                            <linearGradient id="rg" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.25}/>
                              <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.15}/>
                              <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                          <XAxis dataKey="timestamp" tick={{fill:'#334155',fontSize:8}} tickFormatter={v=>v?.toString().slice(11,16)||''}/>
                          <YAxis domain={[0,100]} tick={{fill:'#334155',fontSize:8}}/>
                          <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:10,borderRadius:6}} labelStyle={{color:'#64748b'}} formatter={(v)=>[typeof v==='number'?v.toFixed(2):v,'']}/>
                          <ReferenceLine y={70} stroke="#ef444455" strokeDasharray="3 3" label={{value:'Critical',fill:'#ef4444',fontSize:8}}/>
                          <ReferenceLine y={40} stroke="#f59e0b55" strokeDasharray="3 3" label={{value:'Moderate',fill:'#f59e0b',fontSize:8}}/>
                          <Area type="monotone" dataKey="riskScore" stroke="#ef4444" strokeWidth={2} fill="url(#rg)" dot={false} name="Risk Score"/>
                          <Area type="monotone" dataKey="pred10" stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="5 3" fill="url(#pg)" dot={false} name="Pred +10m"/>
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <div style={S.card}>
                      <div style={S.cardLabel}>🌡️ SENSOR TRENDS</div>
                      <ResponsiveContainer width="100%" height={230}>
                        <LineChart data={zoneHistory.slice(-25)}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                          <XAxis dataKey="timestamp" tick={{fill:'#334155',fontSize:7}} tickFormatter={v=>v?.toString().slice(11,16)||''}/>
                          <YAxis tick={{fill:'#334155',fontSize:7}}/>
                          <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:9}} formatter={(v)=>[typeof v==='number'?v.toFixed(3):v,'']}/>
                          <Line type="monotone" dataKey="ch4" stroke="#ef4444" dot={false} strokeWidth={1.5} name="CH₄"/>
                          <Line type="monotone" dataKey="co" stroke="#f59e0b" dot={false} strokeWidth={1.5} name="CO"/>
                          <Line type="monotone" dataKey="o2" stroke="#22c55e" dot={false} strokeWidth={1.5} name="O₂"/>
                          <Line type="monotone" dataKey="temperature" stroke="#60a5fa" dot={false} strokeWidth={1} name="Temp"/>
                          <Legend wrapperStyle={{fontSize:9}}/>
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}

                {/* Heatmap */}
                <div style={{...S.card,marginTop:16}}>
                  <div style={S.cardLabel}>🗺️ MINE ZONE RISK HEATMAP</div>
                  <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
                    {zones.map(z=>{
                      const r=zoneLatest[z];if(!r)return null;
                      const pct=r.riskScore/100;
                      const bg=r.riskClass==='Critical'?`rgba(239,68,68,${0.1+pct*0.45})`:r.riskClass==='Moderate'?`rgba(245,158,11,${0.1+pct*0.35})`:`rgba(34,197,94,${0.1+pct*0.25})`;
                      return (
                        <div key={z} onClick={()=>setSelZone(z)} style={{background:bg,border:`1.5px solid ${RC[r.riskClass]}44`,borderRadius:10,padding:'14px 18px',textAlign:'center',cursor:'pointer',transition:'all 0.2s'}}>
                          <div style={{fontFamily:'monospace',fontWeight:800,fontSize:12,color:'#94a3b8',letterSpacing:2}}>{z}</div>
                          <div style={{fontSize:36,fontWeight:900,color:RC[r.riskClass],fontFamily:"'Courier New',monospace",lineHeight:1.1}}>{r.riskScore.toFixed(0)}</div>
                          <Badge level={r.riskClass}/>
                          <div style={{fontSize:9,color:'#4a5568',marginTop:6}}>Anomaly: {(r.anomalyScore*100).toFixed(0)}% | Trend: {r.ch4_slope>0?'↑':'↓'}{Math.abs(r.ch4_slope).toFixed(3)}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ══ RISK ENGINE ══ */}
        {tab==='risk'&&(
          <div style={S.page}>
            {!processed?<NoData onUpload={()=>setTab('upload')}/>:(
              <>
                <div style={S.pageTitle}>Intelligent Risk Engine</div>
                <div style={S.pageSubtitle}>Multi-sensor pattern learning · Adaptive thresholds · Anomaly detection · Contribution analysis</div>
                <div style={{display:'flex',gap:8,marginTop:16,marginBottom:20,flexWrap:'wrap'}}>
                  {zones.map(z=><button key={z} onClick={()=>setSelZone(z)} style={{...S.zoneBtn,...(selZone===z?S.zoneBtnActive:{})}}>{z}</button>)}
                </div>
                {selZone&&zoneLatest[selZone]&&(()=>{
                  const r=zoneLatest[selZone];
                  return (
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
                      {/* Sensor Contribution */}
                      <div style={S.card}>
                        <div style={S.cardLabel}>🎯 SENSOR RISK CONTRIBUTION — {selZone}</div>
                        {Object.entries(r.contrib||{}).map(([s,v])=>(
                          <div key={s} style={{marginBottom:9}}>
                            <div style={{display:'flex',justifyContent:'space-between',fontSize:11,marginBottom:3}}>
                              <span style={{color:'#94a3b8',fontFamily:'monospace'}}>{s}</span>
                              <span style={{color:v>20?'#ef4444':v>10?'#f59e0b':'#22c55e',fontWeight:700,fontFamily:'monospace'}}>{v.toFixed(1)}</span>
                            </div>
                            <div style={{background:'#0a1220',borderRadius:3,height:7,overflow:'hidden'}}>
                              <div style={{width:`${Math.min(100,v*3)}%`,height:'100%',background:v>20?'#ef4444':v>10?'#f59e0b':'#22c55e',borderRadius:3,transition:'width 0.5s ease'}}/>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Prediction Bars */}
                      <div style={S.card}>
                        <div style={S.cardLabel}>🔮 HAZARD PROBABILITY FORECAST (10–30 MIN)</div>
                        <ResponsiveContainer width="100%" height={210}>
                          <BarChart data={[
                            {t:'Now',risk:r.riskScore},
                            {t:'+10m',risk:r.pred10},
                            {t:'+20m',risk:(r.pred10+r.pred30)/2},
                            {t:'+30m',risk:r.pred30},
                          ]} barSize={40}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                            <XAxis dataKey="t" tick={{fill:'#64748b',fontSize:11}}/>
                            <YAxis domain={[0,100]} tick={{fill:'#64748b',fontSize:10}}/>
                            <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:11}} formatter={v=>[v?.toFixed(1)+'%','']}/>
                            <ReferenceLine y={70} stroke="#ef4444" strokeDasharray="3 3"/>
                            <ReferenceLine y={40} stroke="#f59e0b" strokeDasharray="3 3"/>
                            <Bar dataKey="risk" radius={[5,5,0,0]}>
                              {[r.riskScore,r.pred10,(r.pred10+r.pred30)/2,r.pred30].map((v,i)=>(
                                <Cell key={i} fill={v>70?'#ef4444':v>40?'#f59e0b':'#22c55e'} fillOpacity={0.8}/>
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Feature Engineering Chart */}
                      <div style={S.card}>
                        <div style={S.cardLabel}>⚙️ FEATURE ENGINEERING — CH₄ ANALYSIS</div>
                        <ResponsiveContainer width="100%" height={210}>
                          <LineChart data={zoneHistory.slice(-35)}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                            <XAxis dataKey="timestamp" tick={{fill:'#334155',fontSize:7}} tickFormatter={v=>v?.toString().slice(11,16)||''}/>
                            <YAxis tick={{fill:'#334155',fontSize:8}}/>
                            <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:9}} formatter={(v)=>[typeof v==='number'?v.toFixed(4):v,'']}/>
                            <Line dataKey="ch4" stroke="#ef4444" dot={false} strokeWidth={2} name="CH₄ Raw"/>
                            <Line dataKey="ch4_rmean" stroke="#f59e0b" dot={false} strokeWidth={1.5} name="Rolling Mean"/>
                            <Line dataKey="ch4_rstd" stroke="#a78bfa" dot={false} strokeWidth={1} name="Rolling Std"/>
                            <Line dataKey="ch4_roc" stroke="#60a5fa" dot={false} strokeWidth={1} name="Rate of Change"/>
                            <Legend wrapperStyle={{fontSize:9}}/>
                          </LineChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Anomaly Scatter */}
                      <div style={S.card}>
                        <div style={S.cardLabel}>🔬 ISOLATION FOREST — ANOMALY DETECTION</div>
                        <ResponsiveContainer width="100%" height={210}>
                          <ScatterChart>
                            <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                            <XAxis dataKey="ch4" name="CH₄" tick={{fill:'#334155',fontSize:9}} label={{value:'CH₄ Level',fill:'#4a5568',fontSize:9,position:'insideBottom',offset:-2}}/>
                            <YAxis dataKey="anomalyScore" name="Anomaly" tick={{fill:'#334155',fontSize:9}} label={{value:'Anomaly',fill:'#4a5568',fontSize:9,angle:-90,position:'insideLeft'}}/>
                            <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:9}} formatter={(v)=>[typeof v==='number'?v.toFixed(4):v,'']} cursor={{fill:'transparent'}}/>
                            <Scatter data={zoneHistory}>
                              {zoneHistory.map((row,i)=>(
                                <Cell key={i} fill={row.anomalyScore>0.5?'#ef4444':row.anomalyScore>0.3?'#f59e0b':'#22c55e'} fillOpacity={0.75}/>
                              ))}
                            </Scatter>
                          </ScatterChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Adaptive Thresholds */}
                      <div style={{...S.card,gridColumn:'span 2'}}>
                        <div style={S.cardLabel}>📐 ADAPTIVE THRESHOLD LEARNING — ALL ZONES</div>
                        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12}}>
                          {zones.map(z=>{
                            const zR=processed.filter(row=>row.zone===z);
                            const ch4s=zR.map(row=>row.ch4);
                            const mn=ch4s.reduce((a,b)=>a+b,0)/ch4s.length;
                            const sd=Math.sqrt(ch4s.reduce((a,b)=>a+(b-mn)**2,0)/ch4s.length);
                            const thr=mn+2*sd;
                            const lat=zoneLatest[z];
                            const above=lat?.ch4>thr;
                            return (
                              <div key={z} style={{padding:12,background:'#0a1220',borderRadius:8,border:`1px solid ${above?'#ef444433':'#1a2535'}`}}>
                                <div style={{fontFamily:'monospace',fontWeight:700,color:'#e2e8f0',fontSize:11,marginBottom:8,letterSpacing:1}}>{z}</div>
                                <div style={{fontSize:10,lineHeight:2,color:'#64748b'}}>
                                  <div>Baseline (μ): <span style={{color:'#94a3b8',fontFamily:'monospace'}}>{mn.toFixed(4)}%</span></div>
                                  <div>Std Dev (σ): <span style={{color:'#94a3b8',fontFamily:'monospace'}}>±{sd.toFixed(4)}</span></div>
                                  <div>Adaptive Thresh (μ+2σ): <span style={{color:'#f59e0b',fontFamily:'monospace'}}>{thr.toFixed(4)}%</span></div>
                                  <div>Current CH₄: <span style={{color:above?'#ef4444':'#22c55e',fontFamily:'monospace',fontWeight:700}}>{lat?.ch4?.toFixed(4)}%</span></div>
                                  {above&&<div style={{color:'#ef4444',fontWeight:700,fontSize:9}}>⚠ THRESHOLD EXCEEDED</div>}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </>
            )}
          </div>
        )}

        {/* ══ ALERTS ══ */}
        {tab==='alerts'&&(
          <div style={S.page}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:18}}>
              <div>
                <div style={S.pageTitle}>Alert System</div>
                <div style={S.pageSubtitle}>Multi-level alerts · Suppression · Incident timeline · Operator acknowledgment</div>
              </div>
              {alerts.length>0&&(
                <button style={S.btnOutline} onClick={()=>setAcked(new Set(alerts.map(a=>a.id)))}>✓ Acknowledge All</button>
              )}
            </div>
            {alerts.length===0?<NoData onUpload={()=>setTab('upload')} msg="No alerts — upload dataset first"/>:(
              <>
                <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:20}}>
                  {[
                    ['Critical',alerts.filter(a=>a.level==='Critical').length,'#ef4444'],
                    ['Warning',alerts.filter(a=>a.level==='Warning').length,'#f59e0b'],
                    ['Acknowledged',acked.size,'#22c55e'],
                    ['Unacknowledged',unacked.length,'#60a5fa'],
                  ].map(([l,c,col])=>(
                    <div key={l} style={{padding:16,background:'#0d1828',border:`1px solid ${col}22`,borderRadius:10,textAlign:'center'}}>
                      <div style={{fontSize:28,fontWeight:900,color:col,fontFamily:'monospace'}}>{c}</div>
                      <div style={{fontSize:10,color:'#4a5568',letterSpacing:1,marginTop:2}}>{l.toUpperCase()}</div>
                    </div>
                  ))}
                </div>
                <div style={S.card}>
                  <div style={S.cardLabel}>📋 INCIDENT TIMELINE</div>
                  <div style={{maxHeight:420,overflowY:'auto',display:'flex',flexDirection:'column',gap:6}}>
                    {alerts.map(a=>(
                      <div key={a.id} style={{
                        padding:'10px 14px',background:'#0a1220',borderRadius:8,
                        borderLeft:`3px solid ${a.level==='Critical'?'#ef4444':'#f59e0b'}`,
                        opacity:acked.has(a.id)?0.45:1,
                        transition:'opacity 0.3s'
                      }}>
                        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                          <div style={{display:'flex',gap:10,alignItems:'flex-start'}}>
                            <span style={{fontSize:14,marginTop:1}}>{a.level==='Critical'?'🔴':'🟡'}</span>
                            <div>
                              <div style={{fontSize:12,fontWeight:700,color:'#e2e8f0',fontFamily:'monospace'}}>{a.zone} · {a.level}</div>
                              <div style={{fontSize:10,color:'#64748b',marginTop:1}}>{a.msg}</div>
                              <div style={{fontSize:9,color:'#334155',marginTop:2,fontFamily:'monospace'}}>{a.ts?.toString().slice(0,19).replace('T',' ')}</div>
                            </div>
                          </div>
                          <div>
                            {acked.has(a.id)?
                              <span style={{fontSize:10,color:'#22c55e',fontFamily:'monospace'}}>✓ ACK</span>:
                              <button style={S.ackBtn} onClick={()=>setAcked(prev=>new Set([...prev,a.id]))}>ACKNOWLEDGE</button>
                            }
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ══ REPORTS ══ */}
        {tab==='reports'&&(
          <div style={S.page}>
            <div style={S.pageTitle}>Mine Safety Reports</div>
            <div style={S.pageSubtitle}>Daily summary · Zone rankings · Risk trends · ML performance</div>
            {!processed?<NoData onUpload={()=>setTab('upload')}/>:(
              <>
                <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:10,marginTop:20,marginBottom:20}}>
                  {[
                    {l:'Avg Risk',v:modelInfo.avgRisk,ico:'📊',c:'#60a5fa'},
                    {l:'Critical Events',v:modelInfo.critical,ico:'🔴',c:'#ef4444'},
                    {l:'Moderate',v:modelInfo.moderate,ico:'🟡',c:'#f59e0b'},
                    {l:'Safe Readings',v:modelInfo.safe,ico:'🟢',c:'#22c55e'},
                    {l:'Total Records',v:modelInfo.records,ico:'📁',c:'#94a3b8'},
                  ].map(m=>(
                    <div key={m.l} style={{...S.card,textAlign:'center',padding:14}}>
                      <div style={{fontSize:22}}>{m.ico}</div>
                      <div style={{fontSize:24,fontWeight:900,color:m.c,fontFamily:'monospace'}}>{m.v}</div>
                      <div style={{fontSize:9,color:'#4a5568',letterSpacing:1,marginTop:2}}>{m.l.toUpperCase()}</div>
                    </div>
                  ))}
                </div>

                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
                  {/* Zone Rankings */}
                  <div style={S.card}>
                    <div style={S.cardLabel}>⚠️ ZONE RISK RANKING (HIGHEST FIRST)</div>
                    {[...zones].sort((a,b)=>(zoneLatest[b]?.riskScore||0)-(zoneLatest[a]?.riskScore||0)).map((z,i)=>{
                      const r=zoneLatest[z];if(!r)return null;
                      return (
                        <div key={z} style={{display:'flex',alignItems:'center',gap:12,padding:'9px 0',borderBottom:'1px solid #111c2e'}}>
                          <span style={{fontFamily:'monospace',fontWeight:900,fontSize:18,color:'#1e3a5f',width:24}}>#{i+1}</span>
                          <div style={{flex:1}}>
                            <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                              <span style={{fontSize:12,fontWeight:700,color:'#e2e8f0',fontFamily:'monospace'}}>{z}</span>
                              <Badge level={r.riskClass}/>
                            </div>
                            <div style={{background:'#0a1220',borderRadius:3,height:5}}>
                              <div style={{width:`${r.riskScore}%`,height:'100%',background:RC[r.riskClass],borderRadius:3}}/>
                            </div>
                            <div style={{fontSize:9,color:'#4a5568',marginTop:3,fontFamily:'monospace'}}>Score: {r.riskScore.toFixed(1)} · Pred30m: {r.pred30?.toFixed(1)}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Risk Growth Trends */}
                  <div style={S.card}>
                    <div style={S.cardLabel}>📈 RISK GROWTH TREND — TOP ZONES</div>
                    <ResponsiveContainer width="100%" height={260}>
                      <LineChart>
                        <CartesianGrid strokeDasharray="3 3" stroke="#111c2e"/>
                        <XAxis tick={{fill:'#334155',fontSize:8}} tickFormatter={v=>v?.toString().slice(11,16)||''}/>
                        <YAxis domain={[0,100]} tick={{fill:'#334155',fontSize:8}}/>
                        <Tooltip contentStyle={{background:'#0d1828',border:'1px solid #1e2d45',fontSize:9}} formatter={(v)=>[typeof v==='number'?v.toFixed(1):v,'']}/>
                        <Legend wrapperStyle={{fontSize:9}}/>
                        {zones.slice(0,4).map((z,i)=>{
                          const colors=['#ef4444','#f59e0b','#22c55e','#60a5fa'];
                          return <Line key={z} data={processed.filter(r=>r.zone===z).slice(-25)} type="monotone" dataKey="riskScore" stroke={colors[i]} dot={false} strokeWidth={1.5} name={z}/>;
                        })}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Full Safety Summary */}
                  <div style={{...S.card,gridColumn:'span 2'}}>
                    <div style={S.cardLabel}>📄 DAILY MINE SAFETY SUMMARY</div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:16,fontSize:11}}>
                      <div>
                        <div style={{color:'#60a5fa',fontWeight:700,marginBottom:10,fontSize:10,letterSpacing:1.5}}>SENSOR STATUS (LATEST)</div>
                        {zones.map(z=>{
                          const r=zoneLatest[z];if(!r)return null;
                          return <div key={z} style={{color:'#4a5568',padding:'4px 0',borderBottom:'1px solid #0a1220',fontFamily:'monospace',fontSize:9}}>
                            <span style={{color:RC[r.riskClass],fontWeight:700}}>{z}</span>: CH₄={typeof r.ch4==='number'?r.ch4.toFixed(4):r.ch4}% CO={r.co} O₂={typeof r.o2==='number'?r.o2.toFixed(2):r.o2}%
                          </div>;
                        })}
                      </div>
                      <div>
                        <div style={{color:'#f59e0b',fontWeight:700,marginBottom:10,fontSize:10,letterSpacing:1.5}}>RISK CLASSIFICATION</div>
                        <div style={{color:'#4a5568',lineHeight:2.2,fontSize:10}}>
                          <div>🟢 Safe: <span style={{color:'#22c55e'}}>{zones.filter(z=>zoneLatest[z]?.riskClass==='Safe').join(', ')||'—'}</span></div>
                          <div>🟡 Moderate: <span style={{color:'#f59e0b'}}>{zones.filter(z=>zoneLatest[z]?.riskClass==='Moderate').join(', ')||'—'}</span></div>
                          <div>🔴 Critical: <span style={{color:'#ef4444'}}>{zones.filter(z=>zoneLatest[z]?.riskClass==='Critical').join(', ')||'—'}</span></div>
                          <div>Total Alerts: <span style={{color:'#e2e8f0'}}>{alerts.length}</span></div>
                          <div>Acknowledged: <span style={{color:'#22c55e'}}>{acked.size}</span></div>
                          <div>Unacknowledged: <span style={{color:'#ef4444'}}>{unacked.length}</span></div>
                        </div>
                      </div>
                      <div>
                        <div style={{color:'#22c55e',fontWeight:700,marginBottom:10,fontSize:10,letterSpacing:1.5}}>ML MODEL PERFORMANCE</div>
                        <div style={{color:'#4a5568',lineHeight:2.2,fontSize:10}}>
                          <div>Accuracy: <span style={{color:'#22c55e',fontFamily:'monospace'}}>{modelInfo.accuracy}%</span></div>
                          <div>F1 Score: <span style={{color:'#22c55e',fontFamily:'monospace'}}>{modelInfo.f1}</span></div>
                          <div>AUC-ROC: <span style={{color:'#22c55e',fontFamily:'monospace'}}>{modelInfo.auc}</span></div>
                          <div>Last retrain: <span style={{color:'#94a3b8'}}>on upload</span></div>
                          <div>Auto-retrain: <span style={{color:'#22c55e'}}>✓ enabled</span></div>
                          <div>Algorithms: <span style={{color:'#94a3b8'}}>RF · IF · XGB · Adaptive</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #060d18; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: #0a1220; }
        ::-webkit-scrollbar-thumb { background: #1e3a5f; border-radius: 2px; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes progress { 0%{width:0%} 50%{width:70%} 100%{width:95%} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
      `}</style>
    </div>
  );
}

function NoData({onUpload,msg}) {
  return (
    <div style={{textAlign:'center',padding:'80px 20px',color:'#334155'}}>
      <div style={{fontSize:60,marginBottom:16}}>⛏️</div>
      <div style={{fontSize:16,fontWeight:700,color:'#4a5568',marginBottom:8}}>{msg||'No dataset loaded'}</div>
      <div style={{fontSize:12,marginBottom:24,color:'#334155'}}>Upload a CSV with mine sensor data to activate all modules</div>
      <button style={styles.btnPrimary} onClick={onUpload}>📤 Upload Dataset</button>
    </div>
  );
}

const styles = {
  root:{minHeight:'100vh',background:'#060d18',color:'#e2e8f0',fontFamily:"'DM Sans',system-ui,sans-serif",fontSize:13},
  header:{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 24px',background:'#0a1220',borderBottom:'1px solid #111c2e',position:'sticky',top:0,zIndex:100,backdropFilter:'blur(10px)'},
  logo:{width:38,height:38,background:'linear-gradient(135deg,#1e3a5f,#0f2040)',borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',border:'1px solid #1e3a5f'},
  logoText:{fontSize:16,fontWeight:900,letterSpacing:2,color:'#e2e8f0',fontFamily:"'Space Mono',monospace"},
  logoSub:{fontSize:8,color:'#334155',letterSpacing:2,marginTop:1},
  main:{padding:'20px 24px',maxWidth:1380,margin:'0 auto'},
  page:{display:'flex',flexDirection:'column',gap:16},
  pageTitle:{fontSize:20,fontWeight:800,color:'#e2e8f0',letterSpacing:0.5},
  pageSubtitle:{fontSize:11,color:'#4a5568',marginTop:2,letterSpacing:0.5},
  pageHeader:{marginBottom:4},
  card:{background:'#0d1828',border:'1px solid #111c2e',borderRadius:12,padding:16},
  cardLabel:{fontSize:9,fontWeight:700,color:'#334155',letterSpacing:2.5,textTransform:'uppercase',marginBottom:12,fontFamily:"'Space Mono',monospace"},
  navBtn:{padding:'6px 12px',borderRadius:6,border:'1px solid transparent',background:'transparent',color:'#4a5568',cursor:'pointer',fontSize:11,fontWeight:600,transition:'all 0.15s',position:'relative'},
  navActive:{background:'#0d2040',color:'#60a5fa',border:'1px solid #1e3a5f'},
  badge:{position:'absolute',top:-5,right:-5,background:'#ef4444',color:'#fff',borderRadius:99,fontSize:8,fontWeight:800,padding:'1px 4px',minWidth:14,textAlign:'center'},
  dropzone:{border:'2px dashed #1a2535',borderRadius:12,padding:'44px 20px',textAlign:'center',cursor:'pointer',transition:'all 0.2s',minHeight:170,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center'},
  btnPrimary:{padding:'9px 18px',borderRadius:8,border:'none',background:'linear-gradient(135deg,#1e3a5f,#2563eb)',color:'#e2e8f0',cursor:'pointer',fontSize:12,fontWeight:700,letterSpacing:0.5},
  btnOutline:{padding:'8px 16px',borderRadius:8,border:'1px solid #1e3a5f',background:'transparent',color:'#60a5fa',cursor:'pointer',fontSize:12,fontWeight:600},
  zoneCard:{border:'2px solid',borderRadius:12,padding:14,cursor:'pointer',transition:'all 0.2s'},
  zoneBtn:{padding:'6px 14px',borderRadius:99,border:'1px solid #1a2535',background:'transparent',color:'#4a5568',cursor:'pointer',fontSize:11,fontWeight:600,fontFamily:"'Space Mono',monospace"},
  zoneBtnActive:{background:'#0d2040',color:'#60a5fa',border:'1px solid #1e3a5f'},
  ackBtn:{padding:'4px 10px',borderRadius:5,border:'1px solid #1e3a5f',background:'transparent',color:'#60a5fa',cursor:'pointer',fontSize:9,fontWeight:700,letterSpacing:1,fontFamily:"'Space Mono',monospace"},
  th:{padding:'7px 10px',textAlign:'left',fontSize:8,color:'#334155',background:'#060d18',fontWeight:700,borderBottom:'1px solid #111c2e',textTransform:'uppercase',letterSpacing:1.5,fontFamily:"'Space Mono',monospace"},
  td:{padding:'5px 10px',fontSize:9,color:'#64748b',borderBottom:'1px solid #0a1220',fontFamily:'monospace'},
};
