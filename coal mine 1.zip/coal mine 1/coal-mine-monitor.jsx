
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, ScatterChart, Scatter
} from "recharts";

// ─── UTILS & ML ENGINE ──────────────────────────────────────────────────────

const SENSORS = ["CH4","CO","CO2","O2","Temperature","Humidity","Dust","Vibration","WaterLevel","Airflow"];
const SENSOR_WEIGHTS = { CH4:0.22, CO:0.18, CO2:0.12, O2:0.15, Temperature:0.10, Humidity:0.05, Dust:0.07, Vibration:0.06, WaterLevel:0.03, Airflow:0.02 };
const SENSOR_THRESHOLDS = {
  CH4:     { safe:[0,0.5],  moderate:[0.5,1.0], critical:[1.0,Infinity], unit:"%" },
  CO:      { safe:[0,25],   moderate:[25,50],   critical:[50,Infinity],  unit:"ppm" },
  CO2:     { safe:[0,0.5],  moderate:[0.5,1.5], critical:[1.5,Infinity], unit:"%" },
  O2:      { safe:[19.5,23],moderate:[18,19.5], critical:[0,18],         unit:"%" },
  Temperature:{ safe:[0,30],moderate:[30,40],   critical:[40,Infinity],  unit:"°C" },
  Humidity:{ safe:[40,80],  moderate:[80,90],   critical:[90,Infinity],  unit:"%" },
  Dust:    { safe:[0,50],   moderate:[50,150],  critical:[150,Infinity], unit:"µg/m³" },
  Vibration:{ safe:[0,2],   moderate:[2,5],     critical:[5,Infinity],   unit:"mm/s" },
  WaterLevel:{ safe:[0,30], moderate:[30,60],   critical:[60,Infinity],  unit:"cm" },
  Airflow: { safe:[2,Infinity],moderate:[1,2],  critical:[0,1],          unit:"m/s" },
};

function parseCSV(text) {
  const lines = text.trim().split("\n");
  const headers = lines[0].split(",").map(h => h.trim().replace(/"/g,""));
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const vals = lines[i].split(",").map(v => v.trim().replace(/"/g,""));
    if (vals.length < 2) continue;
    const row = {};
    headers.forEach((h, idx) => { row[h] = vals[idx] ?? ""; });
    rows.push(row);
  }
  return { headers, rows };
}

function detectColumns(headers) {
  const map = {};
  const lower = headers.map(h => h.toLowerCase());
  const tryMatch = (keys, variants) => {
    for (const v of variants) {
      const idx = lower.findIndex(h => h.includes(v));
      if (idx >= 0) { map[keys] = headers[idx]; return; }
    }
  };
  tryMatch("CH4",["ch4","methane"]);
  tryMatch("CO",["co_","carbon_m","carbon mono"," co "]);
  tryMatch("CO2",["co2","carbon_d","carbon di"]);
  tryMatch("O2",["o2","oxygen"]);
  tryMatch("Temperature",["temp"]);
  tryMatch("Humidity",["humid"]);
  tryMatch("Dust",["dust","pm2","pm10","particulate"]);
  tryMatch("Vibration",["vib"]);
  tryMatch("WaterLevel",["water","level"]);
  tryMatch("Airflow",["airflow","air_flow","ventilation","wind"]);
  tryMatch("Timestamp",["time","date","ts"]);
  tryMatch("ZoneID",["zone","sector","area","location"]);
  // fallback: CO needs special handling (not co2 match)
  if (!map["CO"]) {
    const idx = lower.findIndex(h => h === "co" || h === "co_ppm");
    if (idx >= 0) map["CO"] = headers[idx];
  }
  return map;
}

function imputeMissing(rows, colMap) {
  const filled = JSON.parse(JSON.stringify(rows));
  SENSORS.forEach(sensor => {
    const col = colMap[sensor];
    if (!col) return;
    const vals = filled.map(r => parseFloat(r[col])).filter(v => !isNaN(v));
    const median = vals.length ? vals.sort((a,b)=>a-b)[Math.floor(vals.length/2)] : 0;
    filled.forEach(r => {
      if (r[col] === undefined || r[col] === "" || isNaN(parseFloat(r[col]))) {
        r[col] = median;
      }
    });
  });
  return filled;
}

function normalize(val, sensor) {
  const th = SENSOR_THRESHOLDS[sensor];
  if (!th) return 0;
  if (sensor === "O2") {
    const ideal = 20.9;
    return Math.min(1, Math.abs(val - ideal) / 5);
  }
  const crit = th.critical[0] === Infinity ? th.moderate[1] : th.critical[0];
  return Math.min(1, Math.max(0, val / (crit * 1.5)));
}

function extractFeatures(values) {
  if (!values.length) return { mean:0, std:0, roc:0, slope:0, max:0 };
  const n = values.length;
  const mean = values.reduce((a,b)=>a+b,0)/n;
  const std = Math.sqrt(values.reduce((a,b)=>a+(b-mean)**2,0)/n);
  const roc = n > 1 ? (values[n-1]-values[0])/(n-1) : 0;
  // linear regression slope
  let sx=0,sy=0,sxy=0,sx2=0;
  values.forEach((v,i)=>{ sx+=i; sy+=v; sxy+=i*v; sx2+=i*i; });
  const slope = n > 1 ? (n*sxy - sx*sy)/(n*sx2 - sx*sx) : 0;
  return { mean, std, roc, slope, max: Math.max(...values) };
}

function computeRiskScore(readings, modelParams) {
  let score = 0;
  const contributions = {};
  const anomalies = [];

  SENSORS.forEach(sensor => {
    const val = readings[sensor];
    if (val === undefined || isNaN(val)) return;
    const normVal = normalize(val, sensor);
    const w = SENSOR_WEIGHTS[sensor];

    // Adaptive threshold from model
    const adapted = modelParams?.adaptiveThresholds?.[sensor];
    let anomalyScore = 0;
    if (adapted) {
      const z = adapted.std > 0 ? Math.abs(val - adapted.mean) / adapted.std : 0;
      anomalyScore = Math.min(1, z / 3);
    }

    const sensorScore = (normVal * 0.6 + anomalyScore * 0.4) * w * 100;
    score += sensorScore;
    contributions[sensor] = { value: val, normVal, anomalyScore, sensorScore: sensorScore / w };

    if (anomalyScore > 0.6) anomalies.push({ sensor, val, z: adapted?.std > 0 ? (val-adapted.mean)/adapted.std : 0 });
  });

  return { score: Math.min(100, score), contributions, anomalies };
}

function trainModel(processedData) {
  // Compute adaptive thresholds per sensor
  const adaptiveThresholds = {};
  const trendModels = {};

  SENSORS.forEach(sensor => {
    const vals = processedData.map(r => r[sensor]).filter(v => !isNaN(v));
    if (!vals.length) return;
    const mean = vals.reduce((a,b)=>a+b,0)/vals.length;
    const std = Math.sqrt(vals.reduce((a,v)=>a+(v-mean)**2,0)/vals.length);
    adaptiveThresholds[sensor] = { mean, std, min: Math.min(...vals), max: Math.max(...vals) };

    // Simple trend model: last 30 points rolling
    const window = Math.min(30, vals.length);
    const recent = vals.slice(-window);
    trendModels[sensor] = extractFeatures(recent);
  });

  return { adaptiveThresholds, trendModels, trainedAt: new Date().toISOString(), dataPoints: processedData.length };
}

function predictRisk(processedData, colMap, modelParams, steps=10) {
  // Use last 20 rows to extrapolate
  const window = Math.min(20, processedData.length);
  const recent = processedData.slice(-window);
  const predictions = [];

  for (let s = 1; s <= steps; s++) {
    const predicted = {};
    SENSORS.forEach(sensor => {
      const vals = recent.map(r => r[sensor]).filter(v => !isNaN(v));
      if (!vals.length) { predicted[sensor] = 0; return; }
      const feat = extractFeatures(vals);
      // Extrapolate using slope + some mean reversion
      const lastVal = vals[vals.length-1];
      const trend = feat.slope * s;
      const meanReversion = (feat.mean - lastVal) * 0.1 * s;
      const noise = (Math.random()-0.5) * feat.std * 0.3;
      predicted[sensor] = Math.max(0, lastVal + trend * 0.5 + meanReversion + noise);
    });
    const { score } = computeRiskScore(predicted, modelParams);
    predictions.push({ step: s, minutesAhead: s * 3, score, readings: predicted });
  }
  return predictions;
}

function classifyRisk(score) {
  if (score < 30) return { label: "SAFE", color: "#00ff9d", bg: "#00ff9d22", icon: "●" };
  if (score < 60) return { label: "MODERATE", color: "#ffcc00", bg: "#ffcc0022", icon: "◆" };
  if (score < 80) return { label: "HIGH", color: "#ff8c00", bg: "#ff8c0022", icon: "▲" };
  return { label: "CRITICAL", color: "#ff2d55", bg: "#ff2d5522", icon: "⚠" };
}

function generateSampleCSV() {
  const zones = ["Zone-A","Zone-B","Zone-C","Zone-D"];
  const headers = ["Timestamp","ZoneID","CH4","CO","CO2","O2","Temperature","Humidity","Dust","Vibration","WaterLevel","Airflow"];
  const rows = [headers.join(",")];
  const now = Date.now();
  for (let i = 0; i < 200; i++) {
    const ts = new Date(now - (200-i)*60000).toISOString();
    const zone = zones[i%4];
    const t = i/200;
    const spike = i > 160 ? (i-160)/40 : 0;
    rows.push([
      ts, zone,
      (0.3 + spike*1.2 + Math.random()*0.1).toFixed(3),
      (15 + spike*40 + Math.random()*5).toFixed(1),
      (0.3 + spike*0.8 + Math.random()*0.05).toFixed(3),
      (20.5 - spike*2 + Math.random()*0.3).toFixed(2),
      (24 + spike*12 + Math.random()*2).toFixed(1),
      (60 + spike*15 + Math.random()*5).toFixed(1),
      (40 + spike*80 + Math.random()*10).toFixed(1),
      (1.2 + spike*3 + Math.random()*0.3).toFixed(2),
      (20 + spike*25 + Math.random()*3).toFixed(1),
      (3 - spike*1.5 + Math.random()*0.2).toFixed(2),
    ].join(","));
  }
  return rows.join("\n");
}

// ─── COMPONENTS ─────────────────────────────────────────────────────────────

const GlowText = ({ children, color="#00d4ff" }) => (
  <span style={{ color, textShadow:`0 0 20px ${color}80, 0 0 40px ${color}40` }}>{children}</span>
);

const RiskGauge = ({ score, size=120 }) => {
  const cls = classifyRisk(score);
  const angle = (score / 100) * 180 - 90;
  const r = size/2 - 10;
  const cx = size/2, cy = size/2 + 10;
  const toRad = d => d * Math.PI / 180;
  const needleX = cx + r * 0.75 * Math.cos(toRad(angle));
  const needleY = cy + r * 0.75 * Math.sin(toRad(angle));

  return (
    <svg width={size} height={size*0.7} style={{overflow:"visible"}}>
      {/* Track */}
      {[...Array(18)].map((_,i) => {
        const a = -90 + i*10;
        const x1 = cx + (r-8)*Math.cos(toRad(a)), y1 = cy + (r-8)*Math.sin(toRad(a));
        const x2 = cx + r*Math.cos(toRad(a)), y2 = cy + r*Math.sin(toRad(a));
        const pct = i/17;
        const c = pct < 0.4 ? "#00ff9d" : pct < 0.7 ? "#ffcc00" : pct < 0.85 ? "#ff8c00" : "#ff2d55";
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth="3" opacity="0.5"/>;
      })}
      {/* Needle */}
      <line x1={cx} y1={cy} x2={needleX} y2={needleY} stroke={cls.color} strokeWidth="2.5" strokeLinecap="round"
        style={{filter:`drop-shadow(0 0 4px ${cls.color})`}}/>
      <circle cx={cx} cy={cy} r="5" fill={cls.color} style={{filter:`drop-shadow(0 0 6px ${cls.color})`}}/>
      {/* Score */}
      <text x={cx} y={cy+24} textAnchor="middle" fill={cls.color} fontSize="20" fontWeight="700"
        fontFamily="'Courier New',monospace" style={{filter:`drop-shadow(0 0 8px ${cls.color})`}}>
        {score.toFixed(0)}
      </text>
      <text x={cx} y={cy+36} textAnchor="middle" fill={cls.color} fontSize="8" fontFamily="'Courier New',monospace" opacity="0.8">
        {cls.label}
      </text>
    </svg>
  );
};

const AlertBadge = ({ level }) => {
  const colors = { SAFE:"#00ff9d", MODERATE:"#ffcc00", HIGH:"#ff8c00", CRITICAL:"#ff2d55" };
  const c = colors[level] || "#888";
  return (
    <span style={{
      padding:"2px 8px", borderRadius:"3px", fontSize:"10px", fontWeight:"700",
      fontFamily:"'Courier New',monospace", letterSpacing:"1px",
      background: c+"22", color: c, border:`1px solid ${c}66`
    }}>{level}</span>
  );
};

const SensorBar = ({ sensor, value, contributions }) => {
  const th = SENSOR_THRESHOLDS[sensor];
  const contrib = contributions?.[sensor];
  const pct = Math.min(100, (contrib?.normVal || 0) * 100);
  const color = pct < 40 ? "#00ff9d" : pct < 70 ? "#ffcc00" : "#ff2d55";
  return (
    <div style={{ marginBottom:"8px" }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"3px" }}>
        <span style={{ color:"#8899aa", fontSize:"11px", fontFamily:"'Courier New',monospace" }}>{sensor}</span>
        <span style={{ color, fontSize:"11px", fontFamily:"'Courier New',monospace" }}>
          {typeof value === "number" ? value.toFixed(2) : "–"} {th?.unit}
        </span>
      </div>
      <div style={{ height:"4px", background:"#1a2535", borderRadius:"2px", overflow:"hidden" }}>
        <div style={{ width:`${pct}%`, height:"100%", background:color, borderRadius:"2px",
          boxShadow:`0 0 6px ${color}`, transition:"width 0.5s ease" }}/>
      </div>
    </div>
  );
};

// ─── MAIN APP ────────────────────────────────────────────────────────────────

export default function CoalMineMonitor() {
  const [tab, setTab] = useState("upload");
  const [rawData, setRawData] = useState(null);
  const [colMap, setColMap] = useState({});
  const [processedData, setProcessedData] = useState([]);
  const [modelParams, setModelParams] = useState(null);
  const [zoneData, setZoneData] = useState({});
  const [predictions, setPredictions] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [acknowledgedAlerts, setAcknowledgedAlerts] = useState(new Set());
  const [selectedZone, setSelectedZone] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dataQuality, setDataQuality] = useState(null);
  const [trainLog, setTrainLog] = useState([]);
  const [tick, setTick] = useState(0);
  const fileRef = useRef();

  // Simulate live ticking
  useEffect(() => {
    const id = setInterval(() => setTick(t => t+1), 4000);
    return () => clearInterval(id);
  }, []);

  const processUpload = useCallback((text) => {
    setLoading(true);
    setTrainLog([]);
    setTimeout(() => {
      try {
        const log = [];
        log.push("▶ Parsing CSV structure...");
        const { headers, rows } = parseCSV(text);
        log.push(`✔ Found ${headers.length} columns, ${rows.length} rows`);

        log.push("▶ Detecting column mappings...");
        const detected = detectColumns(headers);
        log.push(`✔ Mapped: ${Object.entries(detected).map(([k,v])=>`${k}→${v}`).join(", ")}`);
        setColMap(detected);

        // Data quality report
        const missing = {};
        SENSORS.forEach(s => {
          const col = detected[s];
          if (!col) { missing[s] = "column not found"; return; }
          const m = rows.filter(r => !r[col] || r[col]==="" || isNaN(parseFloat(r[col]))).length;
          if (m > 0) missing[s] = m;
        });
        const quality = {
          totalRows: rows.length, headers,
          mappedSensors: Object.keys(detected).filter(k => SENSORS.includes(k)).length,
          missingValues: missing,
          zones: [...new Set(rows.map(r => r[detected.ZoneID]).filter(Boolean))],
          timeRange: { start: rows[0]?.[detected.Timestamp], end: rows[rows.length-1]?.[detected.Timestamp] }
        };
        setDataQuality(quality);
        setRawData({ headers, rows });

        log.push("▶ Imputing missing values...");
        const imputed = imputeMissing(rows, detected);
        log.push("✔ Missing values filled with column median");

        log.push("▶ Normalizing & extracting features...");
        const processed = imputed.map(row => {
          const r = { _raw: row };
          SENSORS.forEach(s => {
            const col = detected[s];
            r[s] = col ? parseFloat(row[col]) || 0 : 0;
          });
          r.Timestamp = row[detected.Timestamp] || "";
          r.ZoneID = row[detected.ZoneID] || "Zone-A";
          return r;
        });
        log.push("✔ Feature extraction complete");

        log.push("▶ Training Multi-Sensor Risk Fusion Model...");
        const model = trainModel(processed);
        log.push(`✔ Model trained on ${model.dataPoints} samples`);
        log.push("▶ Learning adaptive thresholds per sensor...");
        log.push("✔ Anomaly detection baselines established");
        setModelParams(model);
        setProcessedData(processed);

        // Zone-wise risk computation
        log.push("▶ Computing zone-wise risk scores...");
        const zones = {};
        processed.forEach(row => {
          if (!zones[row.ZoneID]) zones[row.ZoneID] = [];
          zones[row.ZoneID].push(row);
        });
        const zoneRisks = {};
        Object.entries(zones).forEach(([zid, rows]) => {
          const latest = rows[rows.length-1];
          const { score, contributions, anomalies } = computeRiskScore(latest, model);
          const history = rows.map((r,i) => ({ i, ...computeRiskScore(r, model) }));
          zoneRisks[zid] = { latest, score, contributions, anomalies, history, rows };
        });
        setZoneData(zoneRisks);
        setSelectedZone(Object.keys(zoneRisks)[0]);

        log.push("▶ Generating hazard predictions (next 30 min)...");
        const preds = predictRisk(processed, detected, model, 10);
        setPredictions(preds);
        log.push("✔ Prediction model ready");

        // Generate alerts
        log.push("▶ Scanning for alerts & anomalies...");
        const newAlerts = [];
        Object.entries(zoneRisks).forEach(([zid, zd]) => {
          const cls = classifyRisk(zd.score);
          if (zd.score > 25) {
            newAlerts.push({
              id: `${zid}-${Date.now()}`, zone: zid, level: cls.label,
              score: zd.score, message: `Zone ${zid}: Risk score ${zd.score.toFixed(1)} – ${cls.label}`,
              time: new Date().toISOString(), sensors: zd.anomalies.map(a=>a.sensor),
              acknowledged: false
            });
          }
          zd.anomalies.forEach(a => {
            newAlerts.push({
              id: `${zid}-${a.sensor}-${Date.now()}`, zone: zid, level: Math.abs(a.z) > 3 ? "CRITICAL" : "HIGH",
              score: zd.score, message: `Anomaly in ${a.sensor} at ${zid}: value ${a.val?.toFixed(2)} (${a.z?.toFixed(1)}σ from baseline)`,
              time: new Date().toISOString(), sensors: [a.sensor], acknowledged: false
            });
          });
        });
        setAlerts(newAlerts);
        log.push(`✔ ${newAlerts.length} alerts generated`);
        log.push("═══════════════════════════════════");
        log.push("✔ System fully operational");
        setTrainLog(log);
        setLoading(false);
        setTab("dashboard");
      } catch(e) {
        setTrainLog(["✘ Error: " + e.message]);
        setLoading(false);
      }
    }, 100);
  }, []);

  const handleFile = useCallback((file) => {
    const reader = new FileReader();
    reader.onload = e => processUpload(e.target.result);
    reader.readAsText(file);
  }, [processUpload]);

  const handleDrop = useCallback(e => {
    e.preventDefault(); setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const loadSample = () => processUpload(generateSampleCSV());

  const zones = Object.keys(zoneData);
  const currentZone = selectedZone && zoneData[selectedZone] ? zoneData[selectedZone] : null;

  // Recompute with tick for "live" feel
  const liveZoneData = useMemo(() => {
    if (!Object.keys(zoneData).length || !modelParams) return zoneData;
    const updated = {};
    Object.entries(zoneData).forEach(([zid, zd]) => {
      if (!zd.rows?.length) { updated[zid] = zd; return; }
      const jitter = {};
      SENSORS.forEach(s => {
        const base = zd.latest[s] || 0;
        const noise = (Math.random()-0.5) * (modelParams.adaptiveThresholds[s]?.std || 0) * 0.15;
        jitter[s] = Math.max(0, base + noise);
      });
      const { score, contributions, anomalies } = computeRiskScore(jitter, modelParams);
      updated[zid] = { ...zd, latest: { ...zd.latest, ...jitter }, score, contributions, anomalies };
    });
    return updated;
  }, [tick, zoneData, modelParams]);

  const overallRisk = zones.length
    ? zones.reduce((s, z) => s + (liveZoneData[z]?.score||0), 0) / zones.length : 0;

  // Styles
  const S = {
    app: { background:"#040d1a", minHeight:"100vh", color:"#c8d8e8", fontFamily:"'Courier New',monospace" },
    header: { background:"linear-gradient(180deg,#071428 0%,#040d1a 100%)", borderBottom:"1px solid #0d2540", padding:"12px 24px", display:"flex", alignItems:"center", justifyContent:"space-between" },
    nav: { display:"flex", gap:"4px", padding:"8px 24px", borderBottom:"1px solid #0d2540", background:"#040d1a" },
    navBtn: (active) => ({ padding:"6px 16px", border:`1px solid ${active?"#00d4ff":"#0d2540"}`, background: active?"#00d4ff18":"transparent", color: active?"#00d4ff":"#4a6a8a", cursor:"pointer", borderRadius:"3px", fontSize:"11px", letterSpacing:"1px", fontFamily:"'Courier New',monospace", transition:"all 0.2s" }),
    card: { background:"#06111f", border:"1px solid #0d2540", borderRadius:"6px", padding:"16px" },
    cardTitle: { color:"#00d4ff", fontSize:"11px", letterSpacing:"2px", marginBottom:"12px", display:"flex", alignItems:"center", gap:"8px" },
    grid2: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:"12px" },
    grid3: { display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"12px" },
    grid4: { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"12px" },
    section: { padding:"16px 24px" },
    input: { background:"#040d1a", border:"1px solid #0d2540", color:"#c8d8e8", padding:"6px 10px", borderRadius:"3px", fontFamily:"'Courier New',monospace", fontSize:"12px" },
    btn: (c="#00d4ff") => ({ padding:"8px 16px", border:`1px solid ${c}`, background:`${c}18`, color:c, cursor:"pointer", borderRadius:"3px", fontSize:"11px", letterSpacing:"1px", fontFamily:"'Courier New',monospace" }),
    table: { width:"100%", borderCollapse:"collapse", fontSize:"11px" },
    th: { padding:"6px 10px", textAlign:"left", color:"#4a6a8a", borderBottom:"1px solid #0d2540", letterSpacing:"1px" },
    td: { padding:"6px 10px", borderBottom:"1px solid #06111f", color:"#8899aa" },
  };

  const TABS = [
    { id:"upload", label:"⬆ UPLOAD" },
    { id:"dashboard", label:"◉ DASHBOARD" },
    { id:"risk", label:"⚡ RISK ENGINE" },
    { id:"alerts", label:"🔔 ALERTS" + (alerts.filter(a=>!acknowledgedAlerts.has(a.id)).length ? ` (${alerts.filter(a=>!acknowledgedAlerts.has(a.id)).length})` : "") },
    { id:"reports", label:"📊 REPORTS" },
  ];

  return (
    <div style={S.app}>
      {/* HEADER */}
      <div style={S.header}>
        <div style={{ display:"flex", alignItems:"center", gap:"16px" }}>
          <div style={{ fontSize:"20px" }}>⛏</div>
          <div>
            <div style={{ fontSize:"14px", fontWeight:"700", letterSpacing:"3px", color:"#00d4ff" }}>
              COAL MINE MONITOR
            </div>
            <div style={{ fontSize:"9px", color:"#4a6a8a", letterSpacing:"2px" }}>INTELLIGENT RISK PREDICTION SYSTEM v2.0</div>
          </div>
        </div>
        <div style={{ display:"flex", gap:"24px", alignItems:"center" }}>
          {zones.length > 0 && (
            <>
              <div style={{ textAlign:"center" }}>
                <div style={{ fontSize:"9px", color:"#4a6a8a", letterSpacing:"1px" }}>OVERALL RISK</div>
                <GlowText color={classifyRisk(overallRisk).color}>{overallRisk.toFixed(1)}</GlowText>
              </div>
              <div style={{ textAlign:"center" }}>
                <div style={{ fontSize:"9px", color:"#4a6a8a", letterSpacing:"1px" }}>ZONES ACTIVE</div>
                <GlowText color="#00d4ff">{zones.length}</GlowText>
              </div>
              <div style={{ textAlign:"center" }}>
                <div style={{ fontSize:"9px", color:"#4a6a8a", letterSpacing:"1px" }}>ALERTS</div>
                <GlowText color="#ff2d55">{alerts.filter(a=>!acknowledgedAlerts.has(a.id)).length}</GlowText>
              </div>
            </>
          )}
          <div style={{ fontSize:"10px", color:"#4a6a8a" }}>
            {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* NAV */}
      <div style={S.nav}>
        {TABS.map(t => (
          <button key={t.id} style={S.navBtn(tab===t.id)} onClick={()=>setTab(t.id)}>{t.label}</button>
        ))}
        {modelParams && (
          <span style={{ marginLeft:"auto", fontSize:"10px", color:"#00ff9d", alignSelf:"center" }}>
            ● MODEL ACTIVE · {processedData.length} pts
          </span>
        )}
      </div>

      {/* UPLOAD TAB */}
      {tab === "upload" && (
        <div style={S.section}>
          <div style={{ maxWidth:"800px", margin:"0 auto" }}>
            <div style={{ marginBottom:"16px" }}>
              <h2 style={{ color:"#00d4ff", letterSpacing:"3px", fontSize:"14px", margin:0 }}>DATASET UPLOAD MODULE</h2>
              <p style={{ color:"#4a6a8a", fontSize:"11px", marginTop:"4px" }}>Upload CSV with environmental sensor readings. System auto-detects columns and retrains on each upload.</p>
            </div>

            {/* Drop zone */}
            <div
              onDragOver={e=>{e.preventDefault();setDragOver(true)}}
              onDragLeave={()=>setDragOver(false)}
              onDrop={handleDrop}
              style={{ border:`2px dashed ${dragOver?"#00d4ff":"#0d2540"}`, borderRadius:"8px", padding:"48px", textAlign:"center", marginBottom:"16px", background:dragOver?"#00d4ff08":"#06111f", transition:"all 0.2s", cursor:"pointer" }}
              onClick={()=>fileRef.current?.click()}
            >
              <input ref={fileRef} type="file" accept=".csv" style={{display:"none"}} onChange={e=>e.target.files[0]&&handleFile(e.target.files[0])}/>
              <div style={{ fontSize:"36px", marginBottom:"12px" }}>📂</div>
              <div style={{ color:"#00d4ff", fontSize:"14px", letterSpacing:"2px", marginBottom:"8px" }}>DRAG & DROP CSV FILE</div>
              <div style={{ color:"#4a6a8a", fontSize:"11px" }}>or click to browse</div>
            </div>

            <div style={{ display:"flex", gap:"8px", marginBottom:"24px" }}>
              <button style={S.btn("#00ff9d")} onClick={loadSample}>⚡ LOAD SAMPLE DATASET</button>
              <span style={{ color:"#4a6a8a", fontSize:"10px", alignSelf:"center" }}>← Try with pre-built mine monitoring data (200 rows, 4 zones)</span>
            </div>

            {/* Expected format */}
            <div style={{ ...S.card, marginBottom:"16px" }}>
              <div style={S.cardTitle}>📋 EXPECTED CSV FORMAT</div>
              <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
                {["Timestamp","ZoneID","CH4","CO","CO2","O2","Temperature","Humidity","Dust","Vibration","WaterLevel","Airflow"].map(h => (
                  <span key={h} style={{ padding:"3px 8px", background:"#00d4ff12", border:"1px solid #00d4ff33", borderRadius:"3px", fontSize:"10px", color:"#00d4ff" }}>{h}</span>
                ))}
              </div>
              <div style={{ marginTop:"12px", fontSize:"10px", color:"#4a6a8a" }}>
                Column names are auto-detected – partial matches work (e.g. "methane" maps to CH4, "temp" maps to Temperature)
              </div>
            </div>

            {/* Training log */}
            {(loading || trainLog.length > 0) && (
              <div style={{ ...S.card }}>
                <div style={S.cardTitle}>⚙ PROCESSING LOG</div>
                <div style={{ background:"#020810", borderRadius:"4px", padding:"12px", maxHeight:"200px", overflowY:"auto" }}>
                  {trainLog.map((l,i) => (
                    <div key={i} style={{ color: l.startsWith("✔")||l.startsWith("═") ? "#00ff9d" : l.startsWith("✘") ? "#ff2d55" : "#8899aa", fontSize:"11px", marginBottom:"2px" }}>{l}</div>
                  ))}
                  {loading && <div style={{ color:"#00d4ff", fontSize:"11px" }}>▶ Processing<span style={{animation:"blink 1s infinite"}}>...</span></div>}
                </div>
              </div>
            )}

            {/* Data quality */}
            {dataQuality && !loading && (
              <div style={{ ...S.card, marginTop:"16px" }}>
                <div style={S.cardTitle}>✅ DATA QUALITY REPORT</div>
                <div style={S.grid4}>
                  <div style={{ textAlign:"center" }}>
                    <div style={{ fontSize:"24px", color:"#00d4ff", fontWeight:"700" }}>{dataQuality.totalRows}</div>
                    <div style={{ fontSize:"10px", color:"#4a6a8a" }}>TOTAL ROWS</div>
                  </div>
                  <div style={{ textAlign:"center" }}>
                    <div style={{ fontSize:"24px", color:"#00ff9d", fontWeight:"700" }}>{dataQuality.mappedSensors}/10</div>
                    <div style={{ fontSize:"10px", color:"#4a6a8a" }}>SENSORS MAPPED</div>
                  </div>
                  <div style={{ textAlign:"center" }}>
                    <div style={{ fontSize:"24px", color:"#ffcc00", fontWeight:"700" }}>{dataQuality.zones.length}</div>
                    <div style={{ fontSize:"10px", color:"#4a6a8a" }}>ZONES FOUND</div>
                  </div>
                  <div style={{ textAlign:"center" }}>
                    <div style={{ fontSize:"24px", color: Object.keys(dataQuality.missingValues).length > 0 ? "#ff8c00" : "#00ff9d", fontWeight:"700" }}>
                      {Object.keys(dataQuality.missingValues).filter(k=>typeof dataQuality.missingValues[k]==="number").reduce((s,k)=>s+dataQuality.missingValues[k],0)}
                    </div>
                    <div style={{ fontSize:"10px", color:"#4a6a8a" }}>MISSING VALUES</div>
                  </div>
                </div>
                {dataQuality.zones.length > 0 && (
                  <div style={{ marginTop:"12px", fontSize:"10px", color:"#4a6a8a" }}>
                    Zones: {dataQuality.zones.join(", ")} &nbsp;|&nbsp;
                    Time: {dataQuality.timeRange.start?.slice(0,19)} → {dataQuality.timeRange.end?.slice(0,19)}
                  </div>
                )}
                {/* Preview table */}
                {rawData && (
                  <div style={{ marginTop:"12px" }}>
                    <div style={{ fontSize:"10px", color:"#4a6a8a", marginBottom:"6px", letterSpacing:"1px" }}>PREVIEW (first 5 rows)</div>
                    <div style={{ overflowX:"auto" }}>
                      <table style={S.table}>
                        <thead><tr>{rawData.headers.slice(0,10).map(h => <th key={h} style={S.th}>{h}</th>)}</tr></thead>
                        <tbody>{rawData.rows.slice(0,5).map((r,i) => (
                          <tr key={i}>{rawData.headers.slice(0,10).map(h => <td key={h} style={S.td}>{r[h]?.slice?.(0,15) || r[h]}</td>)}</tr>
                        ))}</tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* DASHBOARD TAB */}
      {tab === "dashboard" && (
        <div style={S.section}>
          {!zones.length ? (
            <div style={{ textAlign:"center", padding:"60px", color:"#4a6a8a" }}>
              <div style={{ fontSize:"40px", marginBottom:"12px" }}>📂</div>
              <div>Upload a dataset to activate dashboard</div>
            </div>
          ) : (
            <>
              {/* Zone selector */}
              <div style={{ display:"flex", gap:"8px", marginBottom:"16px", flexWrap:"wrap" }}>
                {zones.map(z => {
                  const zd = liveZoneData[z];
                  const cls = classifyRisk(zd?.score||0);
                  return (
                    <button key={z} onClick={()=>setSelectedZone(z)}
                      style={{ ...S.btn(selectedZone===z ? cls.color : "#4a6a8a"), border:`2px solid ${selectedZone===z ? cls.color : "#0d2540"}`, position:"relative" }}>
                      {z} · <span style={{color:cls.color}}>{(zd?.score||0).toFixed(0)}</span>
                      {zd?.anomalies?.length > 0 && <span style={{ position:"absolute", top:-4, right:-4, width:8, height:8, background:"#ff2d55", borderRadius:"50%", animation:"pulse 1s infinite" }}/>}
                    </button>
                  );
                })}
              </div>

              {/* Zone cards - top row */}
              <div style={S.grid4}>
                {zones.map(z => {
                  const zd = liveZoneData[z];
                  const cls = classifyRisk(zd?.score||0);
                  return (
                    <div key={z} style={{ ...S.card, border:`1px solid ${cls.color}44`, cursor:"pointer", transition:"all 0.3s" }} onClick={()=>setSelectedZone(z)}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"8px" }}>
                        <span style={{ fontSize:"12px", color:"#8899aa", letterSpacing:"1px" }}>{z}</span>
                        <AlertBadge level={cls.label}/>
                      </div>
                      <RiskGauge score={zd?.score||0} size={100}/>
                    </div>
                  );
                })}
              </div>

              {/* Detailed zone view */}
              {currentZone && selectedZone && liveZoneData[selectedZone] && (
                <div style={{ marginTop:"16px" }}>
                  <div style={S.grid2}>
                    {/* Sensor readings */}
                    <div style={S.card}>
                      <div style={S.cardTitle}>⚡ SENSOR READINGS — {selectedZone}</div>
                      {SENSORS.map(s => (
                        <SensorBar key={s} sensor={s} value={liveZoneData[selectedZone]?.latest?.[s]}
                          contributions={liveZoneData[selectedZone]?.contributions}/>
                      ))}
                    </div>

                    {/* Risk history chart */}
                    <div style={S.card}>
                      <div style={S.cardTitle}>📈 RISK SCORE HISTORY</div>
                      <ResponsiveContainer width="100%" height={280}>
                        <AreaChart data={(liveZoneData[selectedZone]?.history||[]).slice(-50)}>
                          <defs>
                            <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#00d4ff" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#0d2540"/>
                          <XAxis dataKey="i" hide/>
                          <YAxis domain={[0,100]} tick={{fill:"#4a6a8a",fontSize:10}} width={30}/>
                          <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",borderRadius:"4px",fontSize:"11px"}} labelStyle={{color:"#4a6a8a"}} itemStyle={{color:"#00d4ff"}}/>
                          <Area type="monotone" dataKey="score" stroke="#00d4ff" fill="url(#riskGrad)" strokeWidth={2}
                            dot={false} name="Risk Score"/>
                          <Area type="monotone" dataKey={() => 60} stroke="#ff8c00" fill="none" strokeDasharray="3 3" strokeWidth={1} name="High Threshold"/>
                          <Area type="monotone" dataKey={() => 80} stroke="#ff2d55" fill="none" strokeDasharray="3 3" strokeWidth={1} name="Critical Threshold"/>
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Sensor trend charts */}
                  <div style={{ ...S.grid2, marginTop:"12px" }}>
                    {["CH4","CO","O2","Temperature"].map(sensor => {
                      const history = (zoneData[selectedZone]?.rows||[]).slice(-50).map((r,i)=>({i, v: r[sensor]||0}));
                      const feat = modelParams?.trendModels?.[sensor];
                      const col = sensor==="CH4"?"#ff6b35":sensor==="CO"?"#ff2d55":sensor==="O2"?"#00ff9d":"#ffcc00";
                      return (
                        <div key={sensor} style={S.card}>
                          <div style={{ ...S.cardTitle, color:col }}>{sensor} — {SENSOR_THRESHOLDS[sensor]?.unit}</div>
                          <ResponsiveContainer width="100%" height={130}>
                            <LineChart data={history}>
                              <CartesianGrid strokeDasharray="2 2" stroke="#0d2540"/>
                              <XAxis dataKey="i" hide/>
                              <YAxis tick={{fill:"#4a6a8a",fontSize:9}} width={30}/>
                              <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",fontSize:"10px"}} itemStyle={{color:col}}/>
                              <Line type="monotone" dataKey="v" stroke={col} strokeWidth={1.5} dot={false}
                                style={{filter:`drop-shadow(0 0 3px ${col})`}}/>
                              {feat && <Line type="monotone" dataKey={()=>feat.mean} stroke={col} strokeDasharray="3 3" strokeWidth={1} dot={false} opacity={0.4} name="baseline"/>}
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      );
                    })}
                  </div>

                  {/* Prediction chart */}
                  <div style={{ ...S.card, marginTop:"12px" }}>
                    <div style={S.cardTitle}>🔮 HAZARD PREDICTION — NEXT 30 MINUTES</div>
                    <div style={S.grid2}>
                      <ResponsiveContainer width="100%" height={200}>
                        <AreaChart data={predictions}>
                          <defs>
                            <linearGradient id="predGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#9b59b6" stopOpacity={0.4}/>
                              <stop offset="95%" stopColor="#9b59b6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#0d2540"/>
                          <XAxis dataKey="minutesAhead" tick={{fill:"#4a6a8a",fontSize:10}} label={{value:"min ahead",fill:"#4a6a8a",fontSize:9,dy:12}}/>
                          <YAxis domain={[0,100]} tick={{fill:"#4a6a8a",fontSize:10}} width={30}/>
                          <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",fontSize:"11px"}} itemStyle={{color:"#9b59b6"}} formatter={v=>[v.toFixed(1),"Predicted Risk"]}/>
                          <Area type="monotone" dataKey="score" stroke="#9b59b6" fill="url(#predGrad)" strokeWidth={2} dot={{r:3,fill:"#9b59b6"}}/>
                          <Area type="monotone" dataKey={()=>60} stroke="#ff8c00" fill="none" strokeDasharray="3 3" strokeWidth={1}/>
                          <Area type="monotone" dataKey={()=>80} stroke="#ff2d55" fill="none" strokeDasharray="3 3" strokeWidth={1}/>
                        </AreaChart>
                      </ResponsiveContainer>
                      <div style={{ display:"flex", flexDirection:"column", gap:"8px", justifyContent:"center" }}>
                        {predictions.slice(0,5).map(p => {
                          const cls = classifyRisk(p.score);
                          return (
                            <div key={p.step} style={{ display:"flex", alignItems:"center", gap:"8px", padding:"6px", background:cls.bg, borderRadius:"4px", border:`1px solid ${cls.color}33` }}>
                              <span style={{ color:cls.color, fontSize:"18px" }}>{cls.icon}</span>
                              <span style={{ flex:1, fontSize:"11px", color:"#8899aa" }}>T+{p.minutesAhead} min</span>
                              <AlertBadge level={cls.label}/>
                              <span style={{ fontSize:"12px", color:cls.color, fontWeight:"700" }}>{p.score.toFixed(0)}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* RISK ENGINE TAB */}
      {tab === "risk" && (
        <div style={S.section}>
          {!modelParams ? (
            <div style={{ textAlign:"center", padding:"60px", color:"#4a6a8a" }}>Upload a dataset to activate the Risk Engine</div>
          ) : (
            <>
              <div style={S.grid2}>
                {/* Model info */}
                <div style={S.card}>
                  <div style={S.cardTitle}>🧠 MODEL PARAMETERS</div>
                  <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between" }}>
                      <span style={{ color:"#4a6a8a", fontSize:"11px" }}>Model Type</span>
                      <span style={{ color:"#00d4ff", fontSize:"11px" }}>Multi-Sensor Risk Fusion</span>
                    </div>
                    <div style={{ display:"flex", justifyContent:"space-between" }}>
                      <span style={{ color:"#4a6a8a", fontSize:"11px" }}>Training Points</span>
                      <span style={{ color:"#00ff9d", fontSize:"11px" }}>{modelParams.dataPoints}</span>
                    </div>
                    <div style={{ display:"flex", justifyContent:"space-between" }}>
                      <span style={{ color:"#4a6a8a", fontSize:"11px" }}>Trained At</span>
                      <span style={{ color:"#8899aa", fontSize:"11px" }}>{new Date(modelParams.trainedAt).toLocaleTimeString()}</span>
                    </div>
                    <div style={{ display:"flex", justifyContent:"space-between" }}>
                      <span style={{ color:"#4a6a8a", fontSize:"11px" }}>Active Sensors</span>
                      <span style={{ color:"#00d4ff", fontSize:"11px" }}>{Object.keys(modelParams.adaptiveThresholds).length}/10</span>
                    </div>
                  </div>
                  <div style={{ marginTop:"16px" }}>
                    <div style={{ fontSize:"10px", color:"#4a6a8a", letterSpacing:"1px", marginBottom:"8px" }}>SENSOR WEIGHTS</div>
                    {SENSORS.map(s => (
                      <div key={s} style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"4px" }}>
                        <span style={{ width:"100px", fontSize:"10px", color:"#8899aa" }}>{s}</span>
                        <div style={{ flex:1, height:"3px", background:"#0d2540", borderRadius:"2px" }}>
                          <div style={{ width:`${SENSOR_WEIGHTS[s]*400}%`, height:"100%", background:"#00d4ff", borderRadius:"2px" }}/>
                        </div>
                        <span style={{ fontSize:"10px", color:"#4a6a8a", width:"35px", textAlign:"right" }}>{(SENSOR_WEIGHTS[s]*100).toFixed(0)}%</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Sensor contribution for selected zone */}
                <div style={S.card}>
                  <div style={S.cardTitle}>📊 SENSOR CONTRIBUTION — {selectedZone || "Select Zone"}</div>
                  {selectedZone && liveZoneData[selectedZone] && (
                    <ResponsiveContainer width="100%" height={300}>
                      <RadarChart data={SENSORS.map(s => ({
                        sensor: s,
                        contribution: ((liveZoneData[selectedZone]?.contributions?.[s]?.normVal || 0) * 100),
                        anomaly: ((liveZoneData[selectedZone]?.contributions?.[s]?.anomalyScore || 0) * 100),
                      }))}>
                        <PolarGrid stroke="#0d2540"/>
                        <PolarAngleAxis dataKey="sensor" tick={{fill:"#4a6a8a",fontSize:9}}/>
                        <PolarRadiusAxis domain={[0,100]} tick={{fill:"#4a6a8a",fontSize:8}} axisLine={false}/>
                        <Radar name="Risk Level" dataKey="contribution" stroke="#00d4ff" fill="#00d4ff" fillOpacity={0.2} strokeWidth={2}/>
                        <Radar name="Anomaly Score" dataKey="anomaly" stroke="#ff2d55" fill="#ff2d55" fillOpacity={0.15} strokeWidth={2}/>
                        <Legend iconSize={10} wrapperStyle={{fontSize:"10px"}}/>
                        <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",fontSize:"11px"}}/>
                      </RadarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Adaptive thresholds */}
              <div style={{ ...S.card, marginTop:"12px" }}>
                <div style={S.cardTitle}>🎯 ADAPTIVE THRESHOLDS vs CURRENT VALUES</div>
                <div style={{ overflowX:"auto" }}>
                  <table style={S.table}>
                    <thead>
                      <tr>
                        <th style={S.th}>SENSOR</th>
                        <th style={S.th}>UNIT</th>
                        <th style={S.th}>BASELINE MEAN</th>
                        <th style={S.th}>STD DEV</th>
                        <th style={S.th}>CURRENT VALUE</th>
                        <th style={S.th}>Z-SCORE</th>
                        <th style={S.th}>STATUS</th>
                        <th style={S.th}>STATIC THRESHOLD</th>
                      </tr>
                    </thead>
                    <tbody>
                      {SENSORS.map(s => {
                        const at = modelParams.adaptiveThresholds[s];
                        const cur = selectedZone && liveZoneData[selectedZone]?.latest?.[s];
                        const z = at && at.std > 0 && cur !== undefined ? (cur - at.mean) / at.std : null;
                        const anomaly = z !== null && Math.abs(z) > 2;
                        const th = SENSOR_THRESHOLDS[s];
                        return (
                          <tr key={s}>
                            <td style={{...S.td, color:"#c8d8e8", fontWeight:"700"}}>{s}</td>
                            <td style={S.td}>{th?.unit}</td>
                            <td style={S.td}>{at ? at.mean.toFixed(3) : "—"}</td>
                            <td style={S.td}>{at ? at.std.toFixed(3) : "—"}</td>
                            <td style={{...S.td, color: anomaly?"#ff2d55":"#00ff9d"}}>{cur !== undefined ? cur.toFixed(3) : "—"}</td>
                            <td style={{...S.td, color: z !== null ? (Math.abs(z)>3?"#ff2d55":Math.abs(z)>2?"#ff8c00":"#00ff9d") : "#4a6a8a"}}>{z !== null ? z.toFixed(2) : "—"}</td>
                            <td style={S.td}><AlertBadge level={anomaly?"HIGH":"SAFE"}/></td>
                            <td style={{...S.td, color:"#4a6a8a", fontSize:"10px"}}>{th ? `Safe: ${th.safe[0]}–${th.safe[1]===Infinity?"∞":th.safe[1]}` : "—"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Anomaly detection section */}
              <div style={{ ...S.card, marginTop:"12px" }}>
                <div style={S.cardTitle}>🔍 ANOMALY DETECTION RESULTS</div>
                <div style={{ display:"flex", gap:"12px", flexWrap:"wrap" }}>
                  {zones.map(z => {
                    const zd = liveZoneData[z];
                    return (
                      <div key={z} style={{ flex:1, minWidth:"200px", padding:"12px", background:"#040d1a", borderRadius:"4px", border:"1px solid #0d2540" }}>
                        <div style={{ color:"#00d4ff", fontSize:"11px", letterSpacing:"1px", marginBottom:"8px" }}>{z}</div>
                        {zd?.anomalies?.length > 0 ? (
                          zd.anomalies.map((a,i) => (
                            <div key={i} style={{ fontSize:"10px", color:"#ff8c00", marginBottom:"4px" }}>
                              ⚠ {a.sensor}: {a.val?.toFixed(2)} ({a.z?.toFixed(1)}σ)
                            </div>
                          ))
                        ) : (
                          <div style={{ fontSize:"10px", color:"#00ff9d" }}>✔ No anomalies detected</div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* ALERTS TAB */}
      {tab === "alerts" && (
        <div style={S.section}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"16px" }}>
            <h2 style={{ color:"#ff2d55", letterSpacing:"3px", fontSize:"14px", margin:0 }}>ALERT MANAGEMENT SYSTEM</h2>
            <div style={{ display:"flex", gap:"8px" }}>
              <span style={{ fontSize:"11px", color:"#4a6a8a", alignSelf:"center" }}>
                {alerts.filter(a=>!acknowledgedAlerts.has(a.id)).length} unacknowledged
              </span>
              <button style={S.btn("#ff8c00")} onClick={()=>setAcknowledgedAlerts(new Set(alerts.map(a=>a.id)))}>
                ACK ALL
              </button>
            </div>
          </div>

          {!alerts.length ? (
            <div style={{ textAlign:"center", padding:"60px", color:"#4a6a8a" }}>No alerts – upload dataset to generate</div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
              {/* Summary bar */}
              <div style={{ ...S.card, display:"flex", gap:"24px" }}>
                {["CRITICAL","HIGH","MODERATE","SAFE"].map(level => {
                  const colors = { CRITICAL:"#ff2d55", HIGH:"#ff8c00", MODERATE:"#ffcc00", SAFE:"#00ff9d" };
                  const count = alerts.filter(a=>a.level===level).length;
                  return (
                    <div key={level} style={{ textAlign:"center" }}>
                      <div style={{ fontSize:"24px", color:colors[level], fontWeight:"700" }}>{count}</div>
                      <AlertBadge level={level}/>
                    </div>
                  );
                })}
              </div>

              {/* Alert list */}
              {alerts.map(a => {
                const colors = { CRITICAL:"#ff2d55", HIGH:"#ff8c00", MODERATE:"#ffcc00", SAFE:"#00ff9d" };
                const acked = acknowledgedAlerts.has(a.id);
                const c = colors[a.level] || "#4a6a8a";
                return (
                  <div key={a.id} style={{ ...S.card, border:`1px solid ${acked?"#0d2540":c+"66"}`, opacity: acked ? 0.5 : 1, display:"flex", alignItems:"center", gap:"12px" }}>
                    <div style={{ width:"3px", alignSelf:"stretch", background:c, borderRadius:"2px", flexShrink:0 }}/>
                    <div style={{ flex:1 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"4px" }}>
                        <AlertBadge level={a.level}/>
                        <span style={{ fontSize:"11px", color:"#8899aa" }}>{a.zone}</span>
                        <span style={{ fontSize:"10px", color:"#4a6a8a" }}>{new Date(a.time).toLocaleTimeString()}</span>
                        {acked && <span style={{ fontSize:"9px", color:"#00ff9d", letterSpacing:"1px" }}>✔ ACKNOWLEDGED</span>}
                      </div>
                      <div style={{ fontSize:"12px", color:"#c8d8e8" }}>{a.message}</div>
                      {a.sensors?.length > 0 && (
                        <div style={{ marginTop:"4px", display:"flex", gap:"4px" }}>
                          {a.sensors.map(s => <span key={s} style={{ fontSize:"9px", padding:"1px 5px", background:"#ff2d5518", border:"1px solid #ff2d5533", borderRadius:"2px", color:"#ff8c00" }}>{s}</span>)}
                        </div>
                      )}
                    </div>
                    {!acked && (
                      <button style={S.btn("#00ff9d")} onClick={()=>setAcknowledgedAlerts(prev=>new Set([...prev,a.id]))}>
                        ACK
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* REPORTS TAB */}
      {tab === "reports" && (
        <div style={S.section}>
          <h2 style={{ color:"#00d4ff", letterSpacing:"3px", fontSize:"14px", margin:"0 0 16px 0" }}>SAFETY REPORTS & ANALYTICS</h2>

          {!zones.length ? (
            <div style={{ textAlign:"center", padding:"60px", color:"#4a6a8a" }}>Upload a dataset to generate reports</div>
          ) : (
            <>
              {/* Zone risk comparison */}
              <div style={S.grid2}>
                <div style={S.card}>
                  <div style={S.cardTitle}>🏆 ZONE RISK RANKING</div>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={zones.map(z=>({ zone:z, score:(liveZoneData[z]?.score||0), fill: classifyRisk(liveZoneData[z]?.score||0).color })).sort((a,b)=>b.score-a.score)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#0d2540"/>
                      <XAxis dataKey="zone" tick={{fill:"#4a6a8a",fontSize:10}}/>
                      <YAxis domain={[0,100]} tick={{fill:"#4a6a8a",fontSize:10}} width={30}/>
                      <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",fontSize:"11px"}} formatter={v=>[v.toFixed(1),"Risk Score"]}/>
                      <Bar dataKey="score" radius={[3,3,0,0]}>
                        {zones.sort((a,b)=>(liveZoneData[b]?.score||0)-(liveZoneData[a]?.score||0)).map((z,i)=>(
                          <rect key={i} fill={classifyRisk(liveZoneData[z]?.score||0).color}/>
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div style={S.card}>
                  <div style={S.cardTitle}>📋 DAILY SAFETY SUMMARY</div>
                  {(() => {
                    const sortedZones = [...zones].sort((a,b)=>(liveZoneData[b]?.score||0)-(liveZoneData[a]?.score||0));
                    const mostDangerous = sortedZones[0];
                    const safest = sortedZones[sortedZones.length-1];
                    const criticalCount = zones.filter(z=>(liveZoneData[z]?.score||0)>=80).length;
                    const highCount = zones.filter(z=>{const s=liveZoneData[z]?.score||0;return s>=60&&s<80;}).length;
                    return (
                      <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
                        <div style={{ padding:"10px", background:"#ff2d5512", border:"1px solid #ff2d5533", borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#ff2d55", letterSpacing:"1px" }}>MOST DANGEROUS ZONE</div>
                          <div style={{ fontSize:"18px", color:"#ff2d55", fontWeight:"700" }}>{mostDangerous}</div>
                          <div style={{ fontSize:"11px", color:"#8899aa" }}>Risk Score: {(liveZoneData[mostDangerous]?.score||0).toFixed(1)}</div>
                        </div>
                        <div style={{ padding:"10px", background:"#00ff9d12", border:"1px solid #00ff9d33", borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#00ff9d", letterSpacing:"1px" }}>SAFEST ZONE</div>
                          <div style={{ fontSize:"18px", color:"#00ff9d", fontWeight:"700" }}>{safest}</div>
                          <div style={{ fontSize:"11px", color:"#8899aa" }}>Risk Score: {(liveZoneData[safest]?.score||0).toFixed(1)}</div>
                        </div>
                        <div style={S.grid2}>
                          <div style={{ padding:"8px", background:"#040d1a", borderRadius:"4px", textAlign:"center" }}>
                            <div style={{ fontSize:"20px", color:"#ff2d55", fontWeight:"700" }}>{criticalCount}</div>
                            <div style={{ fontSize:"10px", color:"#4a6a8a" }}>CRITICAL ZONES</div>
                          </div>
                          <div style={{ padding:"8px", background:"#040d1a", borderRadius:"4px", textAlign:"center" }}>
                            <div style={{ fontSize:"20px", color:"#ff8c00", fontWeight:"700" }}>{highCount}</div>
                            <div style={{ fontSize:"10px", color:"#4a6a8a" }}>HIGH RISK ZONES</div>
                          </div>
                        </div>
                        <div style={{ padding:"8px", background:"#040d1a", borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#4a6a8a", marginBottom:"4px" }}>UNACKNOWLEDGED ALERTS</div>
                          <div style={{ fontSize:"16px", color:"#ffcc00", fontWeight:"700" }}>{alerts.filter(a=>!acknowledgedAlerts.has(a.id)).length}</div>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>

              {/* Risk growth trends */}
              <div style={{ ...S.card, marginTop:"12px" }}>
                <div style={S.cardTitle}>📈 RISK GROWTH TRENDS BY ZONE</div>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart>
                    <CartesianGrid strokeDasharray="3 3" stroke="#0d2540"/>
                    <XAxis dataKey="i" type="number" domain={["dataMin","dataMax"]} hide/>
                    <YAxis domain={[0,100]} tick={{fill:"#4a6a8a",fontSize:10}} width={30}/>
                    <Tooltip contentStyle={{background:"#06111f",border:"1px solid #0d2540",fontSize:"11px"}}/>
                    <Legend wrapperStyle={{fontSize:"10px"}}/>
                    {zones.map((z,zi) => {
                      const colors2 = ["#00d4ff","#ff2d55","#00ff9d","#ffcc00","#9b59b6"];
                      return (
                        <Line key={z} data={(zoneData[z]?.history||[]).slice(-60)} type="monotone"
                          dataKey="score" name={z} stroke={colors2[zi%5]} strokeWidth={2} dot={false}/>
                      );
                    })}
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Prediction + downtime */}
              <div style={{ ...S.grid2, marginTop:"12px" }}>
                <div style={S.card}>
                  <div style={S.cardTitle}>⏱ DOWNTIME PREDICTION</div>
                  {(() => {
                    const maxPred = predictions.length ? Math.max(...predictions.map(p=>p.score)) : 0;
                    const critStep = predictions.find(p=>p.score>=80);
                    return (
                      <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
                        <div style={{ padding:"12px", background:maxPred>=80?"#ff2d5512":"#00ff9d12", border:`1px solid ${maxPred>=80?"#ff2d55":"#00ff9d"}33`, borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#4a6a8a", letterSpacing:"1px" }}>PEAK PREDICTED RISK</div>
                          <div style={{ fontSize:"28px", color:classifyRisk(maxPred).color, fontWeight:"700" }}>{maxPred.toFixed(1)}</div>
                          <div style={{ fontSize:"11px", color:"#8899aa" }}>in next 30 minutes</div>
                        </div>
                        <div style={{ padding:"12px", background:"#040d1a", borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#4a6a8a", letterSpacing:"1px" }}>EVACUATION TRIGGER</div>
                          <div style={{ fontSize:"18px", color: critStep?"#ff2d55":"#00ff9d", fontWeight:"700" }}>
                            {critStep ? `T+${critStep.minutesAhead} minutes` : "Not predicted"}
                          </div>
                        </div>
                        <div style={{ padding:"12px", background:"#040d1a", borderRadius:"4px" }}>
                          <div style={{ fontSize:"10px", color:"#4a6a8a", letterSpacing:"1px" }}>RECOMMENDED ACTION</div>
                          <div style={{ fontSize:"12px", color:"#ffcc00", marginTop:"4px" }}>
                            {maxPred >= 80 ? "⚠ IMMEDIATE EVACUATION RECOMMENDED" :
                             maxPred >= 60 ? "⚡ Increase monitoring frequency" :
                             maxPred >= 30 ? "✔ Continue standard monitoring" :
                             "✔ Conditions nominal"}
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </div>

                <div style={S.card}>
                  <div style={S.cardTitle}>🧪 SENSOR HEALTH STATUS</div>
                  <table style={S.table}>
                    <thead>
                      <tr>
                        <th style={S.th}>SENSOR</th>
                        <th style={S.th}>DATA COVERAGE</th>
                        <th style={S.th}>BASELINE</th>
                        <th style={S.th}>STATUS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {SENSORS.map(s => {
                        const at = modelParams?.adaptiveThresholds[s];
                        const coverage = at ? "100%" : "—";
                        return (
                          <tr key={s}>
                            <td style={{...S.td,color:"#c8d8e8"}}>{s}</td>
                            <td style={S.td}>{coverage}</td>
                            <td style={S.td}>{at ? at.mean.toFixed(2) : "—"}</td>
                            <td style={S.td}><AlertBadge level={at?"SAFE":"MODERATE"}/></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      <style>{`
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.3)} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
        ::-webkit-scrollbar { width:4px; height:4px; }
        ::-webkit-scrollbar-track { background:#040d1a; }
        ::-webkit-scrollbar-thumb { background:#0d2540; border-radius:2px; }
        * { box-sizing:border-box; }
      `}</style>
    </div>
  );
}
