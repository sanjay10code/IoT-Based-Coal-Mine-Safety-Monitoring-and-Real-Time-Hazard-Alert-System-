import { AppProvider, useApp } from '@/context/AppContext';
import { Navigation } from '@/components/Navigation';
import { Dashboard } from '@/pages/Dashboard';
import { DataImport } from '@/pages/DataImport';
import { LiveSensors } from '@/pages/LiveSensors';
import { RiskMap } from '@/pages/RiskMap';
import { Alerts } from '@/pages/Alerts';
import { Models } from '@/pages/Models';
import { Reports } from '@/pages/Reports';
import { Admin } from '@/pages/Admin';

function AppContent() {
  const { currentPage } = useApp();

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'dataimport':
        return <DataImport />;
      case 'sensors':
        return <LiveSensors />;
      case 'riskmap':
        return <RiskMap />;
      case 'alerts':
        return <Alerts />;
      case 'models':
        return <Models />;
      case 'reports':
        return <Reports />;
      case 'admin':
        return <Admin />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0E13] text-white">
      {/* Noise Overlay */}
      <div className="noise-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main Content */}
      <main className="relative z-10">
        {renderPage()}
      </main>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
