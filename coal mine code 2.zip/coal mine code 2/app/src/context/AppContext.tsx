import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { 
  UserRole, 
  RiskLevel, 
  Zone, 
  Sensor, 
  Alert, 
  MLModel, 
  SafetyMetrics,
  SimulationState,
  PageId,
  SensorReading
} from '@/types';
import { 
  validateDataset, 
  type ParsedDataset
} from '@/utils/dataParser';

// Generate mock sensor history
const generateHistory = (baseValue: number, variance: number, points: number = 24): SensorReading[] => {
  const history: SensorReading[] = [];
  const now = new Date();
  for (let i = points; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
    const value = baseValue + (Math.random() - 0.5) * variance;
    history.push({ timestamp, value: Math.max(0, value) });
  }
  return history;
};

// Initial Zones
const initialZones: Zone[] = [
  { id: 'shaft-a', name: 'Shaft-A', riskLevel: 'low', sensors: ['ch4-1', 'co-1', 'temp-1'], coordinates: { x: 15, y: 20, width: 12, height: 15 }, description: 'Main access shaft' },
  { id: 'tunnel-3', name: 'Tunnel-3', riskLevel: 'medium', sensors: ['ch4-2', 'dust-1', 'vib-1'], coordinates: { x: 35, y: 35, width: 25, height: 10 }, description: 'Primary extraction tunnel' },
  { id: 'vent-2', name: 'Vent-2', riskLevel: 'low', sensors: ['o2-1', 'temp-2', 'hum-1'], coordinates: { x: 70, y: 25, width: 10, height: 20 }, description: 'Ventilation shaft' },
  { id: 'staging-1', name: 'Staging-1', riskLevel: 'high', sensors: ['ch4-3', 'co-2', 'dust-2'], coordinates: { x: 50, y: 60, width: 18, height: 12 }, description: 'Material staging area' },
  { id: 'emergency-exit', name: 'Emergency Exit', riskLevel: 'low', sensors: ['o2-2', 'temp-3'], coordinates: { x: 80, y: 70, width: 8, height: 15 }, description: 'Emergency evacuation route' },
];

// Initial Sensors
const initialSensors: Sensor[] = [
  { id: 'ch4-1', name: 'CH4-S1', type: 'CH4', zoneId: 'shaft-a', value: 0.42, unit: '%', status: 'normal', timestamp: new Date(), history: generateHistory(0.4, 0.1) },
  { id: 'ch4-2', name: 'CH4-S2', type: 'CH4', zoneId: 'tunnel-3', value: 0.85, unit: '%', status: 'warning', timestamp: new Date(), history: generateHistory(0.7, 0.2) },
  { id: 'ch4-3', name: 'CH4-S3', type: 'CH4', zoneId: 'staging-1', value: 1.25, unit: '%', status: 'critical', timestamp: new Date(), history: generateHistory(1.0, 0.3) },
  { id: 'co-1', name: 'CO-S1', type: 'CO', zoneId: 'shaft-a', value: 8, unit: 'ppm', status: 'normal', timestamp: new Date(), history: generateHistory(7, 3) },
  { id: 'co-2', name: 'CO-S2', type: 'CO', zoneId: 'staging-1', value: 18, unit: 'ppm', status: 'warning', timestamp: new Date(), history: generateHistory(15, 5) },
  { id: 'o2-1', name: 'O2-S1', type: 'O2', zoneId: 'vent-2', value: 20.8, unit: '%', status: 'normal', timestamp: new Date(), history: generateHistory(20.9, 0.3) },
  { id: 'o2-2', name: 'O2-S2', type: 'O2', zoneId: 'emergency-exit', value: 20.5, unit: '%', status: 'normal', timestamp: new Date(), history: generateHistory(20.8, 0.2) },
  { id: 'dust-1', name: 'Dust-S1', type: 'dust', zoneId: 'tunnel-3', value: 2.4, unit: 'mg/m³', status: 'warning', timestamp: new Date(), history: generateHistory(2.0, 0.5) },
  { id: 'dust-2', name: 'Dust-S2', type: 'dust', zoneId: 'staging-1', value: 4.2, unit: 'mg/m³', status: 'critical', timestamp: new Date(), history: generateHistory(3.5, 0.8) },
  { id: 'temp-1', name: 'Temp-S1', type: 'temperature', zoneId: 'shaft-a', value: 18.5, unit: '°C', status: 'normal', timestamp: new Date(), history: generateHistory(18, 1) },
  { id: 'temp-2', name: 'Temp-S2', type: 'temperature', zoneId: 'vent-2', value: 16.2, unit: '°C', status: 'normal', timestamp: new Date(), history: generateHistory(16, 0.8) },
  { id: 'temp-3', name: 'Temp-S3', type: 'temperature', zoneId: 'emergency-exit', value: 17.8, unit: '°C', status: 'normal', timestamp: new Date(), history: generateHistory(17.5, 0.5) },
  { id: 'hum-1', name: 'Hum-S1', type: 'humidity', zoneId: 'vent-2', value: 72, unit: '%', status: 'normal', timestamp: new Date(), history: generateHistory(70, 5) },
  { id: 'vib-1', name: 'Vib-S1', type: 'vibration', zoneId: 'tunnel-3', value: 3.2, unit: 'mm/s', status: 'warning', timestamp: new Date(), history: generateHistory(2.8, 0.6) },
];

// Initial Alerts
const initialAlerts: Alert[] = [
  { id: 'alert-1', timestamp: new Date(Date.now() - 15 * 60 * 1000), zoneId: 'tunnel-3', zoneName: 'Tunnel-3', sensorType: 'CH4', message: 'Elevated methane trend detected', severity: 'high', status: 'active' },
  { id: 'alert-2', timestamp: new Date(Date.now() - 45 * 60 * 1000), zoneId: 'vent-2', zoneName: 'Vent-2', sensorType: 'temperature', message: 'Temperature spike detected', severity: 'medium', status: 'resolved' },
  { id: 'alert-3', timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), zoneId: 'shaft-a', zoneName: 'Shaft-A', sensorType: 'CO', message: 'Baseline drift detected', severity: 'low', status: 'resolved' },
  { id: 'alert-4', timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), zoneId: 'staging-1', zoneName: 'Staging-1', sensorType: 'dust', message: 'Dust threshold approaching', severity: 'medium', status: 'monitoring' },
  { id: 'alert-5', timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000), zoneId: 'tunnel-3', zoneName: 'Tunnel-3', sensorType: 'CH4', message: 'Levels normalized', severity: 'low', status: 'resolved' },
];

// Initial ML Models
const initialModels: MLModel[] = [
  { 
    id: 'conformal', 
    name: 'Conformal Prediction', 
    description: 'Risk forecasts with calibrated uncertainty bands. Know when the model is unsure.',
    accuracy: 94.2,
    latency: 38,
    status: 'healthy',
    lastUpdated: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    icon: 'TrendingUp'
  },
  { 
    id: 'tft', 
    name: 'Temporal Fusion Transformer', 
    description: 'Multivariate time-series forecasting that fuses sensors, weather, and maintenance logs.',
    accuracy: 96.8,
    latency: 52,
    status: 'healthy',
    lastUpdated: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    icon: 'Layers'
  },
  { 
    id: 'gnn', 
    name: 'Graph Neural Network', 
    description: 'Models tunnel connectivity to predict how risk propagates across zones.',
    accuracy: 92.5,
    latency: 45,
    status: 'healthy',
    lastUpdated: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    icon: 'Network'
  },
  { 
    id: 'ssad', 
    name: 'Self-Supervised Anomaly Detection', 
    description: 'Contrastive learning approach for detecting novel anomalies without labeled data.',
    accuracy: 89.3,
    latency: 34,
    status: 'healthy',
    lastUpdated: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    icon: 'Search'
  },
  { 
    id: 'fl', 
    name: 'Federated Learning + HPO', 
    description: 'Privacy-preserving distributed learning with automated hyperparameter optimization.',
    accuracy: 91.7,
    latency: 120,
    status: 'retraining',
    lastUpdated: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    icon: 'Shield'
  },
];

// Initial Safety Metrics
const initialMetrics: SafetyMetrics = {
  overallScore: 94,
  sensorUptime: 99.97,
  avgResponseTime: 2.1,
  openAlerts: 3,
  modelAccuracy: 96.4,
  daysWithoutIncident: 127,
};

interface AppContextType {
  // User State
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  
  // Navigation
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  
  // Data State
  zones: Zone[];
  sensors: Sensor[];
  alerts: Alert[];
  models: MLModel[];
  safetyMetrics: SafetyMetrics;
  
  // Data Import
  importedData: ParsedDataset | null;
  importData: (dataset: ParsedDataset) => void;
  clearImportedData: () => void;
  isUsingImportedData: boolean;
  
  // Simulation State
  simulation: SimulationState;
  updateSimulation: (updates: Partial<SimulationState>) => void;
  applySimulation: () => void;
  resetSimulation: () => void;
  
  // Actions
  resolveAlert: (alertId: string) => void;
  acknowledgeAlert: (alertId: string) => void;
  refreshData: () => void;
  
  // Computed
  getZoneSensors: (zoneId: string) => Sensor[];
  getAlertsBySeverity: (severity: RiskLevel | 'all') => Alert[];
  getCriticalSensors: () => Sensor[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [userRole, setUserRole] = useState<UserRole>('operator');
  const [currentPage, setCurrentPage] = useState<PageId>('dashboard');
  const [zones, setZones] = useState<Zone[]>(initialZones);
  const [sensors, setSensors] = useState<Sensor[]>(initialSensors);
  const [alerts, setAlerts] = useState<Alert[]>(initialAlerts);
  const [models] = useState<MLModel[]>(initialModels);
  const [safetyMetrics] = useState<SafetyMetrics>(initialMetrics);
  const [importedData, setImportedData] = useState<ParsedDataset | null>(null);
  const [simulation, setSimulation] = useState<SimulationState>({
    methaneLevel: 0.5,
    ventilationRate: 2.8,
    temperature: 18,
    predictedRisk: 'low',
  });

  const isUsingImportedData = importedData !== null;

  // Import data from file
  const importData = useCallback((dataset: ParsedDataset) => {
    const errors = validateDataset(dataset);
    if (errors.length > 0) {
      console.error('Dataset validation errors:', errors);
      throw new Error(errors.join('\n'));
    }
    
    setImportedData(dataset);
    setSensors(dataset.sensors);
    setZones(dataset.zones);
    setAlerts(dataset.alerts);
  }, []);

  // Clear imported data and reset to defaults
  const clearImportedData = useCallback(() => {
    setImportedData(null);
    setSensors(initialSensors);
    setZones(initialZones);
    setAlerts(initialAlerts);
  }, []);

  // Update simulation values
  const updateSimulation = useCallback((updates: Partial<SimulationState>) => {
    setSimulation(prev => {
      const newState = { ...prev, ...updates };
      // Calculate predicted risk based on simulation values
      let risk: RiskLevel = 'low';
      if (newState.methaneLevel > 1.5 || newState.temperature > 35) {
        risk = 'critical';
      } else if (newState.methaneLevel > 1.0 || newState.temperature > 30) {
        risk = 'high';
      } else if (newState.methaneLevel > 0.8 || newState.temperature > 25) {
        risk = 'medium';
      }
      return { ...newState, predictedRisk: risk };
    });
  }, []);

  // Apply simulation to actual sensor data
  const applySimulation = useCallback(() => {
    setSensors(prev => prev.map(sensor => {
      if (sensor.type === 'CH4') {
        const newValue = simulation.methaneLevel + (Math.random() - 0.5) * 0.1;
        return {
          ...sensor,
          value: Math.max(0, newValue),
          status: newValue > 1.0 ? 'critical' : newValue > 0.8 ? 'warning' : 'normal',
          timestamp: new Date(),
        };
      }
      if (sensor.type === 'temperature') {
        const newValue = simulation.temperature + (Math.random() - 0.5) * 2;
        return {
          ...sensor,
          value: Math.max(0, newValue),
          status: newValue > 35 ? 'critical' : newValue > 30 ? 'warning' : 'normal',
          timestamp: new Date(),
        };
      }
      return sensor;
    }));

    // Update zone risk levels based on simulation
    setZones(prev => prev.map(zone => {
      const zoneSensors = sensors.filter(s => s.zoneId === zone.id);
      const hasCritical = zoneSensors.some(s => s.status === 'critical');
      const hasWarning = zoneSensors.some(s => s.status === 'warning');
      
      let newRisk: RiskLevel = 'low';
      if (hasCritical) newRisk = 'critical';
      else if (hasWarning) newRisk = 'medium';
      
      return { ...zone, riskLevel: newRisk };
    }));
  }, [simulation, sensors]);

  // Reset simulation
  const resetSimulation = useCallback(() => {
    setSimulation({
      methaneLevel: 0.5,
      ventilationRate: 2.8,
      temperature: 18,
      predictedRisk: 'low',
    });
    if (!isUsingImportedData) {
      setSensors(initialSensors);
      setZones(initialZones);
    }
  }, [isUsingImportedData]);

  // Resolve alert
  const resolveAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, status: 'resolved' as const } : alert
    ));
  }, []);

  // Acknowledge alert
  const acknowledgeAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, status: 'monitoring' as const } : alert
    ));
  }, []);

  // Refresh data (simulate)
  const refreshData = useCallback(() => {
    if (isUsingImportedData) return; // Don't refresh imported data
    setSensors(prev => prev.map(sensor => ({
      ...sensor,
      value: sensor.value + (Math.random() - 0.5) * 0.1,
      timestamp: new Date(),
    })));
  }, [isUsingImportedData]);

  // Get sensors for a zone
  const getZoneSensors = useCallback((zoneId: string) => {
    return sensors.filter(s => s.zoneId === zoneId);
  }, [sensors]);

  // Get alerts by severity
  const getAlertsBySeverity = useCallback((severity: RiskLevel | 'all') => {
    if (severity === 'all') return alerts;
    return alerts.filter(a => a.severity === severity);
  }, [alerts]);

  // Get critical sensors
  const getCriticalSensors = useCallback(() => {
    return sensors.filter(s => s.status === 'critical' || s.status === 'warning');
  }, [sensors]);

  // Auto-refresh sensors every 5 seconds (only for demo data)
  useEffect(() => {
    if (isUsingImportedData) return;
    const interval = setInterval(() => {
      refreshData();
    }, 5000);
    return () => clearInterval(interval);
  }, [refreshData, isUsingImportedData]);

  const value: AppContextType = {
    userRole,
    setUserRole,
    currentPage,
    setCurrentPage,
    zones,
    sensors,
    alerts,
    models,
    safetyMetrics,
    importedData,
    importData,
    clearImportedData,
    isUsingImportedData,
    simulation,
    updateSimulation,
    applySimulation,
    resetSimulation,
    resolveAlert,
    acknowledgeAlert,
    refreshData,
    getZoneSensors,
    getAlertsBySeverity,
    getCriticalSensors,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
