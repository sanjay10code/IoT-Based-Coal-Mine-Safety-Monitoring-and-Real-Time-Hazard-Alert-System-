import type { Sensor, Alert, Zone, SensorType } from '@/types';

export interface ParsedDataset {
  sensors: Sensor[];
  alerts: Alert[];
  zones: Zone[];
  metadata: {
    importedAt: Date;
    totalReadings: number;
    dateRange: { start: Date; end: Date };
  };
}

export interface CSVRow {
  timestamp: string;
  sensor_id: string;
  sensor_type: string;
  zone_id: string;
  zone_name: string;
  value: string;
  unit: string;
  status?: string;
}

const VALID_SENSOR_TYPES: SensorType[] = ['CH4', 'CO', 'O2', 'dust', 'temperature', 'humidity', 'vibration'];

export function parseCSV(csvText: string): CSVRow[] {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) throw new Error('CSV must have at least a header and one data row');
  
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const rows: CSVRow[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());
    if (values.length !== headers.length) continue;
    
    const row: any = {};
    headers.forEach((header, idx) => {
      row[header] = values[idx];
    });
    rows.push(row as CSVRow);
  }
  
  return rows;
}

export function parseJSON(jsonText: string): any {
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('Invalid JSON format');
  }
}

export function processSensorData(rows: CSVRow[]): ParsedDataset {
  const sensorMap = new Map<string, Sensor>();
  const zoneMap = new Map<string, Zone>();
  const alerts: Alert[] = [];
  
  let minDate = new Date(8640000000000000);
  let maxDate = new Date(-8640000000000000);
  let totalReadings = 0;
  
  // Process each row
  rows.forEach((row, idx) => {
    const timestamp = new Date(row.timestamp);
    if (isNaN(timestamp.getTime())) return;
    
    // Update date range
    if (timestamp < minDate) minDate = timestamp;
    if (timestamp > maxDate) maxDate = timestamp;
    
    const sensorType = row.sensor_type.toUpperCase() as SensorType;
    if (!VALID_SENSOR_TYPES.includes(sensorType)) return;
    
    const value = parseFloat(row.value);
    if (isNaN(value)) return;
    
    // Determine status based on thresholds
    const status = determineStatus(sensorType, value, row.status);
    
    // Create or update sensor
    const sensorId = row.sensor_id;
    if (!sensorMap.has(sensorId)) {
      sensorMap.set(sensorId, {
        id: sensorId,
        name: sensorId.toUpperCase(),
        type: sensorType,
        zoneId: row.zone_id,
        value: value,
        unit: row.unit || getDefaultUnit(sensorType),
        status: status,
        timestamp: timestamp,
        history: [],
      });
    }
    
    const sensor = sensorMap.get(sensorId)!;
    sensor.history.push({ timestamp, value });
    totalReadings++;
    
    // Update current value if this is the latest
    if (timestamp > sensor.timestamp) {
      sensor.value = value;
      sensor.status = status;
      sensor.timestamp = timestamp;
    }
    
    // Create zone if not exists
    if (!zoneMap.has(row.zone_id)) {
      zoneMap.set(row.zone_id, {
        id: row.zone_id,
        name: row.zone_name || row.zone_id,
        riskLevel: 'low',
        sensors: [],
        coordinates: generateZoneCoordinates(row.zone_id, zoneMap.size),
        description: `${row.zone_name || row.zone_id} monitoring zone`,
      });
    }
    
    const zone = zoneMap.get(row.zone_id)!;
    if (!zone.sensors.includes(sensorId)) {
      zone.sensors.push(sensorId);
    }
    
    // Generate alerts for critical/warning status
    if (status === 'critical' || status === 'warning') {
      const alertId = `alert-${idx}`;
      const existingAlert = alerts.find(a => 
        a.zoneId === row.zone_id && 
        a.sensorType === sensorType && 
        a.status === 'active'
      );
      
      if (!existingAlert) {
        alerts.push({
          id: alertId,
          timestamp,
          zoneId: row.zone_id,
          zoneName: zone.name,
          sensorType,
          message: generateAlertMessage(sensorType, value, status),
          severity: status === 'critical' ? 'critical' : 'high',
          status: 'active',
        });
      }
    }
  });
  
  // Update zone risk levels based on sensor statuses
  zoneMap.forEach((zone) => {
    const zoneSensors = zone.sensors.map(id => sensorMap.get(id)).filter(Boolean) as Sensor[];
    const hasCritical = zoneSensors.some(s => s.status === 'critical');
    const hasWarning = zoneSensors.some(s => s.status === 'warning');
    
    if (hasCritical) zone.riskLevel = 'critical';
    else if (hasWarning) zone.riskLevel = 'high';
    else if (zoneSensors.some(s => s.status === 'normal')) zone.riskLevel = 'low';
    else zone.riskLevel = 'medium';
  });
  
  return {
    sensors: Array.from(sensorMap.values()),
    alerts,
    zones: Array.from(zoneMap.values()),
    metadata: {
      importedAt: new Date(),
      totalReadings,
      dateRange: { start: minDate, end: maxDate },
    },
  };
}

function determineStatus(type: SensorType, value: number, providedStatus?: string): 'normal' | 'warning' | 'critical' {
  if (providedStatus && ['normal', 'warning', 'critical'].includes(providedStatus)) {
    return providedStatus as 'normal' | 'warning' | 'critical';
  }
  
  const thresholds = getThresholds(type);
  if (value >= thresholds.critical) return 'critical';
  if (value >= thresholds.warning) return 'warning';
  return 'normal';
}

function getThresholds(type: SensorType): { warning: number; critical: number } {
  switch (type) {
    case 'CH4': return { warning: 0.8, critical: 1.0 };
    case 'CO': return { warning: 20, critical: 35 };
    case 'O2': return { warning: 19.5, critical: 18 };
    case 'dust': return { warning: 2.5, critical: 4.0 };
    case 'temperature': return { warning: 30, critical: 35 };
    case 'humidity': return { warning: 80, critical: 90 };
    case 'vibration': return { warning: 3.5, critical: 5.0 };
    default: return { warning: 50, critical: 80 };
  }
}

function getDefaultUnit(type: SensorType): string {
  switch (type) {
    case 'CH4': return '%';
    case 'CO': return 'ppm';
    case 'O2': return '%';
    case 'dust': return 'mg/m³';
    case 'temperature': return '°C';
    case 'humidity': return '%';
    case 'vibration': return 'mm/s';
    default: return '';
  }
}

function generateAlertMessage(type: SensorType, value: number, status: string): string {
  const typeNames: Record<SensorType, string> = {
    CH4: 'Methane',
    CO: 'Carbon Monoxide',
    O2: 'Oxygen',
    dust: 'Dust',
    temperature: 'Temperature',
    humidity: 'Humidity',
    vibration: 'Vibration',
  };
  
  if (status === 'critical') {
    return `${typeNames[type]} critical: ${value.toFixed(2)} ${getDefaultUnit(type)}`;
  }
  return `${typeNames[type]} elevated: ${value.toFixed(2)} ${getDefaultUnit(type)}`;
}

function generateZoneCoordinates(_zoneId: string, index: number): { x: number; y: number; width: number; height: number } {
  // Generate deterministic coordinates based on zone index
  const positions = [
    { x: 15, y: 20, width: 12, height: 15 },
    { x: 35, y: 35, width: 25, height: 10 },
    { x: 70, y: 25, width: 10, height: 20 },
    { x: 50, y: 60, width: 18, height: 12 },
    { x: 80, y: 70, width: 8, height: 15 },
    { x: 25, y: 55, width: 15, height: 10 },
    { x: 60, y: 15, width: 12, height: 12 },
    { x: 10, y: 45, width: 10, height: 15 },
  ];
  
  return positions[index % positions.length];
}

export function generateSampleCSV(): string {
  const headers = 'timestamp,sensor_id,sensor_type,zone_id,zone_name,value,unit,status';
  const now = new Date();
  const rows: string[] = [headers];
  
  const sensors = [
    { id: 'ch4-1', type: 'CH4', zone: 'shaft-a', zoneName: 'Shaft-A', unit: '%' },
    { id: 'ch4-2', type: 'CH4', zone: 'tunnel-3', zoneName: 'Tunnel-3', unit: '%' },
    { id: 'co-1', type: 'CO', zone: 'shaft-a', zoneName: 'Shaft-A', unit: 'ppm' },
    { id: 'temp-1', type: 'temperature', zone: 'shaft-a', zoneName: 'Shaft-A', unit: '°C' },
    { id: 'dust-1', type: 'dust', zone: 'tunnel-3', zoneName: 'Tunnel-3', unit: 'mg/m³' },
    { id: 'vib-1', type: 'vibration', zone: 'tunnel-3', zoneName: 'Tunnel-3', unit: 'mm/s' },
  ];
  
  // Generate 48 hours of data (every 30 minutes)
  for (let i = 48; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 30 * 60 * 1000);
    const timestampStr = timestamp.toISOString();
    
    sensors.forEach(sensor => {
      let value: number;
      let status = 'normal';
      
      // Generate realistic values with some variation
      switch (sensor.type) {
        case 'CH4':
          value = 0.4 + Math.random() * 0.6;
          if (value > 0.8) status = 'warning';
          if (value > 1.0) status = 'critical';
          break;
        case 'CO':
          value = 5 + Math.random() * 20;
          if (value > 20) status = 'warning';
          if (value > 35) status = 'critical';
          break;
        case 'temperature':
          value = 16 + Math.random() * 10;
          if (value > 30) status = 'warning';
          if (value > 35) status = 'critical';
          break;
        case 'dust':
          value = 1 + Math.random() * 3;
          if (value > 2.5) status = 'warning';
          if (value > 4) status = 'critical';
          break;
        case 'vibration':
          value = 2 + Math.random() * 2;
          if (value > 3.5) status = 'warning';
          if (value > 5) status = 'critical';
          break;
        default:
          value = Math.random() * 100;
      }
      
      rows.push(`${timestampStr},${sensor.id},${sensor.type},${sensor.zone},${sensor.zoneName},${value.toFixed(2)},${sensor.unit},${status}`);
    });
  }
  
  return rows.join('\n');
}

export function downloadSampleDataset() {
  const csv = generateSampleCSV();
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'coalmine_sample_data.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function validateDataset(data: ParsedDataset): string[] {
  const errors: string[] = [];
  
  if (data.sensors.length === 0) {
    errors.push('No valid sensors found in dataset');
  }
  
  if (data.zones.length === 0) {
    errors.push('No valid zones found in dataset');
  }
  
  data.sensors.forEach(sensor => {
    if (sensor.history.length === 0) {
      errors.push(`Sensor ${sensor.id} has no history data`);
    }
  });
  
  return errors;
}
