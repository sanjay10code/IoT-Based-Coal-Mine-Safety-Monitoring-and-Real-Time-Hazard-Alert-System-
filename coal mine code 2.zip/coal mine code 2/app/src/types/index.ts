// User Role Types
export type UserRole = 'operator' | 'supervisor';

// Risk Level Types
export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

// Zone Types
export interface Zone {
  id: string;
  name: string;
  riskLevel: RiskLevel;
  sensors: string[];
  coordinates: { x: number; y: number; width: number; height: number };
  description?: string;
}

// Sensor Types
export type SensorType = 'CH4' | 'CO' | 'O2' | 'dust' | 'temperature' | 'humidity' | 'vibration';

export interface Sensor {
  id: string;
  name: string;
  type: SensorType;
  zoneId: string;
  value: number;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  timestamp: Date;
  history: SensorReading[];
}

export interface SensorReading {
  timestamp: Date;
  value: number;
}

// Alert Types
export interface Alert {
  id: string;
  timestamp: Date;
  zoneId: string;
  zoneName: string;
  sensorType: SensorType;
  message: string;
  severity: RiskLevel;
  status: 'active' | 'monitoring' | 'resolved';
}

// ML Model Types
export interface MLModel {
  id: string;
  name: string;
  description: string;
  accuracy: number;
  latency: number;
  status: 'healthy' | 'degraded' | 'retraining';
  lastUpdated: Date;
  icon: string;
}

// Safety Score Types
export interface SafetyMetrics {
  overallScore: number;
  sensorUptime: number;
  avgResponseTime: number;
  openAlerts: number;
  modelAccuracy: number;
  daysWithoutIncident: number;
}

// Simulation Types
export interface SimulationState {
  methaneLevel: number;
  ventilationRate: number;
  temperature: number;
  predictedRisk: RiskLevel;
}

// Navigation Types
export type PageId = 'dashboard' | 'sensors' | 'riskmap' | 'alerts' | 'models' | 'reports' | 'admin' | 'dataimport';

export interface NavItem {
  id: PageId;
  label: string;
  icon: string;
  allowedRoles: UserRole[];
}

// Chart Data Types
export interface ChartDataPoint {
  timestamp: string;
  value: number;
  zone?: string;
}

// Report Types
export interface Report {
  id: string;
  title: string;
  type: 'daily' | 'weekly' | 'monthly' | 'incident';
  generatedAt: Date;
  size: string;
  downloadUrl?: string;
}

// Heatmap Cell Types
export interface HeatmapCell {
  x: number;
  y: number;
  riskLevel: RiskLevel;
  value: number;
}
