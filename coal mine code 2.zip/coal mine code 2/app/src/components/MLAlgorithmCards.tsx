import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, Network, Search, Shield, Activity, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface MLAlgorithm {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  accuracy: number;
  latency: number;
  status: 'healthy' | 'degraded' | 'retraining';
  features: string[];
  badge?: string;
}

const algorithms: MLAlgorithm[] = [
  {
    id: 'conformal',
    name: 'Conformal Prediction',
    description: 'Risk forecasts with calibrated uncertainty bands. Know when the model is unsure and needs human oversight.',
    icon: TrendingUp,
    accuracy: 94.2,
    latency: 38,
    status: 'healthy',
    features: ['Uncertainty Quantification', 'Calibration Guarantees', '99% Coverage'],
    badge: 'Uncertainty Aware',
  },
  {
    id: 'tft',
    name: 'Temporal Fusion Transformer',
    description: 'Multivariate time-series forecasting that fuses sensors, weather, and maintenance logs for 24h predictions.',
    icon: Brain,
    accuracy: 96.8,
    latency: 52,
    status: 'healthy',
    features: ['Multi-Horizon', 'Variable Selection', 'Attention Mechanism'],
    badge: 'Best Accuracy',
  },
  {
    id: 'gnn',
    name: 'Graph Neural Network',
    description: 'Models tunnel connectivity to predict how risk propagates across zones in the mine network.',
    icon: Network,
    accuracy: 92.5,
    latency: 45,
    status: 'healthy',
    features: ['Spatial Reasoning', 'Connectivity Analysis', 'Risk Diffusion'],
  },
  {
    id: 'ssad',
    name: 'Self-Supervised Anomaly Detection',
    description: 'Contrastive learning approach detecting novel anomalies without labeled training data.',
    icon: Search,
    accuracy: 89.3,
    latency: 34,
    status: 'healthy',
    features: ['No Labels Required', 'Novel Pattern Detection', 'Continuous Learning'],
  },
  {
    id: 'fl',
    name: 'Federated Learning + HPO',
    description: 'Privacy-preserving distributed learning across multiple mines with automated hyperparameter optimization.',
    icon: Shield,
    accuracy: 91.7,
    latency: 120,
    status: 'retraining',
    features: ['Privacy Preserving', 'Cross-Site Learning', 'Auto ML'],
    badge: 'Privacy First',
  },
];

const statusConfig = {
  healthy: { icon: CheckCircle, color: '#22C55E', label: 'Healthy' },
  degraded: { icon: AlertCircle, color: '#F59E0B', label: 'Degraded' },
  retraining: { icon: Activity, color: '#FF4D00', label: 'Retraining' },
};

export function MLAlgorithmCards() {
  const { models } = useApp();

  return (
    <div className="card-dark p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Early-Warning ML Engine</h3>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#22C55E]" />
            <span className="text-[#A9B3C2]">{models.filter(m => m.status === 'healthy').length} Healthy</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[#FF4D00] status-pulse-critical" />
            <span className="text-[#A9B3C2]">{models.filter(m => m.status === 'retraining').length} Retraining</span>
          </div>
        </div>
      </div>

      <p className="text-[#A9B3C2] mb-6">
        Multivariate forecasting + uncertainty quantification—so you act before thresholds are breached.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {algorithms.map((algo, index) => {
          const Icon = algo.icon;
          const StatusIcon = statusConfig[algo.status].icon;
          const model = models.find(m => m.id === algo.id);
          
          return (
            <motion.div
              key={algo.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="ml-card p-4 flex flex-col"
            >
              {/* Badge */}
              {algo.badge && (
                <div className="absolute top-3 right-3">
                  <span className="text-[10px] px-2 py-0.5 bg-[#FF4D00]/20 text-[#FF4D00] rounded-full border border-[#FF4D00]/30">
                    {algo.badge}
                  </span>
                </div>
              )}

              {/* Icon */}
              <div className="w-10 h-10 rounded-lg bg-[#FF4D00]/10 flex items-center justify-center mb-3">
                <Icon className="w-5 h-5 text-[#FF4D00]" />
              </div>

              {/* Title */}
              <h4 className="text-sm font-semibold text-white mb-2 pr-16">{algo.name}</h4>

              {/* Description */}
              <p className="text-xs text-[#A9B3C2] mb-4 flex-grow">{algo.description}</p>

              {/* Features */}
              <div className="flex flex-wrap gap-1 mb-4">
                {algo.features.map((feature, i) => (
                  <span 
                    key={i}
                    className="text-[10px] px-2 py-0.5 bg-white/5 text-[#A9B3C2] rounded-full"
                  >
                    {feature}
                  </span>
                ))}
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div className="p-2 bg-white/5 rounded-lg">
                  <p className="text-[10px] text-[#A9B3C2] mb-0.5">Accuracy</p>
                  <p className="text-sm font-semibold text-white">{algo.accuracy}%</p>
                </div>
                <div className="p-2 bg-white/5 rounded-lg">
                  <p className="text-[10px] text-[#A9B3C2] mb-0.5">Latency</p>
                  <p className="text-sm font-semibold text-white">{algo.latency}ms</p>
                </div>
              </div>

              {/* Status */}
              <div className="flex items-center justify-between pt-3 border-t border-white/10">
                <div className="flex items-center gap-1.5">
                  <StatusIcon 
                    className="w-3.5 h-3.5"
                    style={{ color: statusConfig[algo.status].color }}
                  />
                  <span 
                    className="text-xs"
                    style={{ color: statusConfig[algo.status].color }}
                  >
                    {statusConfig[algo.status].label}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[#A9B3C2]">
                  <Clock className="w-3 h-3" />
                  <span className="text-[10px]">
                    {model ? Math.floor((Date.now() - model.lastUpdated.getTime()) / (1000 * 60 * 60 * 24)) : 0}d
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Model Health Summary */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-sm text-[#A9B3C2]">Model Health</span>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[#22C55E]/10 rounded-lg">
                <Activity className="w-4 h-4 text-[#22C55E]" />
                <span className="text-sm text-[#22C55E]">Avg Latency: 42ms</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg">
                <CheckCircle className="w-4 h-4 text-[#22C55E]" />
                <span className="text-sm text-[#A9B3C2]">Drift: None</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg">
                <Clock className="w-4 h-4 text-[#A9B3C2]" />
                <span className="text-sm text-[#A9B3C2]">Retrain: 6d</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
