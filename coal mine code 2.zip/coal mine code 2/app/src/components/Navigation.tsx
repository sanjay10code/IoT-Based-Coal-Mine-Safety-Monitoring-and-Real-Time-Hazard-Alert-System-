import { useApp } from '@/context/AppContext';
import type { PageId, UserRole } from '@/types';
import { 
  LayoutDashboard, 
  Activity, 
  Map, 
  Bell, 
  Brain, 
  FileText, 
  Settings,
  User,
  Shield,
  Menu,
  X,
  Upload
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  id: PageId;
  label: string;
  icon: React.ElementType;
  allowedRoles: UserRole[];
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, allowedRoles: ['operator', 'supervisor'] },
  { id: 'dataimport', label: 'Data Import', icon: Upload, allowedRoles: ['operator', 'supervisor'] },
  { id: 'sensors', label: 'Live Sensors', icon: Activity, allowedRoles: ['operator', 'supervisor'] },
  { id: 'riskmap', label: 'Risk Map', icon: Map, allowedRoles: ['operator', 'supervisor'] },
  { id: 'alerts', label: 'Alerts', icon: Bell, allowedRoles: ['operator', 'supervisor'] },
  { id: 'models', label: 'Models', icon: Brain, allowedRoles: ['supervisor'] },
  { id: 'reports', label: 'Reports', icon: FileText, allowedRoles: ['supervisor'] },
  { id: 'admin', label: 'Admin', icon: Settings, allowedRoles: ['supervisor'] },
];

export function Navigation() {
  const { userRole, setUserRole, currentPage, setCurrentPage } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const filteredNavItems = navItems.filter(item => item.allowedRoles.includes(userRole));

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0B0E13]/90 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#FF4D00] to-[#E04400] flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div className="hidden sm:block">
              <span className="text-lg font-bold text-white tracking-tight">CoalMine</span>
              <span className="text-lg font-bold text-[#FF4D00] tracking-tight ml-1">Sentinel</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive 
                      ? 'bg-[#FF4D00]/15 text-[#FF4D00] border border-[#FF4D00]/30' 
                      : 'text-[#A9B3C2] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Right Section - Role Switcher */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center bg-white/5 rounded-lg p-1 border border-white/10">
              <button
                onClick={() => setUserRole('operator')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                  userRole === 'operator'
                    ? 'bg-[#FF4D00]/20 text-[#FF4D00]'
                    : 'text-[#A9B3C2] hover:text-white'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                Operator
              </button>
              <button
                onClick={() => setUserRole('supervisor')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium transition-all duration-200 ${
                  userRole === 'supervisor'
                    ? 'bg-[#FF4D00]/20 text-[#FF4D00]'
                    : 'text-[#A9B3C2] hover:text-white'
                }`}
              >
                <Shield className="w-3.5 h-3.5" />
                Supervisor
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-[#A9B3C2] hover:text-white hover:bg-white/5 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-white/5 bg-[#0B0E13]/95 backdrop-blur-xl">
          <div className="px-4 py-4 space-y-2">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive 
                      ? 'bg-[#FF4D00]/15 text-[#FF4D00] border border-[#FF4D00]/30' 
                      : 'text-[#A9B3C2] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
            
            {/* Mobile Role Switcher */}
            <div className="pt-4 border-t border-white/10">
              <p className="text-xs text-[#A9B3C2] mb-2 px-4">Switch Role</p>
              <div className="flex gap-2 px-4">
                <button
                  onClick={() => setUserRole('operator')}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
                    userRole === 'operator'
                      ? 'bg-[#FF4D00]/20 text-[#FF4D00] border border-[#FF4D00]/30'
                      : 'text-[#A9B3C2] hover:text-white bg-white/5'
                  }`}
                >
                  <User className="w-4 h-4" />
                  Operator
                </button>
                <button
                  onClick={() => setUserRole('supervisor')}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200 ${
                    userRole === 'supervisor'
                      ? 'bg-[#FF4D00]/20 text-[#FF4D00] border border-[#FF4D00]/30'
                      : 'text-[#A9B3C2] hover:text-white bg-white/5'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  Supervisor
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
