import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Wind, Flame, Droplets, Thermometer, Cloud, Activity, AlertCircle } from 'lucide-react';
import type { SensorType } from '@/types';

const sensorConfig: Record<SensorType, { icon: React.ElementType; label: string; unit: string; threshold: number }> = {
  CH4: { icon: Flame, label: 'Methane (CH₄)', unit: '%', threshold: 1.0 },
  CO: { icon: Wind, label: 'Carbon Monoxide', unit: 'ppm', threshold: 25 },
  O2: { icon: Droplets, label: 'Oxygen', unit: '%', threshold: 19.5 },
  dust: { icon: Cloud, label: 'Dust', unit: 'mg/m³', threshold: 3.0 },
  temperature: { icon: Thermometer, label: 'Temperature', unit: '°C', threshold: 35 },
  humidity: { icon: Droplets, label: 'Humidity', unit: '%', threshold: 85 },
  vibration: { icon: Activity, label: 'Vibration', unit: 'mm/s', threshold: 4.0 },
};

export function LiveRiskOverview() {
  const { sensors, alerts } = useApp();

  // Get latest reading for each sensor type
  const getLatestByType = (type: SensorType) => {
    const typeSensors = sensors.filter(s => s.type === type);
    return typeSensors.length > 0 ? typeSensors[0] : null;
  };

  const sensorTypes: SensorType[] = ['CH4', 'CO', 'O2', 'dust', 'temperature', 'humidity', 'vibration'];

  return (
    <div className="card-dark p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Live Risk Overview</h3>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#22C55E] status-pulse-low" />
          <span className="text-xs font-mono text-[#22C55E]">Live</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
        {sensorTypes.map((type, index) => {
          const sensor = getLatestByType(type);
          const config = sensorConfig[type];
          const Icon = config.icon;
          
          if (!sensor) return null;

          const isWarning = sensor.status === 'warning';
          const isCritical = sensor.status === 'critical';

          return (
            <motion.div
              key={type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`p-3 rounded-lg border transition-all duration-300 ${
                isCritical 
                  ? 'bg-[#EF4444]/10 border-[#EF4444]/40 status-pulse-high'
                  : isWarning
                  ? 'bg-[#F59E0B]/10 border-[#F59E0B]/40'
                  : 'bg-white/5 border-white/10'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${
                  isCritical ? 'text-[#EF4444]' : isWarning ? 'text-[#F59E0B]' : 'text-[#22C55E]'
                }`} />
                <span className="text-xs text-[#A9B3C2] truncate">{config.label}</span>
              </div>
              <div className="flex items-baseline gap-1">
                <span className={`text-xl font-bold ${
                  isCritical ? 'text-[#EF4444]' : isWarning ? 'text-[#F59E0B]' : 'text-white'
                }`}>
                  {sensor.value.toFixed(type === 'CH4' ? 2 : type === 'temperature' ? 1 : 0)}
                </span>
                <span className="text-xs text-[#A9B3C2]">{config.unit}</span>
              </div>
              <div className="mt-2 flex items-center gap-1">
                <div className={`w-1.5 h-1.5 rounded-full ${
                  isCritical ? 'bg-[#EF4444]' : isWarning ? 'bg-[#F59E0B]' : 'bg-[#22C55E]'
                }`} />
                <span className={`text-xs capitalize ${
                  isCritical ? 'text-[#EF4444]' : isWarning ? 'text-[#F59E0B]' : 'text-[#22C55E]'
                }`}>
                  {sensor.status}
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Recent Alerts Mini Feed */}
      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="flex items-center gap-2 mb-3">
          <AlertCircle className="w-4 h-4 text-[#FF4D00]" />
          <span className="text-sm font-medium text-white">Recent Alerts</span>
        </div>
        <div className="space-y-2">
          {alerts.slice(0, 3).map((alert, index) => (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="flex items-center justify-between p-2 rounded-lg bg-white/5"
            >
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono text-[#A9B3C2]">
                  {alert.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                <span className="text-sm text-white">{alert.zoneName}</span>
                <span className="text-xs text-[#A9B3C2]">{alert.message}</span>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                alert.severity === 'critical' ? 'bg-[#EF4444]/20 text-[#EF4444]' :
                alert.severity === 'high' ? 'bg-[#F59E0B]/20 text-[#F59E0B]' :
                alert.severity === 'medium' ? 'bg-[#FF4D00]/20 text-[#FF4D00]' :
                'bg-[#22C55E]/20 text-[#22C55E]'
              }`}>
                {alert.status}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
