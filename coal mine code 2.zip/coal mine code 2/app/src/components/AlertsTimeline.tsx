import { useApp } from '@/context/AppContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Search, Filter, CheckCircle, AlertTriangle, Clock, XCircle, Flame, Wind, Thermometer, Cloud, Droplets, Zap } from 'lucide-react';
import { useState } from 'react';
import type { RiskLevel, SensorType } from '@/types';

const sensorIcons: Record<SensorType, React.ElementType> = {
  CH4: Flame,
  CO: Wind,
  O2: Droplets,
  dust: Cloud,
  temperature: Thermometer,
  humidity: Droplets,
  vibration: Zap,
};

const severityConfig: Record<RiskLevel, { color: string; bg: string; icon: React.ElementType }> = {
  low: { color: '#22C55E', bg: 'rgba(34, 197, 94, 0.15)', icon: CheckCircle },
  medium: { color: '#F59E0B', bg: 'rgba(245, 158, 11, 0.15)', icon: AlertTriangle },
  high: { color: '#EF4444', bg: 'rgba(239, 68, 68, 0.15)', icon: AlertTriangle },
  critical: { color: '#FF4D00', bg: 'rgba(255, 77, 0, 0.2)', icon: XCircle },
};

const statusConfig = {
  active: { label: 'Active', color: '#EF4444' },
  monitoring: { label: 'Monitoring', color: '#F59E0B' },
  resolved: { label: 'Resolved', color: '#22C55E' },
};

export function AlertsTimeline() {
  const { alerts, resolveAlert, acknowledgeAlert } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<RiskLevel | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'monitoring' | 'resolved'>('all');

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    const matchesSearch = 
      alert.zoneName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alert.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alert.sensorType.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || alert.status === statusFilter;
    
    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const severityCounts = {
    all: alerts.length,
    critical: alerts.filter(a => a.severity === 'critical').length,
    high: alerts.filter(a => a.severity === 'high').length,
    medium: alerts.filter(a => a.severity === 'medium').length,
    low: alerts.filter(a => a.severity === 'low').length,
  };

  return (
    <div className="card-dark p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Alerts Timeline</h3>
          <span className="ml-2 px-2 py-0.5 bg-[#FF4D00]/20 text-[#FF4D00] text-xs rounded-full">
            {filteredAlerts.length}
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-4 mb-6">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A9B3C2]" />
          <input
            type="text"
            placeholder="Search alerts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-[#A9B3C2] focus:outline-none focus:border-[#FF4D00]/50 transition-colors"
          />
        </div>

        {/* Severity Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#A9B3C2]" />
          <div className="flex flex-wrap gap-1">
            {(['all', 'critical', 'high', 'medium', 'low'] as const).map((severity) => (
              <button
                key={severity}
                onClick={() => setSeverityFilter(severity)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                  severityFilter === severity
                    ? 'bg-[#FF4D00]/20 text-[#FF4D00] border border-[#FF4D00]/30'
                    : 'bg-white/5 text-[#A9B3C2] border border-transparent hover:border-white/10'
                }`}
              >
                {severity === 'all' ? 'All' : severity.charAt(0).toUpperCase() + severity.slice(1)}
                <span className="ml-1.5 opacity-60">({severityCounts[severity]})</span>
              </button>
            ))}
          </div>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#A9B3C2]" />
          <div className="flex flex-wrap gap-1">
            {(['all', 'active', 'monitoring', 'resolved'] as const).map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${
                  statusFilter === status
                    ? 'bg-[#FF4D00]/20 text-[#FF4D00] border border-[#FF4D00]/30'
                    : 'bg-white/5 text-[#A9B3C2] border border-transparent hover:border-white/10'
                }`}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
        <AnimatePresence>
          {filteredAlerts.map((alert, index) => {
            const SeverityIcon = severityConfig[alert.severity].icon;
            const SensorIcon = sensorIcons[alert.sensorType];
            
            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
                className={`alert-row p-3 rounded-lg border ${
                  alert.severity === 'critical' ? 'bg-[#EF4444]/5 border-[#EF4444]/20' :
                  alert.severity === 'high' ? 'bg-[#F59E0B]/5 border-[#F59E0B]/20' :
                  alert.severity === 'medium' ? 'bg-[#FF4D00]/5 border-[#FF4D00]/20' :
                  'bg-white/5 border-white/10'
                }`}
              >
                <div className="flex items-start gap-3">
                  {/* Severity Indicator */}
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: severityConfig[alert.severity].bg }}
                  >
                    <SeverityIcon 
                      className="w-4 h-4"
                      style={{ color: severityConfig[alert.severity].color }}
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-grow min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono text-[#A9B3C2]">
                        {alert.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <span className="text-sm font-medium text-white">{alert.zoneName}</span>
                      <div className="flex items-center gap-1 px-1.5 py-0.5 bg-white/5 rounded">
                        <SensorIcon className="w-3 h-3 text-[#A9B3C2]" />
                        <span className="text-xs text-[#A9B3C2]">{alert.sensorType}</span>
                      </div>
                    </div>
                    <p className="text-sm text-[#A9B3C2] mt-1 truncate">{alert.message}</p>
                  </div>

                  {/* Status & Actions */}
                  <div className="flex flex-col items-end gap-2">
                    <span 
                      className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{ 
                        backgroundColor: statusConfig[alert.status].color + '20',
                        color: statusConfig[alert.status].color
                      }}
                    >
                      {statusConfig[alert.status].label}
                    </span>
                    
                    {alert.status === 'active' && (
                      <div className="flex gap-1">
                        <button
                          onClick={() => acknowledgeAlert(alert.id)}
                          className="p-1.5 rounded bg-[#F59E0B]/10 text-[#F59E0B] hover:bg-[#F59E0B]/20 transition-colors"
                          title="Acknowledge"
                        >
                          <Clock className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => resolveAlert(alert.id)}
                          className="p-1.5 rounded bg-[#22C55E]/10 text-[#22C55E] hover:bg-[#22C55E]/20 transition-colors"
                          title="Resolve"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                    
                    {alert.status === 'monitoring' && (
                      <button
                        onClick={() => resolveAlert(alert.id)}
                        className="p-1.5 rounded bg-[#22C55E]/10 text-[#22C55E] hover:bg-[#22C55E]/20 transition-colors"
                        title="Resolve"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {filteredAlerts.length === 0 && (
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-[#22C55E] mx-auto mb-3 opacity-50" />
            <p className="text-[#A9B3C2]">No alerts match your filters</p>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap gap-4 text-xs">
        <span className="text-[#A9B3C2]">Severity:</span>
        {(['critical', 'high', 'medium', 'low'] as RiskLevel[]).map((severity) => (
          <div key={severity} className="flex items-center gap-1.5">
            <div 
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: severityConfig[severity].color }}
            />
            <span className="text-[#A9B3C2] capitalize">{severity}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
