import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { TrendingUp, Shield, Award } from 'lucide-react';
import { useEffect, useState } from 'react';

export function SafetyScoreGauge() {
  const { safetyMetrics } = useApp();
  const [animatedScore, setAnimatedScore] = useState(0);
  
  const score = safetyMetrics.overallScore;
  const circumference = 2 * Math.PI * 80;
  const strokeDashoffset = circumference - (animatedScore / 100) * circumference;
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedScore(score);
    }, 300);
    return () => clearTimeout(timer);
  }, [score]);

  const getScoreColor = (s: number) => {
    if (s >= 90) return '#22C55E';
    if (s >= 75) return '#F59E0B';
    if (s >= 60) return '#EF4444';
    return '#FF4D00';
  };

  const scoreColor = getScoreColor(score);

  return (
    <div className="card-dark p-6 h-full">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="w-5 h-5 text-[#FF4D00]" />
        <h3 className="text-lg font-semibold text-white">Safety Score</h3>
      </div>

      <div className="flex flex-col items-center">
        {/* Gauge */}
        <div className="relative w-48 h-48">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
            <defs>
              <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#EF4444" />
                <stop offset="50%" stopColor="#F59E0B" />
                <stop offset="100%" stopColor="#22C55E" />
              </linearGradient>
            </defs>
            
            {/* Background Circle */}
            <circle
              cx="100"
              cy="100"
              r="80"
              fill="none"
              stroke="rgba(255,255,255,0.1)"
              strokeWidth="12"
            />
            
            {/* Progress Circle */}
            <motion.circle
              cx="100"
              cy="100"
              r="80"
              fill="none"
              stroke="url(#gaugeGradient)"
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          </svg>
          
          {/* Center Content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.span 
              className="text-5xl font-bold"
              style={{ color: scoreColor }}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              {animatedScore}
            </motion.span>
            <span className="text-xs text-[#A9B3C2] mt-1">out of 100</span>
          </div>
        </div>

        {/* Score Details */}
        <div className="mt-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Award className="w-5 h-5 text-[#FF4D00]" />
            <span className="text-lg font-semibold text-white">Top 10%</span>
          </div>
          <p className="text-sm text-[#A9B3C2]">
            For comparable mining sites
          </p>
        </div>

        {/* Days Without Incident */}
        <div className="mt-6 w-full p-4 bg-[#22C55E]/10 border border-[#22C55E]/30 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm text-[#A9B3C2]">Days Without Incident</span>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#22C55E]" />
              <span className="text-2xl font-bold text-[#22C55E]">
                {safetyMetrics.daysWithoutIncident}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
