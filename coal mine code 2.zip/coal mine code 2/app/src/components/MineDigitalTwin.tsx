import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Map, Info, AlertTriangle, Wind, Flame, Thermometer } from 'lucide-react';
import { useState } from 'react';
import type { RiskLevel, Zone } from '@/types';

const riskColors: Record<RiskLevel, string> = {
  low: '#22C55E',
  medium: '#F59E0B',
  high: '#EF4444',
  critical: '#FF4D00',
};

const riskBgColors: Record<RiskLevel, string> = {
  low: 'rgba(34, 197, 94, 0.15)',
  medium: 'rgba(245, 158, 11, 0.2)',
  high: 'rgba(239, 68, 68, 0.25)',
  critical: 'rgba(255, 77, 0, 0.3)',
};

export function MineDigitalTwin() {
  const { zones, getZoneSensors } = useApp();
  const [selectedZone, setSelectedZone] = useState<Zone | null>(null);
  const [hoveredZone, setHoveredZone] = useState<string | null>(null);

  return (
    <div className="card-dark p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Map className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Live Mine Digital Twin</h3>
        </div>
        <div className="flex items-center gap-4">
          {/* Legend */}
          <div className="flex items-center gap-3 text-xs">
            {(['low', 'medium', 'high', 'critical'] as RiskLevel[]).map((level) => (
              <div key={level} className="flex items-center gap-1.5">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: riskColors[level] }}
                />
                <span className="text-[#A9B3C2] capitalize">{level}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Schematic */}
        <div className="lg:col-span-3">
          <div className="zone-schematic aspect-[16/9] relative">
            {/* Grid Background */}
            <div className="absolute inset-0 opacity-30">
              <svg width="100%" height="100%">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
            </div>

            {/* Tunnel Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {/* Main shaft connection */}
              <line x1="21%" y1="27.5%" x2="35%" y2="40%" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
              {/* Tunnel to vent */}
              <line x1="60%" y1="40%" x2="75%" y2="35%" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
              {/* Tunnel to staging */}
              <line x1="47.5%" y1="40%" x2="59%" y2="66%" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
              {/* To emergency exit */}
              <line x1="68%" y1="35%" x2="84%" y2="77.5%" stroke="rgba(255,255,255,0.2)" strokeWidth="2" strokeDasharray="5,5" />
            </svg>

            {/* Zones */}
            {zones.map((zone, index) => {
              const isHovered = hoveredZone === zone.id;
              const isSelected = selectedZone?.id === zone.id;
              const zoneSensors = getZoneSensors(zone.id);
              
              return (
                <motion.div
                  key={zone.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="absolute cursor-pointer transition-all duration-300"
                  style={{
                    left: `${zone.coordinates.x}%`,
                    top: `${zone.coordinates.y}%`,
                    width: `${zone.coordinates.width}%`,
                    height: `${zone.coordinates.height}%`,
                  }}
                  onMouseEnter={() => setHoveredZone(zone.id)}
                  onMouseLeave={() => setHoveredZone(null)}
                  onClick={() => setSelectedZone(zone)}
                >
                  <div 
                    className={`w-full h-full rounded-lg border-2 transition-all duration-300 ${
                      isSelected ? 'border-[#FF4D00]' : 'border-transparent'
                    } ${isHovered ? 'scale-105' : ''}`}
                    style={{
                      backgroundColor: riskBgColors[zone.riskLevel],
                      boxShadow: isHovered ? `0 0 20px ${riskColors[zone.riskLevel]}40` : 'none',
                    }}
                  >
                    {/* Zone Label */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-2">
                      <span className="text-xs sm:text-sm font-semibold text-white text-center">
                        {zone.name}
                      </span>
                      <div 
                        className="w-2 h-2 rounded-full mt-1"
                        style={{ backgroundColor: riskColors[zone.riskLevel] }}
                      />
                    </div>

                    {/* Sensor Icons */}
                    <div className="absolute -top-2 -right-2 flex flex-wrap gap-1">
                      {zoneSensors.slice(0, 3).map((sensor, i) => (
                        <div 
                          key={i}
                          className={`w-5 h-5 rounded-full flex items-center justify-center ${
                            sensor.status === 'critical' ? 'bg-[#EF4444] status-pulse-high' :
                            sensor.status === 'warning' ? 'bg-[#F59E0B]' :
                            'bg-[#22C55E]'
                          }`}
                        >
                          {sensor.type === 'CH4' && <Flame className="w-3 h-3 text-white" />}
                          {sensor.type === 'CO' && <Wind className="w-3 h-3 text-white" />}
                          {sensor.type === 'temperature' && <Thermometer className="w-3 h-3 text-white" />}
                          {!['CH4', 'CO', 'temperature'].includes(sensor.type) && (
                            <div className="w-1.5 h-1.5 rounded-full bg-white" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}

            {/* Labels */}
            <div className="absolute bottom-2 left-2 text-xs text-[#A9B3C2] font-mono">
              Scale: 1:500
            </div>
            <div className="absolute bottom-2 right-2 text-xs text-[#A9B3C2] font-mono">
              Last updated: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>

        {/* Zone List Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white/5 rounded-lg border border-white/10 p-4 h-full">
            <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Info className="w-4 h-4 text-[#FF4D00]" />
              Zone Status
            </h4>
            <div className="space-y-2">
              {zones.map((zone) => {
                const zoneSensors = getZoneSensors(zone.id);
                const criticalCount = zoneSensors.filter(s => s.status === 'critical').length;
                const warningCount = zoneSensors.filter(s => s.status === 'warning').length;
                
                return (
                  <motion.div
                    key={zone.id}
                    whileHover={{ x: 4 }}
                    className={`p-3 rounded-lg cursor-pointer transition-all duration-200 ${
                      selectedZone?.id === zone.id 
                        ? 'bg-[#FF4D00]/20 border border-[#FF4D00]/40' 
                        : 'bg-white/5 border border-transparent hover:border-white/10'
                    }`}
                    onClick={() => setSelectedZone(zone)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-white">{zone.name}</span>
                      <span 
                        className="text-xs px-2 py-0.5 rounded-full capitalize"
                        style={{ 
                          backgroundColor: riskBgColors[zone.riskLevel],
                          color: riskColors[zone.riskLevel]
                        }}
                      >
                        {zone.riskLevel}
                      </span>
                    </div>
                    <p className="text-xs text-[#A9B3C2] mb-2">{zone.description}</p>
                    <div className="flex items-center gap-2">
                      {criticalCount > 0 && (
                        <span className="flex items-center gap-1 text-xs text-[#EF4444]">
                          <AlertTriangle className="w-3 h-3" />
                          {criticalCount} critical
                        </span>
                      )}
                      {warningCount > 0 && (
                        <span className="flex items-center gap-1 text-xs text-[#F59E0B]">
                          <AlertTriangle className="w-3 h-3" />
                          {warningCount} warning
                        </span>
                      )}
                      {criticalCount === 0 && warningCount === 0 && (
                        <span className="text-xs text-[#22C55E]">All sensors normal</span>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Selected Zone Details */}
      {selectedZone && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-6 pt-6 border-t border-white/10"
        >
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-semibold text-white">{selectedZone.name} Details</h4>
            <button 
              onClick={() => setSelectedZone(null)}
              className="text-xs text-[#A9B3C2] hover:text-white"
            >
              Close
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {getZoneSensors(selectedZone.id).map((sensor) => (
              <div 
                key={sensor.id}
                className={`p-3 rounded-lg border ${
                  sensor.status === 'critical' ? 'bg-[#EF4444]/10 border-[#EF4444]/30' :
                  sensor.status === 'warning' ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30' :
                  'bg-white/5 border-white/10'
                }`}
              >
                <p className="text-xs text-[#A9B3C2] mb-1">{sensor.name}</p>
                <p className={`text-lg font-bold ${
                  sensor.status === 'critical' ? 'text-[#EF4444]' :
                  sensor.status === 'warning' ? 'text-[#F59E0B]' :
                  'text-white'
                }`}>
                  {sensor.value.toFixed(sensor.type === 'CH4' ? 2 : 1)} {sensor.unit}
                </p>
                <p className={`text-xs capitalize ${
                  sensor.status === 'critical' ? 'text-[#EF4444]' :
                  sensor.status === 'warning' ? 'text-[#F59E0B]' :
                  'text-[#22C55E]'
                }`}>
                  {sensor.status}
                </p>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
