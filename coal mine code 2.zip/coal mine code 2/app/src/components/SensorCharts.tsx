import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Activity, Flame, Wind, Droplets, Thermometer, Cloud, Zap } from 'lucide-react';
import { useState } from 'react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import type { SensorType } from '@/types';

interface ChartConfig {
  type: SensorType;
  label: string;
  icon: React.ElementType;
  color: string;
  unit: string;
  threshold: number;
}

const chartConfigs: ChartConfig[] = [
  { type: 'CH4', label: 'Methane (CH₄)', icon: Flame, color: '#FF4D00', unit: '%', threshold: 1.0 },
  { type: 'CO', label: 'Carbon Monoxide', icon: Wind, color: '#EF4444', unit: 'ppm', threshold: 25 },
  { type: 'O2', label: 'Oxygen', icon: Droplets, color: '#3B82F6', unit: '%', threshold: 19.5 },
  { type: 'dust', label: 'Dust Particles', icon: Cloud, color: '#F59E0B', unit: 'mg/m³', threshold: 3.0 },
  { type: 'temperature', label: 'Temperature', icon: Thermometer, color: '#EC4899', unit: '°C', threshold: 35 },
  { type: 'humidity', label: 'Humidity', icon: Droplets, color: '#06B6D4', unit: '%', threshold: 85 },
  { type: 'vibration', label: 'Vibration', icon: Zap, color: '#8B5CF6', unit: 'mm/s', threshold: 4.0 },
];

export function SensorCharts() {
  const { sensors } = useApp();
  const [selectedType, setSelectedType] = useState<SensorType>('CH4');

  const selectedConfig = chartConfigs.find(c => c.type === selectedType)!;
  const selectedSensors = sensors.filter(s => s.type === selectedType);

  // Prepare chart data
  const prepareChartData = () => {
    if (selectedSensors.length === 0) return [];
    
    const history = selectedSensors[0].history;
    return history.map((reading) => ({
      time: reading.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      value: reading.value,
      threshold: selectedConfig.threshold,
    }));
  };

  const chartData = prepareChartData();

  return (
    <div className="card-dark p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Sensor Trends</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#A9B3C2]">Last 24 hours</span>
        </div>
      </div>

      {/* Sensor Type Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {chartConfigs.map((config) => {
          const Icon = config.icon;
          const isActive = selectedType === config.type;
          const hasAlert = sensors.some(s => s.type === config.type && (s.status === 'warning' || s.status === 'critical'));
          
          return (
            <button
              key={config.type}
              onClick={() => setSelectedType(config.type)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                isActive
                  ? 'bg-[#FF4D00]/15 text-[#FF4D00] border border-[#FF4D00]/30'
                  : 'bg-white/5 text-[#A9B3C2] border border-transparent hover:border-white/10 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{config.label}</span>
              <span className="sm:hidden">{config.type}</span>
              {hasAlert && (
                <div className="w-2 h-2 rounded-full bg-[#EF4444] status-pulse-high" />
              )}
            </button>
          );
        })}
      </div>

      {/* Chart */}
      <div className="h-64 sm:h-80">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={selectedConfig.color} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={selectedConfig.color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis 
              dataKey="time" 
              stroke="#A9B3C2"
              fontSize={11}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#A9B3C2"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              domain={['auto', 'auto']}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#111827',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
                fontSize: '12px',
              }}
              labelStyle={{ color: '#A9B3C2' }}
              itemStyle={{ color: selectedConfig.color }}
              formatter={(value: number) => [`${value.toFixed(2)} ${selectedConfig.unit}`, selectedConfig.label]}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={selectedConfig.color}
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorValue)"
            />
            {/* Threshold Line - rendered as reference */}
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Current Values */}
      <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {selectedSensors.map((sensor, idx) => (
          <motion.div
            key={sensor.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className={`p-3 rounded-lg border ${
              sensor.status === 'critical' ? 'bg-[#EF4444]/10 border-[#EF4444]/30' :
              sensor.status === 'warning' ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30' :
              'bg-white/5 border-white/10'
            }`}
          >
            <p className="text-xs text-[#A9B3C2] mb-1">{sensor.name}</p>
            <div className="flex items-baseline gap-1">
              <span className={`text-xl font-bold ${
                sensor.status === 'critical' ? 'text-[#EF4444]' :
                sensor.status === 'warning' ? 'text-[#F59E0B]' :
                'text-white'
              }`}>
                {sensor.value.toFixed(selectedType === 'CH4' ? 2 : 1)}
              </span>
              <span className="text-xs text-[#A9B3C2]">{selectedConfig.unit}</span>
            </div>
            <div className="mt-1 flex items-center gap-1">
              <div className={`w-1.5 h-1.5 rounded-full ${
                sensor.status === 'critical' ? 'bg-[#EF4444]' :
                sensor.status === 'warning' ? 'bg-[#F59E0B]' :
                'bg-[#22C55E]'
              }`} />
              <span className={`text-xs capitalize ${
                sensor.status === 'critical' ? 'text-[#EF4444]' :
                sensor.status === 'warning' ? 'text-[#F59E0B]' :
                'text-[#22C55E]'
              }`}>
                {sensor.status}
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Threshold Indicator */}
      <div className="mt-4 flex items-center justify-end gap-2 text-xs text-[#A9B3C2]">
        <div className="w-4 h-0.5 bg-[#EF4444] border-dashed" style={{ borderTop: '1px dashed #EF4444' }} />
        <span>Threshold: {selectedConfig.threshold} {selectedConfig.unit}</span>
      </div>
    </div>
  );
}
