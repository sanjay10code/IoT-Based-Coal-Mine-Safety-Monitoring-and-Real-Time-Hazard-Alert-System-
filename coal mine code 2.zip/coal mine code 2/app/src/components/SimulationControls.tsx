import { useApp } from '@/context/AppContext';

import { FlaskConical, Flame, Wind, Thermometer, Play, RotateCcw, AlertTriangle, CheckCircle } from 'lucide-react';
import { useState } from 'react';

export function SimulationControls() {
  const { simulation, updateSimulation, applySimulation, resetSimulation } = useApp();
  const [isSimulating, setIsSimulating] = useState(false);

  const handleApply = () => {
    setIsSimulating(true);
    applySimulation();
    setTimeout(() => setIsSimulating(false), 1000);
  };

  const handleReset = () => {
    resetSimulation();
    setIsSimulating(false);
  };

  const getRiskColor = () => {
    switch (simulation.predictedRisk) {
      case 'critical': return '#FF4D00';
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      default: return '#22C55E';
    }
  };

  const getRiskBg = () => {
    switch (simulation.predictedRisk) {
      case 'critical': return 'rgba(255, 77, 0, 0.2)';
      case 'high': return 'rgba(239, 68, 68, 0.2)';
      case 'medium': return 'rgba(245, 158, 11, 0.2)';
      default: return 'rgba(34, 197, 94, 0.2)';
    }
  };

  return (
    <div className="card-dark p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-[#FF4D00]" />
          <h3 className="text-lg font-semibold text-white">Scenario Simulation</h3>
        </div>
        <div className="flex items-center gap-2">
          {isSimulating && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#FF4D00]/10 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-[#FF4D00] status-pulse-critical" />
              <span className="text-xs text-[#FF4D00]">Simulating...</span>
            </div>
          )}
        </div>
      </div>

      <p className="text-sm text-[#A9B3C2] mb-6">
        Test methane spikes, ventilation failures, and temperature events—before they happen. 
        Simulations run on anonymized historical data with no production impact.
      </p>

      {/* Sliders */}
      <div className="space-y-6 mb-6">
        {/* Methane Level Slider */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#FF4D00]" />
              <span className="text-sm text-white">Methane Level</span>
            </div>
            <span className="text-sm font-mono text-[#FF4D00]">
              {simulation.methaneLevel.toFixed(2)}%
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="2"
            step="0.01"
            value={simulation.methaneLevel}
            onChange={(e) => updateSimulation({ methaneLevel: parseFloat(e.target.value) })}
            className="simulation-slider"
          />
          <div className="flex justify-between mt-1 text-xs text-[#A9B3C2]">
            <span>0%</span>
            <span className="text-[#F59E0B]">Warning: 0.8%</span>
            <span className="text-[#EF4444]">Critical: 1.0%</span>
            <span>2%</span>
          </div>
        </div>

        {/* Ventilation Rate Slider */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Wind className="w-4 h-4 text-[#3B82F6]" />
              <span className="text-sm text-white">Ventilation Rate</span>
            </div>
            <span className="text-sm font-mono text-[#3B82F6]">
              {simulation.ventilationRate.toFixed(1)} m/s
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="5"
            step="0.1"
            value={simulation.ventilationRate}
            onChange={(e) => updateSimulation({ ventilationRate: parseFloat(e.target.value) })}
            className="simulation-slider"
          />
          <div className="flex justify-between mt-1 text-xs text-[#A9B3C2]">
            <span>0 m/s</span>
            <span>Normal: 2.5 m/s</span>
            <span>5 m/s</span>
          </div>
        </div>

        {/* Temperature Slider */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-[#EC4899]" />
              <span className="text-sm text-white">Temperature</span>
            </div>
            <span className="text-sm font-mono text-[#EC4899]">
              {simulation.temperature.toFixed(1)}°C
            </span>
          </div>
          <input
            type="range"
            min="10"
            max="50"
            step="0.5"
            value={simulation.temperature}
            onChange={(e) => updateSimulation({ temperature: parseFloat(e.target.value) })}
            className="simulation-slider"
          />
          <div className="flex justify-between mt-1 text-xs text-[#A9B3C2]">
            <span>10°C</span>
            <span className="text-[#F59E0B]">Warning: 30°C</span>
            <span className="text-[#EF4444]">Critical: 35°C</span>
            <span>50°C</span>
          </div>
        </div>
      </div>

      {/* Predicted Risk */}
      <div 
        className="p-4 rounded-lg border mb-6 transition-all duration-300"
        style={{ 
          backgroundColor: getRiskBg(),
          borderColor: getRiskColor() + '40'
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" style={{ color: getRiskColor() }} />
            <span className="text-sm text-white">Predicted Risk Level</span>
          </div>
          <span 
            className="text-lg font-bold capitalize"
            style={{ color: getRiskColor() }}
          >
            {simulation.predictedRisk}
          </span>
        </div>
        <p className="text-xs mt-2" style={{ color: getRiskColor() + 'CC' }}>
          {simulation.predictedRisk === 'critical' 
            ? 'Immediate evacuation recommended. Multiple safety thresholds exceeded.'
            : simulation.predictedRisk === 'high'
            ? 'Elevated risk detected. Increase monitoring frequency.'
            : simulation.predictedRisk === 'medium'
            ? 'Minor deviations from baseline. Continue normal operations.'
            : 'All parameters within normal operating ranges.'}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <button
          onClick={handleApply}
          disabled={isSimulating}
          className="flex-1 flex items-center justify-center gap-2 btn-primary py-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Play className="w-4 h-4" />
          Apply Simulation
        </button>
        <button
          onClick={handleReset}
          disabled={isSimulating}
          className="flex items-center justify-center gap-2 btn-secondary px-4 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RotateCcw className="w-4 h-4" />
          Reset
        </button>
      </div>

      {/* Disclaimer */}
      <p className="mt-4 text-xs text-[#A9B3C2] text-center">
        <CheckCircle className="w-3 h-3 inline mr-1" />
        No production systems affected. Simulation runs in isolated environment.
      </p>
    </div>
  );
}
