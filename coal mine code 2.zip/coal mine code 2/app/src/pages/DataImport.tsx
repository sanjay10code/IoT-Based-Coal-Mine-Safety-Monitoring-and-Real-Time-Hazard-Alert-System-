import { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  Upload, 
  FileText, 
  Download, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Database,
  RefreshCw,
  Trash2,
  FileSpreadsheet,
  Eye,
  Calendar,
  MapPin,
  Bell
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { 
  parseCSV, 
  processSensorData, 
  validateDataset,
  downloadSampleDataset,
  type ParsedDataset,
  type CSVRow
} from '@/utils/dataParser';

interface UploadStatus {
  type: 'idle' | 'uploading' | 'success' | 'error';
  message: string;
  errors?: string[];
}

export function DataImport() {
  const { importData, clearImportedData, importedData, isUsingImportedData, sensors, zones, alerts } = useApp();
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>({ type: 'idle', message: '' });
  const [previewData, setPreviewData] = useState<ParsedDataset | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const processFile = async (file: File) => {
    setUploadStatus({ type: 'uploading', message: 'Processing file...' });
    
    try {
      const text = await file.text();
      let rows: CSVRow[];
      
      if (file.name.endsWith('.csv')) {
        rows = parseCSV(text);
      } else if (file.name.endsWith('.json')) {
        const json = JSON.parse(text);
        rows = Array.isArray(json) ? json : json.data || [];
      } else {
        throw new Error('Unsupported file format. Please upload CSV or JSON.');
      }
      
      if (rows.length === 0) {
        throw new Error('No data rows found in file.');
      }
      
      const dataset = processSensorData(rows);
      const errors = validateDataset(dataset);
      
      if (errors.length > 0) {
        setUploadStatus({ 
          type: 'error', 
          message: 'Validation warnings found',
          errors 
        });
      } else {
        setUploadStatus({ type: 'success', message: 'File processed successfully!' });
      }
      
      setPreviewData(dataset);
    } catch (error) {
      setUploadStatus({ 
        type: 'error', 
        message: error instanceof Error ? error.message : 'Failed to process file'
      });
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleImport = () => {
    if (previewData) {
      importData(previewData);
      setUploadStatus({ type: 'success', message: 'Data imported successfully!' });
      setPreviewData(null);
    }
  };

  const handleClear = () => {
    clearImportedData();
    setPreviewData(null);
    setUploadStatus({ type: 'idle', message: '' });
  };

  const handleDownloadSample = () => {
    downloadSampleDataset();
  };

  const formatDate = (date: Date) => {
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Data <span className="text-[#FF4D00]">Import</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Upload sensor data to visualize and analyze your mine operations
            </p>
          </div>
          {isUsingImportedData && (
            <button
              onClick={handleClear}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/30 rounded-lg hover:bg-[#EF4444]/20 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              Clear Imported Data
            </button>
          )}
        </motion.div>

        {/* Current Data Status */}
        {isUsingImportedData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card-dark p-6 border-l-4 border-[#22C55E]"
          >
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle className="w-6 h-6 text-[#22C55E]" />
              <h3 className="text-lg font-semibold text-white">Using Imported Dataset</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <DataStat 
                icon={Database}
                label="Sensors"
                value={sensors.length}
                color="#3B82F6"
              />
              <DataStat 
                icon={MapPin}
                label="Zones"
                value={zones.length}
                color="#8B5CF6"
              />
              <DataStat 
                icon={Bell}
                label="Alerts"
                value={alerts.length}
                color="#F59E0B"
              />
              <DataStat 
                icon={Calendar}
                label="Imported"
                value={importedData?.metadata.importedAt ? formatDate(importedData.metadata.importedAt) : 'N/A'}
                color="#22C55E"
              />
            </div>
            {importedData?.metadata.dateRange && (
              <div className="mt-4 pt-4 border-t border-white/10">
                <p className="text-sm text-[#A9B3C2]">
                  Data Range: <span className="text-white">{formatDate(importedData.metadata.dateRange.start)}</span>
                  {' '}to{' '}
                  <span className="text-white">{formatDate(importedData.metadata.dateRange.end)}</span>
                </p>
                <p className="text-sm text-[#A9B3C2] mt-1">
                  Total Readings: <span className="text-white">{importedData.metadata.totalReadings.toLocaleString()}</span>
                </p>
              </div>
            )}
          </motion.div>
        )}

        {/* Upload Area */}
        {!previewData && !isUsingImportedData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div
              className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
                dragActive 
                  ? 'border-[#FF4D00] bg-[#FF4D00]/5' 
                  : 'border-white/20 bg-white/5 hover:border-white/40'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.json"
                onChange={handleFileChange}
                className="hidden"
              />
              
              <div className="flex flex-col items-center">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-all ${
                  dragActive ? 'bg-[#FF4D00]/20' : 'bg-white/10'
                }`}>
                  <Upload className={`w-10 h-10 ${dragActive ? 'text-[#FF4D00]' : 'text-[#A9B3C2]'}`} />
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-2">
                  Drop your data file here
                </h3>
                <p className="text-[#A9B3C2] mb-6">
                  or click to browse (CSV or JSON)
                </p>
                
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="btn-primary"
                >
                  Select File
                </button>
              </div>
            </div>

            {/* Sample Download */}
            <div className="mt-6 flex items-center justify-center gap-4">
              <span className="text-sm text-[#A9B3C2]">Don't have data?</span>
              <button
                onClick={handleDownloadSample}
                className="flex items-center gap-2 text-sm text-[#FF4D00] hover:underline"
              >
                <Download className="w-4 h-4" />
                Download Sample Dataset
              </button>
            </div>

            {/* File Format Info */}
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="card-dark p-6">
                <div className="flex items-center gap-2 mb-4">
                  <FileSpreadsheet className="w-5 h-5 text-[#FF4D00]" />
                  <h4 className="font-semibold text-white">CSV Format</h4>
                </div>
                <p className="text-sm text-[#A9B3C2] mb-4">
                  Your CSV file should include these columns:
                </p>
                <code className="block p-3 bg-black/30 rounded-lg text-xs text-[#A9B3C2] font-mono overflow-x-auto">
                  timestamp,sensor_id,sensor_type,zone_id,zone_name,value,unit,status
                </code>
              </div>
              
              <div className="card-dark p-6">
                <div className="flex items-center gap-2 mb-4">
                  <FileText className="w-5 h-5 text-[#FF4D00]" />
                  <h4 className="font-semibold text-white">Supported Sensors</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {['CH4', 'CO', 'O2', 'dust', 'temperature', 'humidity', 'vibration'].map(type => (
                    <span key={type} className="px-2 py-1 bg-white/5 rounded text-xs text-[#A9B3C2]">
                      {type}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Upload Status */}
        {uploadStatus.type !== 'idle' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`p-4 rounded-lg border ${
              uploadStatus.type === 'success' 
                ? 'bg-[#22C55E]/10 border-[#22C55E]/30' 
                : uploadStatus.type === 'error'
                ? 'bg-[#EF4444]/10 border-[#EF4444]/30'
                : uploadStatus.type === 'uploading'
                ? 'bg-[#FF4D00]/10 border-[#FF4D00]/30'
                : ''
            }`}
          >
            <div className="flex items-center gap-3">
              {uploadStatus.type === 'success' && <CheckCircle className="w-5 h-5 text-[#22C55E]" />}
              {uploadStatus.type === 'error' && <XCircle className="w-5 h-5 text-[#EF4444]" />}
              {uploadStatus.type === 'uploading' && <RefreshCw className="w-5 h-5 text-[#FF4D00] animate-spin" />}
              <span className={`text-sm ${
                uploadStatus.type === 'success' ? 'text-[#22C55E]' :
                uploadStatus.type === 'error' ? 'text-[#EF4444]' :
                'text-[#FF4D00]'
              }`}>
                {uploadStatus.message}
              </span>
            </div>
            {uploadStatus.errors && uploadStatus.errors.length > 0 && (
              <ul className="mt-3 space-y-1">
                {uploadStatus.errors.map((error, i) => (
                  <li key={i} className="text-xs text-[#EF4444] flex items-center gap-2">
                    <AlertTriangle className="w-3 h-3" />
                    {error}
                  </li>
                ))}
              </ul>
            )}
          </motion.div>
        )}

        {/* Preview Data */}
        {previewData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card-dark p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Eye className="w-5 h-5 text-[#FF4D00]" />
                Data Preview
              </h3>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPreviewData(null)}
                  className="px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  className="btn-primary"
                >
                  Import Data
                </button>
              </div>
            </div>

            {/* Preview Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
              <PreviewStat label="Sensors" value={previewData.sensors.length} />
              <PreviewStat label="Zones" value={previewData.zones.length} />
              <PreviewStat label="Alerts" value={previewData.alerts.length} />
              <PreviewStat label="Readings" value={previewData.metadata.totalReadings} />
            </div>

            {/* Sensors Preview */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-[#A9B3C2] mb-3">Sensors</h4>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">ID</th>
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">Type</th>
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">Zone</th>
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">Current Value</th>
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">Status</th>
                      <th className="text-left px-3 py-2 text-xs text-[#A9B3C2]">History Points</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.sensors.slice(0, 5).map((sensor) => (
                      <tr key={sensor.id} className="border-b border-white/5">
                        <td className="px-3 py-2 text-sm text-white">{sensor.id}</td>
                        <td className="px-3 py-2 text-sm text-[#A9B3C2]">{sensor.type}</td>
                        <td className="px-3 py-2 text-sm text-[#A9B3C2]">{sensor.zoneId}</td>
                        <td className="px-3 py-2 text-sm text-white">
                          {sensor.value.toFixed(2)} {sensor.unit}
                        </td>
                        <td className="px-3 py-2">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            sensor.status === 'critical' ? 'bg-[#EF4444]/20 text-[#EF4444]' :
                            sensor.status === 'warning' ? 'bg-[#F59E0B]/20 text-[#F59E0B]' :
                            'bg-[#22C55E]/20 text-[#22C55E]'
                          }`}>
                            {sensor.status}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-sm text-[#A9B3C2]">{sensor.history.length}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {previewData.sensors.length > 5 && (
                  <p className="text-xs text-[#A9B3C2] mt-2 text-center">
                    ...and {previewData.sensors.length - 5} more sensors
                  </p>
                )}
              </div>
            </div>

            {/* Zones Preview */}
            <div>
              <h4 className="text-sm font-medium text-[#A9B3C2] mb-3">Zones</h4>
              <div className="flex flex-wrap gap-2">
                {previewData.zones.map((zone) => (
                  <div 
                    key={zone.id}
                    className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg"
                  >
                    <MapPin className="w-4 h-4 text-[#A9B3C2]" />
                    <span className="text-sm text-white">{zone.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      zone.riskLevel === 'critical' ? 'bg-[#EF4444]/20 text-[#EF4444]' :
                      zone.riskLevel === 'high' ? 'bg-[#F59E0B]/20 text-[#F59E0B]' :
                      zone.riskLevel === 'medium' ? 'bg-[#FF4D00]/20 text-[#FF4D00]' :
                      'bg-[#22C55E]/20 text-[#22C55E]'
                    }`}>
                      {zone.riskLevel}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

interface DataStatProps {
  icon: React.ElementType;
  label: string;
  value: string | number;
  color: string;
}

function DataStat({ icon: Icon, label, value, color }: DataStatProps) {
  return (
    <div className="flex items-center gap-3">
      <div 
        className="w-10 h-10 rounded-lg flex items-center justify-center"
        style={{ backgroundColor: color + '20' }}
      >
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div>
        <p className="text-lg font-bold text-white">{value}</p>
        <p className="text-xs text-[#A9B3C2]">{label}</p>
      </div>
    </div>
  );
}

interface PreviewStatProps {
  label: string;
  value: number;
}

function PreviewStat({ label, value }: PreviewStatProps) {
  return (
    <div className="p-4 bg-white/5 rounded-lg text-center">
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-xs text-[#A9B3C2]">{label}</p>
    </div>
  );
}
