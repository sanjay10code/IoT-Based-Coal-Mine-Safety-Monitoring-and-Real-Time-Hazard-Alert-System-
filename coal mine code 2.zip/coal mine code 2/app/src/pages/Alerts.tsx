import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Bell, Search, Filter, Calendar, Download, CheckCircle, AlertTriangle, XCircle, Clock } from 'lucide-react';
import { useState } from 'react';
import type { RiskLevel } from '@/types';

const severityConfig: Record<RiskLevel, { color: string; bg: string; icon: React.ElementType }> = {
  low: { color: '#22C55E', bg: 'rgba(34, 197, 94, 0.15)', icon: CheckCircle },
  medium: { color: '#F59E0B', bg: 'rgba(245, 158, 11, 0.15)', icon: AlertTriangle },
  high: { color: '#EF4444', bg: 'rgba(239, 68, 68, 0.15)', icon: AlertTriangle },
  critical: { color: '#FF4D00', bg: 'rgba(255, 77, 0, 0.2)', icon: XCircle },
};

export function Alerts() {
  const { alerts, resolveAlert, acknowledgeAlert } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<RiskLevel | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'monitoring' | 'resolved'>('all');
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'all'>('today');

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    const matchesSearch = 
      alert.zoneName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alert.message.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesSeverity = severityFilter === 'all' || alert.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || alert.status === statusFilter;
    
    const now = new Date();
    const alertDate = new Date(alert.timestamp);
    let matchesDate = true;
    
    if (dateRange === 'today') {
      matchesDate = alertDate.toDateString() === now.toDateString();
    } else if (dateRange === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      matchesDate = alertDate >= weekAgo;
    } else if (dateRange === 'month') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      matchesDate = alertDate >= monthAgo;
    }
    
    return matchesSearch && matchesSeverity && matchesStatus && matchesDate;
  });

  const stats = {
    total: alerts.length,
    active: alerts.filter(a => a.status === 'active').length,
    monitoring: alerts.filter(a => a.status === 'monitoring').length,
    resolved: alerts.filter(a => a.status === 'resolved').length,
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Alert <span className="text-[#FF4D00]">Center</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Manage and respond to safety alerts across all zones
            </p>
          </div>
          <button className="flex items-center justify-center gap-2 btn-secondary">
            <Download className="w-4 h-4" />
            Export Report
          </button>
        </motion.div>

        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4"
        >
          <StatCard label="Total Alerts" value={stats.total} icon={Bell} color="#3B82F6" />
          <StatCard label="Active" value={stats.active} icon={AlertTriangle} color="#EF4444" pulse />
          <StatCard label="Monitoring" value={stats.monitoring} icon={Clock} color="#F59E0B" />
          <StatCard label="Resolved" value={stats.resolved} icon={CheckCircle} color="#22C55E" />
        </motion.div>

        {/* Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card-dark p-4"
        >
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A9B3C2]" />
              <input
                type="text"
                placeholder="Search alerts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-[#A9B3C2] focus:outline-none focus:border-[#FF4D00]/50"
              />
            </div>

            {/* Severity Filter */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#A9B3C2]" />
              <select
                value={severityFilter}
                onChange={(e) => setSeverityFilter(e.target.value as RiskLevel | 'all')}
                className="px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#FF4D00]/50"
              >
                <option value="all">All Severities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#FF4D00]/50"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="monitoring">Monitoring</option>
              <option value="resolved">Resolved</option>
            </select>

            {/* Date Range */}
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#A9B3C2]" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as typeof dateRange)}
                className="px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#FF4D00]/50"
              >
                <option value="today">Today</option>
                <option value="week">Last 7 Days</option>
                <option value="month">Last 30 Days</option>
                <option value="all">All Time</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Alerts Table */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="card-dark overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Time</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Zone</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Sensor</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Message</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Severity</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAlerts.map((alert, index) => {
                  const SeverityIcon = severityConfig[alert.severity].icon;
                  
                  return (
                    <motion.tr
                      key={alert.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + index * 0.03 }}
                      className="border-b border-white/5 hover:bg-white/5 transition-colors"
                    >
                      <td className="px-4 py-3 text-sm text-[#A9B3C2] font-mono">
                        {alert.timestamp.toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-sm text-white">{alert.zoneName}</td>
                      <td className="px-4 py-3 text-sm text-[#A9B3C2]">{alert.sensorType}</td>
                      <td className="px-4 py-3 text-sm text-white">{alert.message}</td>
                      <td className="px-4 py-3">
                        <div 
                          className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium"
                          style={{ 
                            backgroundColor: severityConfig[alert.severity].bg,
                            color: severityConfig[alert.severity].color
                          }}
                        >
                          <SeverityIcon className="w-3 h-3" />
                          <span className="capitalize">{alert.severity}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span 
                          className="inline-flex px-2 py-1 rounded-full text-xs font-medium capitalize"
                          style={{ 
                            backgroundColor: alert.status === 'active' ? '#EF444420' : alert.status === 'monitoring' ? '#F59E0B20' : '#22C55E20',
                            color: alert.status === 'active' ? '#EF4444' : alert.status === 'monitoring' ? '#F59E0B' : '#22C55E'
                          }}
                        >
                          {alert.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          {alert.status === 'active' && (
                            <>
                              <button
                                onClick={() => acknowledgeAlert(alert.id)}
                                className="p-1.5 rounded bg-[#F59E0B]/10 text-[#F59E0B] hover:bg-[#F59E0B]/20 transition-colors"
                                title="Acknowledge"
                              >
                                <Clock className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => resolveAlert(alert.id)}
                                className="p-1.5 rounded bg-[#22C55E]/10 text-[#22C55E] hover:bg-[#22C55E]/20 transition-colors"
                                title="Resolve"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {alert.status === 'monitoring' && (
                            <button
                              onClick={() => resolveAlert(alert.id)}
                              className="p-1.5 rounded bg-[#22C55E]/10 text-[#22C55E] hover:bg-[#22C55E]/20 transition-colors"
                              title="Resolve"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredAlerts.length === 0 && (
            <div className="text-center py-12">
              <CheckCircle className="w-12 h-12 text-[#22C55E] mx-auto mb-3 opacity-50" />
              <p className="text-[#A9B3C2]">No alerts match your filters</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
  pulse?: boolean;
}

function StatCard({ label, value, icon: Icon, color, pulse }: StatCardProps) {
  return (
    <div className="card-dark p-4">
      <div className="flex items-center gap-3">
        <div 
          className={`w-10 h-10 rounded-lg flex items-center justify-center ${pulse && value > 0 ? 'status-pulse-high' : ''}`}
          style={{ backgroundColor: color + '20' }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-2xl font-bold" style={{ color }}>{value}</p>
          <p className="text-xs text-[#A9B3C2]">{label}</p>
        </div>
      </div>
    </div>
  );
}
