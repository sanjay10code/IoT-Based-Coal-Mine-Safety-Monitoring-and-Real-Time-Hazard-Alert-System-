import { motion } from 'framer-motion';
import { FileText, Download, Calendar, Filter, Search, FileSpreadsheet, FileBarChart, FileCheck, Trash2, Eye } from 'lucide-react';
import { useState } from 'react';

interface Report {
  id: string;
  title: string;
  type: 'daily' | 'weekly' | 'monthly' | 'incident' | 'compliance';
  generatedAt: Date;
  size: string;
  status: 'ready' | 'generating' | 'scheduled';
}

const mockReports: Report[] = [
  { id: '1', title: 'Daily Safety Summary - March 2, 2026', type: 'daily', generatedAt: new Date(), size: '2.4 MB', status: 'ready' },
  { id: '2', title: 'Weekly Risk Analysis - Week 9', type: 'weekly', generatedAt: new Date(Date.now() - 24 * 60 * 60 * 1000), size: '8.7 MB', status: 'ready' },
  { id: '3', title: 'Monthly Compliance Report - February 2026', type: 'monthly', generatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), size: '15.2 MB', status: 'ready' },
  { id: '4', title: 'Incident Report - Tunnel-3 Methane Spike', type: 'incident', generatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), size: '4.1 MB', status: 'ready' },
  { id: '5', title: 'ML Model Performance - Q1 2026', type: 'compliance', generatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), size: '12.5 MB', status: 'ready' },
  { id: '6', title: 'Daily Safety Summary - March 1, 2026', type: 'daily', generatedAt: new Date(Date.now() - 24 * 60 * 60 * 1000), size: '2.3 MB', status: 'ready' },
  { id: '7', title: 'Weekly Risk Analysis - Week 8', type: 'weekly', generatedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000), size: '8.5 MB', status: 'ready' },
  { id: '8', title: 'Sensor Calibration Report', type: 'compliance', generatedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), size: '3.8 MB', status: 'ready' },
];

const reportTypeConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  daily: { icon: FileText, color: '#3B82F6', label: 'Daily' },
  weekly: { icon: FileSpreadsheet, color: '#8B5CF6', label: 'Weekly' },
  monthly: { icon: FileBarChart, color: '#EC4899', label: 'Monthly' },
  incident: { icon: FileCheck, color: '#EF4444', label: 'Incident' },
  compliance: { icon: FileCheck, color: '#22C55E', label: 'Compliance' },
};

export function Reports() {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [reports, setReports] = useState<Report[]>(mockReports);

  const filteredReports = reports.filter(report => {
    const matchesSearch = report.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || report.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleDelete = (id: string) => {
    setReports(reports.filter(r => r.id !== id));
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Safety <span className="text-[#FF4D00]">Reports</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Generate and download safety and compliance reports
            </p>
          </div>
          <button className="flex items-center justify-center gap-2 btn-primary">
            <FileText className="w-4 h-4" />
            Generate New Report
          </button>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-5 gap-4"
        >
          <QuickStat label="Total Reports" value={reports.length} icon={FileText} color="#3B82F6" />
          <QuickStat label="Daily" value={reports.filter(r => r.type === 'daily').length} icon={FileText} color="#3B82F6" />
          <QuickStat label="Weekly" value={reports.filter(r => r.type === 'weekly').length} icon={FileSpreadsheet} color="#8B5CF6" />
          <QuickStat label="Monthly" value={reports.filter(r => r.type === 'monthly').length} icon={FileBarChart} color="#EC4899" />
          <QuickStat label="Incidents" value={reports.filter(r => r.type === 'incident').length} icon={FileCheck} color="#EF4444" />
        </motion.div>

        {/* Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card-dark p-4"
        >
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A9B3C2]" />
              <input
                type="text"
                placeholder="Search reports..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-[#A9B3C2] focus:outline-none focus:border-[#FF4D00]/50"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#A9B3C2]" />
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="px-3 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#FF4D00]/50"
              >
                <option value="all">All Types</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="incident">Incident</option>
                <option value="compliance">Compliance</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Reports List */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="card-dark overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Type</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Title</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Generated</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Size</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredReports.map((report, index) => {
                  const TypeIcon = reportTypeConfig[report.type].icon;
                  const typeColor = reportTypeConfig[report.type].color;
                  
                  return (
                    <motion.tr
                      key={report.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + index * 0.03 }}
                      className="border-b border-white/5 hover:bg-white/5 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div 
                          className="inline-flex items-center gap-2 px-2 py-1 rounded-lg"
                          style={{ backgroundColor: typeColor + '20' }}
                        >
                          <TypeIcon className="w-4 h-4" style={{ color: typeColor }} />
                          <span className="text-xs font-medium" style={{ color: typeColor }}>
                            {reportTypeConfig[report.type].label}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-white">{report.title}</td>
                      <td className="px-4 py-3 text-sm text-[#A9B3C2] font-mono">
                        {report.generatedAt.toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3 text-sm text-[#A9B3C2]">{report.size}</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-[#22C55E]/20 text-[#22C55E]">
                          {report.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button className="p-1.5 rounded bg-white/5 text-[#A9B3C2] hover:text-white hover:bg-white/10 transition-colors">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 rounded bg-[#FF4D00]/10 text-[#FF4D00] hover:bg-[#FF4D00]/20 transition-colors">
                            <Download className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(report.id)}
                            className="p-1.5 rounded bg-[#EF4444]/10 text-[#EF4444] hover:bg-[#EF4444]/20 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredReports.length === 0 && (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-[#A9B3C2] mx-auto mb-3 opacity-50" />
              <p className="text-[#A9B3C2]">No reports found</p>
            </div>
          )}
        </motion.div>

        {/* Scheduled Reports */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="card-dark p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#FF4D00]" />
              Scheduled Reports
            </h3>
            <button className="text-sm text-[#FF4D00] hover:underline">Manage Schedule</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <ScheduledReportCard 
              title="Daily Safety Summary"
              schedule="Every day at 06:00"
              nextRun="Tomorrow, 06:00 AM"
              type="daily"
            />
            <ScheduledReportCard 
              title="Weekly Risk Analysis"
              schedule="Every Monday at 08:00"
              nextRun="Mar 9, 08:00 AM"
              type="weekly"
            />
            <ScheduledReportCard 
              title="Monthly Compliance"
              schedule="1st of every month"
              nextRun="Apr 1, 09:00 AM"
              type="monthly"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}

interface QuickStatProps {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
}

function QuickStat({ label, value, icon: Icon, color }: QuickStatProps) {
  return (
    <div className="card-dark p-4">
      <div className="flex items-center gap-3">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: color + '20' }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-2xl font-bold" style={{ color }}>{value}</p>
          <p className="text-xs text-[#A9B3C2]">{label}</p>
        </div>
      </div>
    </div>
  );
}

interface ScheduledReportCardProps {
  title: string;
  schedule: string;
  nextRun: string;
  type: string;
}

function ScheduledReportCard({ title, schedule, nextRun, type }: ScheduledReportCardProps) {
  const TypeIcon = reportTypeConfig[type]?.icon || FileText;
  const typeColor = reportTypeConfig[type]?.color || '#3B82F6';
  
  return (
    <div className="p-4 bg-white/5 rounded-lg border border-white/10">
      <div className="flex items-center gap-2 mb-2">
        <TypeIcon className="w-4 h-4" style={{ color: typeColor }} />
        <span className="text-sm font-medium text-white">{title}</span>
      </div>
      <p className="text-xs text-[#A9B3C2] mb-1">{schedule}</p>
      <p className="text-xs text-[#FF4D00]">Next: {nextRun}</p>
    </div>
  );
}
