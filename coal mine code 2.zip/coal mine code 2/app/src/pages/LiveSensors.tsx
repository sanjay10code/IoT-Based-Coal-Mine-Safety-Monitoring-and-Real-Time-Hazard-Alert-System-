import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Activity, Flame, Wind, Droplets, Thermometer, Cloud, Zap, RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import type { SensorType } from '@/types';

const sensorConfig: Record<SensorType, { icon: React.ElementType; label: string; unit: string; color: string }> = {
  CH4: { icon: Flame, label: 'Methane', unit: '%', color: '#FF4D00' },
  CO: { icon: Wind, label: 'Carbon Monoxide', unit: 'ppm', color: '#EF4444' },
  O2: { icon: Droplets, label: 'Oxygen', unit: '%', color: '#3B82F6' },
  dust: { icon: Cloud, label: 'Dust', unit: 'mg/m³', color: '#F59E0B' },
  temperature: { icon: Thermometer, label: 'Temperature', unit: '°C', color: '#EC4899' },
  humidity: { icon: Droplets, label: 'Humidity', unit: '%', color: '#06B6D4' },
  vibration: { icon: Zap, label: 'Vibration', unit: 'mm/s', color: '#8B5CF6' },
};

export function LiveSensors() {
  const { sensors, zones, refreshData } = useApp();
  const [selectedSensor, setSelectedSensor] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    refreshData();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const getZoneName = (zoneId: string) => {
    return zones.find(z => z.id === zoneId)?.name || zoneId;
  };

  const selectedSensorData = sensors.find(s => s.id === selectedSensor);

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Live <span className="text-[#FF4D00]">Sensors</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Real-time sensor data from all monitoring points
            </p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center justify-center gap-2 btn-secondary disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </motion.div>

        {/* Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4"
        >
          <StatCard 
            label="Total Sensors"
            value={sensors.length}
            icon={Activity}
            color="#3B82F6"
          />
          <StatCard 
            label="Normal"
            value={sensors.filter(s => s.status === 'normal').length}
            icon={CheckCircle}
            color="#22C55E"
          />
          <StatCard 
            label="Warning"
            value={sensors.filter(s => s.status === 'warning').length}
            icon={AlertTriangle}
            color="#F59E0B"
          />
          <StatCard 
            label="Critical"
            value={sensors.filter(s => s.status === 'critical').length}
            icon={AlertTriangle}
            color="#EF4444"
          />
        </motion.div>

        {/* Sensor Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sensor List */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-1 space-y-3 max-h-[600px] overflow-y-auto pr-2"
          >
            {sensors.map((sensor, index) => {
              const config = sensorConfig[sensor.type];
              const Icon = config.icon;
              
              return (
                <motion.div
                  key={sensor.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 + index * 0.03 }}
                  onClick={() => setSelectedSensor(sensor.id)}
                  className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                    selectedSensor === sensor.id
                      ? 'bg-[#FF4D00]/10 border-[#FF4D00]/40'
                      : sensor.status === 'critical'
                      ? 'bg-[#EF4444]/10 border-[#EF4444]/30'
                      : sensor.status === 'warning'
                      ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30'
                      : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: config.color + '20' }}
                      >
                        <Icon className="w-5 h-5" style={{ color: config.color }} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{sensor.name}</p>
                        <p className="text-xs text-[#A9B3C2]">{getZoneName(sensor.zoneId)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${
                        sensor.status === 'critical' ? 'text-[#EF4444]' :
                        sensor.status === 'warning' ? 'text-[#F59E0B]' :
                        'text-white'
                      }`}>
                        {sensor.value.toFixed(sensor.type === 'CH4' ? 2 : 1)}
                      </p>
                      <p className="text-xs text-[#A9B3C2]">{config.unit}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <div className={`w-2 h-2 rounded-full ${
                        sensor.status === 'critical' ? 'bg-[#EF4444] status-pulse-high' :
                        sensor.status === 'warning' ? 'bg-[#F59E0B]' :
                        'bg-[#22C55E]'
                      }`} />
                      <span className={`text-xs capitalize ${
                        sensor.status === 'critical' ? 'text-[#EF4444]' :
                        sensor.status === 'warning' ? 'text-[#F59E0B]' :
                        'text-[#22C55E]'
                      }`}>
                        {sensor.status}
                      </span>
                    </div>
                    <span className="text-xs text-[#A9B3C2] font-mono">
                      {sensor.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Sensor Detail */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-2"
          >
            {selectedSensorData ? (
              <div className="card-dark p-6 h-full">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: sensorConfig[selectedSensorData.type].color + '20' }}
                    >
                      {(() => {
                        const Icon = sensorConfig[selectedSensorData.type].icon;
                        return <Icon className="w-6 h-6" style={{ color: sensorConfig[selectedSensorData.type].color }} />;
                      })()}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{selectedSensorData.name}</h3>
                      <p className="text-sm text-[#A9B3C2]">{getZoneName(selectedSensorData.zoneId)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-3xl font-bold ${
                      selectedSensorData.status === 'critical' ? 'text-[#EF4444]' :
                      selectedSensorData.status === 'warning' ? 'text-[#F59E0B]' :
                      'text-white'
                    }`}>
                      {selectedSensorData.value.toFixed(selectedSensorData.type === 'CH4' ? 2 : 1)}
                      <span className="text-lg text-[#A9B3C2] ml-1">
                        {sensorConfig[selectedSensorData.type].unit}
                      </span>
                    </p>
                    <div className="flex items-center justify-end gap-1.5 mt-1">
                      <div className={`w-2 h-2 rounded-full ${
                        selectedSensorData.status === 'critical' ? 'bg-[#EF4444]' :
                        selectedSensorData.status === 'warning' ? 'bg-[#F59E0B]' :
                        'bg-[#22C55E]'
                      }`} />
                      <span className={`text-sm capitalize ${
                        selectedSensorData.status === 'critical' ? 'text-[#EF4444]' :
                        selectedSensorData.status === 'warning' ? 'text-[#F59E0B]' :
                        'text-[#22C55E]'
                      }`}>
                        {selectedSensorData.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Chart */}
                <div className="h-64 mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedSensorData.history}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis 
                        dataKey="timestamp"
                        tickFormatter={(time) => new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        stroke="#A9B3C2"
                        fontSize={11}
                      />
                      <YAxis stroke="#A9B3C2" fontSize={11} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#111827',
                          border: '1px solid rgba(255,255,255,0.1)',
                          borderRadius: '8px',
                        }}
                        labelFormatter={(label) => new Date(label).toLocaleString()}
                        formatter={(value: number) => [value.toFixed(2), selectedSensorData.name]}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={sensorConfig[selectedSensorData.type].color}
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                {/* Details */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-3 bg-white/5 rounded-lg">
                    <p className="text-xs text-[#A9B3C2] mb-1">Sensor Type</p>
                    <p className="text-sm font-medium text-white">{sensorConfig[selectedSensorData.type].label}</p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <p className="text-xs text-[#A9B3C2] mb-1">Last Reading</p>
                    <p className="text-sm font-medium text-white">
                      {selectedSensorData.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <p className="text-xs text-[#A9B3C2] mb-1">Data Points</p>
                    <p className="text-sm font-medium text-white">{selectedSensorData.history.length}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="card-dark p-6 h-full flex flex-col items-center justify-center text-center">
                <Activity className="w-16 h-16 text-[#A9B3C2] mb-4 opacity-50" />
                <h3 className="text-lg font-semibold text-white mb-2">Select a Sensor</h3>
                <p className="text-sm text-[#A9B3C2]">Click on any sensor from the list to view detailed data</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
}

function StatCard({ label, value, icon: Icon, color }: StatCardProps) {
  return (
    <div className="card-dark p-4">
      <div className="flex items-center gap-3">
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: color + '20' }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-2xl font-bold text-white">{value}</p>
          <p className="text-xs text-[#A9B3C2]">{label}</p>
        </div>
      </div>
    </div>
  );
}
