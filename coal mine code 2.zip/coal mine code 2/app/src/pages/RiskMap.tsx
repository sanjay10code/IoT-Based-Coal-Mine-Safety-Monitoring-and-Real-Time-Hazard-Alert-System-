import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Map, AlertTriangle, Info, Flame, Wind, Thermometer, Cloud, Activity, Droplets, Zap } from 'lucide-react';
import { useState } from 'react';
import type { RiskLevel, Zone } from '@/types';

const riskColors: Record<RiskLevel, string> = {
  low: '#22C55E',
  medium: '#F59E0B',
  high: '#EF4444',
  critical: '#FF4D00',
};

const sensorIcons: Record<string, React.ElementType> = {
  CH4: Flame,
  CO: Wind,
  O2: Droplets,
  dust: Cloud,
  temperature: Thermometer,
  humidity: Droplets,
  vibration: Zap,
};

export function RiskMap() {
  const { zones, getZoneSensors } = useApp();
  const [selectedZone, setSelectedZone] = useState<Zone | null>(null);
  const [showHeatmap, setShowHeatmap] = useState(true);

  const getRiskStats = () => {
    const total = zones.length;
    const critical = zones.filter(z => z.riskLevel === 'critical').length;
    const high = zones.filter(z => z.riskLevel === 'high').length;
    const medium = zones.filter(z => z.riskLevel === 'medium').length;
    const low = zones.filter(z => z.riskLevel === 'low').length;
    return { total, critical, high, medium, low };
  };

  const stats = getRiskStats();

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Risk <span className="text-[#FF4D00]">Map</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Visualize risk distribution across all mine zones
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowHeatmap(!showHeatmap)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                showHeatmap
                  ? 'bg-[#FF4D00]/20 text-[#FF4D00] border border-[#FF4D00]/30'
                  : 'bg-white/5 text-[#A9B3C2] border border-transparent'
              }`}
            >
              {showHeatmap ? 'Hide Heatmap' : 'Show Heatmap'}
            </button>
          </div>
        </motion.div>

        {/* Risk Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-5 gap-4"
        >
          <RiskStatCard label="Total Zones" value={stats.total} color="#3B82F6" />
          <RiskStatCard label="Critical" value={stats.critical} color="#FF4D00" pulse />
          <RiskStatCard label="High" value={stats.high} color="#EF4444" />
          <RiskStatCard label="Medium" value={stats.medium} color="#F59E0B" />
          <RiskStatCard label="Low" value={stats.low} color="#22C55E" />
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Map */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="card-dark p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Map className="w-5 h-5 text-[#FF4D00]" />
                  <h3 className="text-lg font-semibold text-white">Zone Risk Distribution</h3>
                </div>
                {/* Legend */}
                <div className="flex items-center gap-3 text-xs">
                  {(['low', 'medium', 'high', 'critical'] as RiskLevel[]).map((level) => (
                    <div key={level} className="flex items-center gap-1.5">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: riskColors[level] }}
                      />
                      <span className="text-[#A9B3C2] capitalize">{level}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Schematic Map */}
              <div className="zone-schematic aspect-[16/10] relative">
                {/* Grid */}
                <div className="absolute inset-0 opacity-30">
                  <svg width="100%" height="100%">
                    <pattern id="riskGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"/>
                    </pattern>
                    <rect width="100%" height="100%" fill="url(#riskGrid)" />
                  </svg>
                </div>

                {/* Heatmap Overlay */}
                {showHeatmap && (
                  <div className="absolute inset-0 pointer-events-none">
                    {zones.map((zone) => (
                      <div
                        key={`heatmap-${zone.id}`}
                        className="absolute rounded-full blur-2xl opacity-30"
                        style={{
                          left: `${zone.coordinates.x - 5}%`,
                          top: `${zone.coordinates.y - 5}%`,
                          width: `${zone.coordinates.width + 10}%`,
                          height: `${zone.coordinates.height + 10}%`,
                          backgroundColor: riskColors[zone.riskLevel],
                        }}
                      />
                    ))}
                  </div>
                )}

                {/* Zone Nodes */}
                {zones.map((zone, index) => {
                  const zoneSensors = getZoneSensors(zone.id);
                  const criticalSensors = zoneSensors.filter(s => s.status === 'critical');
                  const warningSensors = zoneSensors.filter(s => s.status === 'warning');
                  
                  return (
                    <motion.div
                      key={zone.id}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.3 + index * 0.1 }}
                      className="absolute cursor-pointer"
                      style={{
                        left: `${zone.coordinates.x + zone.coordinates.width / 2}%`,
                        top: `${zone.coordinates.y + zone.coordinates.height / 2}%`,
                        transform: 'translate(-50%, -50%)',
                      }}
                      onClick={() => setSelectedZone(zone)}
                    >
                      <div 
                        className={`relative w-16 h-16 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                          selectedZone?.id === zone.id ? 'scale-125' : 'hover:scale-110'
                        }`}
                        style={{
                          backgroundColor: riskColors[zone.riskLevel] + '30',
                          borderColor: riskColors[zone.riskLevel],
                          boxShadow: `0 0 30px ${riskColors[zone.riskLevel]}40`,
                        }}
                      >
                        <span className="text-xs font-bold text-white text-center leading-tight">
                          {zone.name.split('-')[0]}
                        </span>
                        
                        {/* Alert Indicators */}
                        {(criticalSensors.length > 0 || warningSensors.length > 0) && (
                          <div className="absolute -top-1 -right-1 flex flex-col gap-1">
                            {criticalSensors.length > 0 && (
                              <div className="w-5 h-5 rounded-full bg-[#EF4444] flex items-center justify-center text-[10px] text-white font-bold status-pulse-high">
                                {criticalSensors.length}
                              </div>
                            )}
                            {warningSensors.length > 0 && (
                              <div className="w-5 h-5 rounded-full bg-[#F59E0B] flex items-center justify-center text-[10px] text-white font-bold">
                                {warningSensors.length}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}

                {/* Connection Lines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                  <line x1="21%" y1="27.5%" x2="47.5%" y2="40%" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
                  <line x1="47.5%" y1="40%" x2="75%" y2="35%" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
                  <line x1="47.5%" y1="40%" x2="59%" y2="66%" stroke="rgba(255,255,255,0.1)" strokeWidth="2" />
                  <line x1="75%" y1="35%" x2="84%" y2="77.5%" stroke="rgba(255,255,255,0.1)" strokeWidth="2" strokeDasharray="5,5" />
                </svg>
              </div>
            </div>
          </motion.div>

          {/* Zone Details */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-1"
          >
            <div className="card-dark p-6 h-full">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Info className="w-5 h-5 text-[#FF4D00]" />
                Zone Details
              </h3>

              {selectedZone ? (
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-white/5">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-lg font-semibold text-white">{selectedZone.name}</h4>
                      <span 
                        className="px-2 py-1 rounded-full text-xs font-medium capitalize"
                        style={{ 
                          backgroundColor: riskColors[selectedZone.riskLevel] + '30',
                          color: riskColors[selectedZone.riskLevel]
                        }}
                      >
                        {selectedZone.riskLevel} Risk
                      </span>
                    </div>
                    <p className="text-sm text-[#A9B3C2]">{selectedZone.description}</p>
                  </div>

                  {/* Sensors */}
                  <div>
                    <h5 className="text-sm font-medium text-white mb-3">Active Sensors</h5>
                    <div className="space-y-2">
                      {getZoneSensors(selectedZone.id).map((sensor) => {
                        const Icon = sensorIcons[sensor.type] || Activity;
                        
                        return (
                          <div 
                            key={sensor.id}
                            className={`p-3 rounded-lg border ${
                              sensor.status === 'critical' ? 'bg-[#EF4444]/10 border-[#EF4444]/30' :
                              sensor.status === 'warning' ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30' :
                              'bg-white/5 border-white/10'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Icon className="w-4 h-4 text-[#A9B3C2]" />
                                <span className="text-sm text-white">{sensor.name}</span>
                              </div>
                              <span className={`text-sm font-medium ${
                                sensor.status === 'critical' ? 'text-[#EF4444]' :
                                sensor.status === 'warning' ? 'text-[#F59E0B]' :
                                'text-[#22C55E]'
                              }`}>
                                {sensor.value.toFixed(sensor.type === 'CH4' ? 2 : 1)} {sensor.unit}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Risk Factors */}
                  <div>
                    <h5 className="text-sm font-medium text-white mb-3">Risk Factors</h5>
                    <div className="space-y-2">
                      {getZoneSensors(selectedZone.id)
                        .filter(s => s.status === 'critical' || s.status === 'warning')
                        .map((sensor) => (
                          <div key={sensor.id} className="flex items-center gap-2 text-sm">
                            <AlertTriangle className={`w-4 h-4 ${
                              sensor.status === 'critical' ? 'text-[#EF4444]' : 'text-[#F59E0B]'
                            }`} />
                            <span className="text-[#A9B3C2]">
                              {sensor.name}: {sensor.value.toFixed(1)} {sensor.unit}
                            </span>
                          </div>
                        ))}
                      {getZoneSensors(selectedZone.id).filter(s => s.status === 'critical' || s.status === 'warning').length === 0 && (
                        <div className="flex items-center gap-2 text-sm">
                          <Activity className="w-4 h-4 text-[#22C55E]" />
                          <span className="text-[#22C55E]">All sensors within normal range</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Map className="w-12 h-12 text-[#A9B3C2] mx-auto mb-3 opacity-50" />
                  <p className="text-[#A9B3C2]">Select a zone to view details</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

interface RiskStatCardProps {
  label: string;
  value: number;
  color: string;
  pulse?: boolean;
}

function RiskStatCard({ label, value, color, pulse }: RiskStatCardProps) {
  return (
    <div className="card-dark p-4">
      <div className="flex items-center justify-between">
        <span className="text-sm text-[#A9B3C2]">{label}</span>
        <div 
          className={`w-3 h-3 rounded-full ${pulse && value > 0 ? 'status-pulse-critical' : ''}`}
          style={{ backgroundColor: color }}
        />
      </div>
      <p className="text-2xl font-bold mt-1" style={{ color }}>{value}</p>
    </div>
  );
}
