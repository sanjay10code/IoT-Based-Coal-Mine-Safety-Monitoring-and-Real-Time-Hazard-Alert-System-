import { motion } from 'framer-motion';
import { Brain, TrendingUp, Network, Search, Shield, Activity, CheckCircle, Clock, AlertTriangle, Play, RotateCcw, BarChart3 } from 'lucide-react';
import { useState } from 'react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';

interface ModelDetail {
  id: string;
  name: string;
  description: string;
  longDescription: string;
  icon: React.ElementType;
  accuracy: number;
  latency: number;
  status: 'healthy' | 'degraded' | 'retraining';
  features: string[];
  parameters: Record<string, string>;
  performance: { time: string; accuracy: number; latency: number }[];
}

const modelDetails: ModelDetail[] = [
  {
    id: 'conformal',
    name: 'Conformal Prediction',
    description: 'Risk forecasts with calibrated uncertainty bands',
    longDescription: 'Conformal Prediction provides risk forecasts with statistically valid uncertainty bands. This allows operators to know when the model is uncertain and requires human oversight. The method guarantees coverage probability, ensuring that true values fall within predicted intervals with a specified confidence level.',
    icon: TrendingUp,
    accuracy: 94.2,
    latency: 38,
    status: 'healthy',
    features: ['Uncertainty Quantification', '99% Coverage Guarantee', 'Calibration Monitoring', 'Adaptive Thresholds'],
    parameters: {
      'Confidence Level': '95%',
      'Coverage': '99.2%',
      'Interval Width': 'Adaptive',
      'Calibration': 'Daily',
    },
    performance: [
      { time: '00:00', accuracy: 93.8, latency: 40 },
      { time: '04:00', accuracy: 94.0, latency: 38 },
      { time: '08:00', accuracy: 94.2, latency: 37 },
      { time: '12:00', accuracy: 94.1, latency: 39 },
      { time: '16:00', accuracy: 94.3, latency: 36 },
      { time: '20:00', accuracy: 94.2, latency: 38 },
    ],
  },
  {
    id: 'tft',
    name: 'Temporal Fusion Transformer',
    description: 'Multivariate time-series forecasting',
    longDescription: 'The Temporal Fusion Transformer (TFT) is a state-of-the-art architecture for multi-horizon time-series forecasting. It combines multi-head attention for long-term dependencies with recurrent layers for local processing, enabling accurate predictions across multiple time horizons while providing interpretable attention weights.',
    icon: Brain,
    accuracy: 96.8,
    latency: 52,
    status: 'healthy',
    features: ['Multi-Horizon Forecasting', 'Variable Selection Networks', 'Interpretable Attention', 'Static Covariates'],
    parameters: {
      'Hidden Size': '160',
      'Attention Heads': '4',
      'Forecast Horizon': '24h',
      'Learning Rate': '0.001',
    },
    performance: [
      { time: '00:00', accuracy: 96.2, latency: 55 },
      { time: '04:00', accuracy: 96.5, latency: 53 },
      { time: '08:00', accuracy: 96.8, latency: 51 },
      { time: '12:00', accuracy: 96.7, latency: 52 },
      { time: '16:00', accuracy: 96.9, latency: 50 },
      { time: '20:00', accuracy: 96.8, latency: 52 },
    ],
  },
  {
    id: 'gnn',
    name: 'Graph Neural Network',
    description: 'Tunnel connectivity risk propagation',
    longDescription: 'Graph Neural Networks model the mine as a connected graph where zones are nodes and tunnels are edges. This allows the model to understand spatial relationships and predict how risks propagate through the mine network, enabling early warnings for zones that may be affected by incidents in connected areas.',
    icon: Network,
    accuracy: 92.5,
    latency: 45,
    status: 'healthy',
    features: ['Spatial Reasoning', 'Message Passing', 'Connectivity Analysis', 'Risk Diffusion Modeling'],
    parameters: {
      'Layers': '3',
      'Hidden Dim': '128',
      'Message Passing': 'GraphSAGE',
      'Aggregation': 'Mean',
    },
    performance: [
      { time: '00:00', accuracy: 91.8, latency: 48 },
      { time: '04:00', accuracy: 92.1, latency: 46 },
      { time: '08:00', accuracy: 92.5, latency: 44 },
      { time: '12:00', accuracy: 92.3, latency: 45 },
      { time: '16:00', accuracy: 92.6, latency: 43 },
      { time: '20:00', accuracy: 92.5, latency: 45 },
    ],
  },
  {
    id: 'ssad',
    name: 'Self-Supervised Anomaly Detection',
    description: 'Contrastive learning for novel anomalies',
    longDescription: 'Self-Supervised Anomaly Detection uses contrastive learning to identify anomalies without requiring labeled training data. By learning representations that capture normal operational patterns, the model can detect novel anomalies that have never been seen before, making it ideal for emerging safety risks.',
    icon: Search,
    accuracy: 89.3,
    latency: 34,
    status: 'healthy',
    features: ['No Labels Required', 'Novel Pattern Detection', 'Continuous Learning', 'Low Latency'],
    parameters: {
      'Encoder': 'ResNet-18',
      'Projection Dim': '128',
      'Temperature': '0.07',
      'Batch Size': '256',
    },
    performance: [
      { time: '00:00', accuracy: 88.5, latency: 36 },
      { time: '04:00', accuracy: 88.9, latency: 35 },
      { time: '08:00', accuracy: 89.3, latency: 33 },
      { time: '12:00', accuracy: 89.1, latency: 34 },
      { time: '16:00', accuracy: 89.4, latency: 32 },
      { time: '20:00', accuracy: 89.3, latency: 34 },
    ],
  },
  {
    id: 'fl',
    name: 'Federated Learning + HPO',
    description: 'Privacy-preserving distributed learning',
    longDescription: 'Federated Learning enables training machine learning models across multiple mine sites without sharing sensitive data. Combined with automated Hyperparameter Optimization (HPO), this approach continuously improves model performance while maintaining data privacy and regulatory compliance.',
    icon: Shield,
    accuracy: 91.7,
    latency: 120,
    status: 'retraining',
    features: ['Privacy Preserving', 'Cross-Site Learning', 'Auto ML', 'Differential Privacy'],
    parameters: {
      'Clients': '5',
      'Rounds': '100',
      'Local Epochs': '5',
      'Privacy Budget': '1.0',
    },
    performance: [
      { time: '00:00', accuracy: 90.5, latency: 125 },
      { time: '04:00', accuracy: 90.8, latency: 122 },
      { time: '08:00', accuracy: 91.2, latency: 120 },
      { time: '12:00', accuracy: 91.5, latency: 118 },
      { time: '16:00', accuracy: 91.7, latency: 115 },
      { time: '20:00', accuracy: 91.7, latency: 120 },
    ],
  },
];

const statusConfig = {
  healthy: { icon: CheckCircle, color: '#22C55E', label: 'Healthy' },
  degraded: { icon: AlertTriangle, color: '#F59E0B', label: 'Degraded' },
  retraining: { icon: Activity, color: '#FF4D00', label: 'Retraining' },
};

export function Models() {
  const [selectedModel, setSelectedModel] = useState<ModelDetail>(modelDetails[0]);
  const [activeTab, setActiveTab] = useState<'overview' | 'performance' | 'parameters'>('overview');

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              ML <span className="text-[#FF4D00]">Models</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Advanced machine learning models for predictive safety
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 bg-[#22C55E]/10 border border-[#22C55E]/30 rounded-lg">
              <CheckCircle className="w-4 h-4 text-[#22C55E]" />
              <span className="text-sm text-[#22C55E]">4 Healthy</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-[#FF4D00]/10 border border-[#FF4D00]/30 rounded-lg">
              <Activity className="w-4 h-4 text-[#FF4D00] status-pulse-critical" />
              <span className="text-sm text-[#FF4D00]">1 Retraining</span>
            </div>
          </div>
        </motion.div>

        {/* Model Selection */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3"
        >
          {modelDetails.map((model) => {
            const Icon = model.icon;
            const StatusIcon = statusConfig[model.status].icon;
            const isSelected = selectedModel.id === model.id;
            
            return (
              <button
                key={model.id}
                onClick={() => setSelectedModel(model)}
                className={`p-4 rounded-lg border text-left transition-all duration-200 ${
                  isSelected
                    ? 'bg-[#FF4D00]/10 border-[#FF4D00]/40'
                    : 'bg-white/5 border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: isSelected ? '#FF4D0020' : 'rgba(255,255,255,0.05)' }}
                  >
                    <Icon className="w-4 h-4" style={{ color: isSelected ? '#FF4D00' : '#A9B3C2' }} />
                  </div>
                  <StatusIcon 
                    className="w-4 h-4"
                    style={{ color: statusConfig[model.status].color }}
                  />
                </div>
                <p className={`text-sm font-medium ${isSelected ? 'text-white' : 'text-[#A9B3C2]'}`}>
                  {model.name}
                </p>
                <p className="text-xs text-[#A9B3C2] mt-1">{model.accuracy}% accuracy</p>
              </button>
            );
          })}
        </motion.div>

        {/* Model Details */}
        <motion.div 
          key={selectedModel.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-dark p-6"
        >
          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-[#FF4D00]/10 flex items-center justify-center">
                {(() => {
                  const Icon = selectedModel.icon;
                  return <Icon className="w-7 h-7 text-[#FF4D00]" />;
                })()}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">{selectedModel.name}</h2>
                <p className="text-[#A9B3C2]">{selectedModel.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-[#FF4D00]/10 text-[#FF4D00] rounded-lg hover:bg-[#FF4D00]/20 transition-colors">
                <Play className="w-4 h-4" />
                Run Inference
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors">
                <RotateCcw className="w-4 h-4" />
                Retrain
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-6 border-b border-white/10 pb-4">
            {(['overview', 'performance', 'parameters'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === tab
                    ? 'bg-[#FF4D00]/15 text-[#FF4D00]'
                    : 'text-[#A9B3C2] hover:text-white hover:bg-white/5'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-[#A9B3C2] leading-relaxed mb-6">
                  {selectedModel.longDescription}
                </p>
                
                <h4 className="text-sm font-medium text-white mb-3">Key Features</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedModel.features.map((feature, i) => (
                    <span 
                      key={i}
                      className="px-3 py-1.5 bg-white/5 text-[#A9B3C2] text-sm rounded-lg"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-4 h-4 text-[#FF4D00]" />
                    <span className="text-sm text-[#A9B3C2]">Accuracy</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{selectedModel.accuracy}%</p>
                </div>
                <div className="p-4 bg-white/5 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-[#FF4D00]" />
                    <span className="text-sm text-[#A9B3C2]">Latency</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{selectedModel.latency}ms</p>
                </div>
                <div className="p-4 bg-white/5 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="w-4 h-4 text-[#FF4D00]" />
                    <span className="text-sm text-[#A9B3C2]">Status</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const StatusIcon = statusConfig[selectedModel.status].icon;
                      return <StatusIcon className="w-5 h-5" style={{ color: statusConfig[selectedModel.status].color }} />;
                    })()}
                    <span style={{ color: statusConfig[selectedModel.status].color }}>
                      {statusConfig[selectedModel.status].label}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'performance' && (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={selectedModel.performance}>
                  <defs>
                    <linearGradient id="accuracyGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#22C55E" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="time" stroke="#A9B3C2" fontSize={11} />
                  <YAxis stroke="#A9B3C2" fontSize={11} domain={[85, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#111827',
                      border: '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="accuracy"
                    stroke="#22C55E"
                    strokeWidth={2}
                    fill="url(#accuracyGradient)"
                    name="Accuracy %"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {activeTab === 'parameters' && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {Object.entries(selectedModel.parameters).map(([key, value]) => (
                <div key={key} className="p-4 bg-white/5 rounded-lg">
                  <p className="text-xs text-[#A9B3C2] mb-1">{key}</p>
                  <p className="text-lg font-semibold text-white">{value}</p>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
