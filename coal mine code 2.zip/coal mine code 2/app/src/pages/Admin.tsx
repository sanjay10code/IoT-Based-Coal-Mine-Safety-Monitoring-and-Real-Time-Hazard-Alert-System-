import { useApp } from '@/context/AppContext';
import { motion } from 'framer-motion';
import { Settings, Users, Shield, Bell, Database, Server, Activity, CheckCircle, AlertTriangle, Save, RotateCcw } from 'lucide-react';
import { useState } from 'react';

interface SystemSetting {
  id: string;
  category: string;
  name: string;
  description: string;
  value: boolean | string | number;
  type: 'boolean' | 'string' | 'number';
}

const initialSettings: SystemSetting[] = [
  { id: '1', category: 'Alerts', name: 'Email Notifications', description: 'Send email alerts for critical events', value: true, type: 'boolean' },
  { id: '2', category: 'Alerts', name: 'SMS Notifications', description: 'Send SMS alerts for critical events', value: true, type: 'boolean' },
  { id: '3', category: 'Alerts', name: 'Alert Threshold', description: 'Minimum severity level for notifications', value: 'medium', type: 'string' },
  { id: '4', category: 'ML', name: 'Auto-Retraining', description: 'Automatically retrain models when drift detected', value: true, type: 'boolean' },
  { id: '5', category: 'ML', name: 'Inference Interval', description: 'Seconds between model predictions', value: 30, type: 'number' },
  { id: '6', category: 'Sensors', name: 'Data Retention', description: 'Days to keep sensor history', value: 90, type: 'number' },
  { id: '7', category: 'Sensors', name: 'Sampling Rate', description: 'Sensor readings per minute', value: 12, type: 'number' },
  { id: '8', category: 'Security', name: 'Two-Factor Auth', description: 'Require 2FA for supervisor accounts', value: true, type: 'boolean' },
  { id: '9', category: 'Security', name: 'Session Timeout', description: 'Minutes until automatic logout', value: 30, type: 'number' },
];

const mockUsers = [
  { id: '1', name: 'John Smith', email: 'john.smith@coalmine.com', role: 'supervisor', status: 'active', lastActive: '2 min ago' },
  { id: '2', name: 'Sarah Johnson', email: 'sarah.j@coalmine.com', role: 'operator', status: 'active', lastActive: '5 min ago' },
  { id: '3', name: 'Mike Davis', email: 'mike.davis@coalmine.com', role: 'operator', status: 'offline', lastActive: '2 hours ago' },
  { id: '4', name: 'Emily Chen', email: 'emily.chen@coalmine.com', role: 'supervisor', status: 'active', lastActive: '1 min ago' },
];

export function Admin() {
  const { userRole } = useApp();
  const [activeTab, setActiveTab] = useState<'general' | 'users' | 'system'>('general');
  const [settings, setSettings] = useState<SystemSetting[]>(initialSettings);
  const [hasChanges, setHasChanges] = useState(false);

  const handleSettingChange = (id: string, value: boolean | string | number) => {
    setSettings(settings.map(s => s.id === id ? { ...s, value } : s));
    setHasChanges(true);
  };

  const handleSave = () => {
    setHasChanges(false);
    // In a real app, this would save to backend
  };

  const handleReset = () => {
    setSettings(initialSettings);
    setHasChanges(false);
  };

  const groupedSettings = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) acc[setting.category] = [];
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, SystemSetting[]>);

  if (userRole !== 'supervisor') {
    return (
      <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1800px] mx-auto">
          <div className="card-dark p-12 text-center">
            <Shield className="w-16 h-16 text-[#EF4444] mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-white mb-2">Access Denied</h1>
            <p className="text-[#A9B3C2]">Only supervisors can access the Admin panel.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              System <span className="text-[#FF4D00]">Admin</span>
            </h1>
            <p className="text-[#A9B3C2]">
              Configure system settings and manage users
            </p>
          </div>
          {hasChanges && (
            <div className="flex items-center gap-3">
              <button 
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 bg-white/5 text-white rounded-lg hover:bg-white/10 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                Reset
              </button>
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 btn-primary"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>
          )}
        </motion.div>

        {/* System Status */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4"
        >
          <StatusCard 
            label="System Status"
            value="Operational"
            icon={Server}
            color="#22C55E"
            pulse
          />
          <StatusCard 
            label="Database"
            value="Connected"
            icon={Database}
            color="#22C55E"
          />
          <StatusCard 
            label="Active Users"
            value={mockUsers.filter(u => u.status === 'active').length.toString()}
            icon={Users}
            color="#3B82F6"
          />
          <StatusCard 
            label="Uptime"
            value="99.97%"
            icon={Activity}
            color="#8B5CF6"
          />
        </motion.div>

        {/* Tabs */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex gap-2 border-b border-white/10"
        >
          {(['general', 'users', 'system'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-sm font-medium transition-all duration-200 border-b-2 ${
                activeTab === tab
                  ? 'text-[#FF4D00] border-[#FF4D00]'
                  : 'text-[#A9B3C2] border-transparent hover:text-white'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </motion.div>

        {/* Tab Content */}
        <motion.div 
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card-dark p-6"
        >
          {activeTab === 'general' && (
            <div className="space-y-6">
              {Object.entries(groupedSettings).map(([category, categorySettings]) => (
                <div key={category}>
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Settings className="w-5 h-5 text-[#FF4D00]" />
                    {category} Settings
                  </h3>
                  <div className="space-y-4">
                    {categorySettings.map((setting) => (
                      <div 
                        key={setting.id}
                        className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 bg-white/5 rounded-lg"
                      >
                        <div className="mb-3 sm:mb-0">
                          <p className="text-sm font-medium text-white">{setting.name}</p>
                          <p className="text-xs text-[#A9B3C2]">{setting.description}</p>
                        </div>
                        <div>
                          {setting.type === 'boolean' && (
                            <button
                              onClick={() => handleSettingChange(setting.id, !setting.value)}
                              className={`w-12 h-6 rounded-full transition-colors relative ${
                                setting.value ? 'bg-[#22C55E]' : 'bg-white/20'
                              }`}
                            >
                              <div 
                                className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${
                                  setting.value ? 'left-6' : 'left-0.5'
                                }`}
                              />
                            </button>
                          )}
                          {setting.type === 'number' && (
                            <input
                              type="number"
                              value={setting.value as number}
                              onChange={(e) => handleSettingChange(setting.id, parseInt(e.target.value))}
                              className="w-24 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white text-center focus:outline-none focus:border-[#FF4D00]/50"
                            />
                          )}
                          {setting.type === 'string' && (
                            <select
                              value={setting.value as string}
                              onChange={(e) => handleSettingChange(setting.id, e.target.value)}
                              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#FF4D00]/50"
                            >
                              <option value="low">Low</option>
                              <option value="medium">Medium</option>
                              <option value="high">High</option>
                              <option value="critical">Critical</option>
                            </select>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'users' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#FF4D00]" />
                  User Management
                </h3>
                <button className="btn-primary text-sm">
                  Add User
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">User</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Role</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Status</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Last Active</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-[#A9B3C2]">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockUsers.map((user) => (
                      <tr key={user.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                        <td className="px-4 py-3">
                          <div>
                            <p className="text-sm font-medium text-white">{user.name}</p>
                            <p className="text-xs text-[#A9B3C2]">{user.email}</p>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium capitalize ${
                            user.role === 'supervisor' 
                              ? 'bg-[#FF4D00]/20 text-[#FF4D00]' 
                              : 'bg-[#3B82F6]/20 text-[#3B82F6]'
                          }`}>
                            {user.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5">
                            <div className={`w-2 h-2 rounded-full ${
                              user.status === 'active' ? 'bg-[#22C55E]' : 'bg-[#A9B3C2]'
                            }`} />
                            <span className="text-sm text-[#A9B3C2] capitalize">{user.status}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm text-[#A9B3C2]">{user.lastActive}</td>
                        <td className="px-4 py-3">
                          <button className="text-sm text-[#FF4D00] hover:underline">Edit</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'system' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Server className="w-5 h-5 text-[#FF4D00]" />
                  System Information
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <InfoCard label="Version" value="v2.4.1" />
                  <InfoCard label="Build" value="2026.03.02" />
                  <InfoCard label="Environment" value="Production" />
                  <InfoCard label="Region" value="US-East" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Database className="w-5 h-5 text-[#FF4D00]" />
                  Database Statistics
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <InfoCard label="Total Records" value="2.4M" />
                  <InfoCard label="Sensor Readings" value="1.8M" />
                  <InfoCard label="Alerts" value="12.5K" />
                  <InfoCard label="Size" value="45.2 GB" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Bell className="w-5 h-5 text-[#FF4D00]" />
                  Notification Channels
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#22C55E]/10 flex items-center justify-center">
                        <CheckCircle className="w-5 h-5 text-[#22C55E]" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Email Service</p>
                        <p className="text-xs text-[#A9B3C2]">SMTP configured and operational</p>
                      </div>
                    </div>
                    <span className="text-xs text-[#22C55E]">Connected</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#22C55E]/10 flex items-center justify-center">
                        <CheckCircle className="w-5 h-5 text-[#22C55E]" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">SMS Gateway</p>
                        <p className="text-xs text-[#A9B3C2]">Twilio integration active</p>
                      </div>
                    </div>
                    <span className="text-xs text-[#22C55E]">Connected</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#F59E0B]/10 flex items-center justify-center">
                        <AlertTriangle className="w-5 h-5 text-[#F59E0B]" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">Webhook</p>
                        <p className="text-xs text-[#A9B3C2]">Last ping: 5 min ago</p>
                      </div>
                    </div>
                    <span className="text-xs text-[#F59E0B]">Degraded</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

interface StatusCardProps {
  label: string;
  value: string;
  icon: React.ElementType;
  color: string;
  pulse?: boolean;
}

function StatusCard({ label, value, icon: Icon, color, pulse }: StatusCardProps) {
  return (
    <div className="card-dark p-4">
      <div className="flex items-center gap-3">
        <div 
          className={`w-10 h-10 rounded-lg flex items-center justify-center ${pulse ? 'status-pulse-low' : ''}`}
          style={{ backgroundColor: color + '20' }}
        >
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div>
          <p className="text-xs text-[#A9B3C2]">{label}</p>
          <p className="text-lg font-semibold" style={{ color }}>{value}</p>
        </div>
      </div>
    </div>
  );
}

interface InfoCardProps {
  label: string;
  value: string;
}

function InfoCard({ label, value }: InfoCardProps) {
  return (
    <div className="p-4 bg-white/5 rounded-lg">
      <p className="text-xs text-[#A9B3C2] mb-1">{label}</p>
      <p className="text-lg font-semibold text-white">{value}</p>
    </div>
  );
}
