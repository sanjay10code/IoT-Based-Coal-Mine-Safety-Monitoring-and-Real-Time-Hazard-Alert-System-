import { useApp } from '@/context/AppContext';
import { SafetyScoreGauge } from '@/components/SafetyScoreGauge';
import { MineDigitalTwin } from '@/components/MineDigitalTwin';
import { MLAlgorithmCards } from '@/components/MLAlgorithmCards';
import { AlertsTimeline } from '@/components/AlertsTimeline';
import { SimulationControls } from '@/components/SimulationControls';
import { SensorCharts } from '@/components/SensorCharts';
import { LiveRiskOverview } from '@/components/LiveRiskOverview';
import { motion } from 'framer-motion';
import { Shield, TrendingUp, AlertTriangle, Activity } from 'lucide-react';

export function Dashboard() {
  const { safetyMetrics, getCriticalSensors } = useApp();
  const criticalSensors = getCriticalSensors();

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1800px] mx-auto space-y-8">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4"
        >
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
              Predictive Safety <span className="text-[#FF4D00]">Dashboard</span>
            </h1>
            <p className="text-[#A9B3C2]">
              AI-powered risk forecasting and real-time mine monitoring
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-[#22C55E]/10 border border-[#22C55E]/30 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-[#22C55E] status-pulse-low" />
              <span className="text-sm font-mono text-[#22C55E]">System Online</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-lg">
              <Activity className="w-4 h-4 text-[#FF4D00]" />
              <span className="text-sm font-mono text-[#A9B3C2]">
                {criticalSensors.length} Active Alerts
              </span>
            </div>
          </div>
        </motion.div>

        {/* Top Row - Safety Score + Live Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-1"
          >
            <SafetyScoreGauge />
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <LiveRiskOverview />
          </motion.div>
        </div>

        {/* Mine Digital Twin */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <MineDigitalTwin />
        </motion.div>

        {/* ML Algorithm Cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <MLAlgorithmCards />
        </motion.div>

        {/* Sensor Charts */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <SensorCharts />
        </motion.div>

        {/* Alerts Timeline + Simulation */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <AlertsTimeline />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
          >
            <SimulationControls />
          </motion.div>
        </div>

        {/* KPI Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          <KpiCard 
            icon={Shield}
            label="Sensor Uptime"
            value={`${safetyMetrics.sensorUptime}%`}
            trend="+0.02%"
            positive
          />
          <KpiCard 
            icon={TrendingUp}
            label="Avg Response"
            value={`${safetyMetrics.avgResponseTime} min`}
            trend="-0.3 min"
            positive
          />
          <KpiCard 
            icon={AlertTriangle}
            label="Open Alerts"
            value={safetyMetrics.openAlerts.toString()}
            trend="-2"
            positive
          />
          <KpiCard 
            icon={Activity}
            label="Model Accuracy"
            value={`${safetyMetrics.modelAccuracy}%`}
            trend="+1.2%"
            positive
          />
        </motion.div>
      </div>
    </div>
  );
}

interface KpiCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  trend: string;
  positive: boolean;
}

function KpiCard({ icon: Icon, label, value, trend, positive }: KpiCardProps) {
  return (
    <div className="card-dark card-dark-hover p-4 sm:p-6">
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-lg bg-[#FF4D00]/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-[#FF4D00]" />
        </div>
        <span className={`text-xs font-mono ${positive ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
          {trend}
        </span>
      </div>
      <p className="text-2xl sm:text-3xl font-bold text-white mb-1">{value}</p>
      <p className="text-xs sm:text-sm text-[#A9B3C2]">{label}</p>
    </div>
  );
}
